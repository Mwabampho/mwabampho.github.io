#!/usr/bin/env python3
"""
StepMail Server — Independent Mail Server & API Engine
Official Domain: stepmail.media

Features:
- RFC 5321 / RFC 6409 SMTP Server & Submission Daemon
- Strict Anti-Open Relay enforcement & Recipient Validation
- Local mailbox delivery directly to SQLite database
- DKIM Key Generation (2048-bit RSA) and Outgoing DKIM Signing (RFC 6376)
- MIME Parsing and Composition with Attachments (RFC 5322 / RFC 2045)
- Outbound Mail Queue & Spool Engine with direct MX resolution & retry logic
- REST Mailbox API for StepMail Clients (macOS / Web / Mobile)
- Live DNS & Deliverability Diagnostics (MX, SPF, DKIM, DMARC, PTR)
"""

import asyncio
import base64
import email
import email.policy
import email.utils
from email.message import EmailMessage
import hashlib
import hmac
import json
import mimetypes
import os
from pathlib import Path
import re
import secrets
import smtplib
import socket
import sqlite3
import ssl
import sys
import threading
import time
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import parse_qs, urlparse

# Cryptography for DKIM RSA key generation and signing
try:
    from cryptography.hazmat.primitives.asymmetric import rsa, padding
    from cryptography.hazmat.primitives import hashes, serialization
    HAS_CRYPTO = True
except ImportError:
    HAS_CRYPTO = False

# Configuration
ROOT_DIR = Path(__file__).resolve().parent
custom_data_dir = os.getenv("STEPMAIL_DATA_DIR")
if custom_data_dir:
    DATA_DIR = Path(custom_data_dir)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    ATTACHMENTS_DIR = DATA_DIR / "attachments"
    ATTACHMENTS_DIR.mkdir(parents=True, exist_ok=True)
elif sys.platform == "darwin":
    default_app_support = Path.home() / "Library" / "Application Support" / "StepMail"
    try:
        default_app_support.mkdir(parents=True, exist_ok=True)
        ATTACHMENTS_DIR = default_app_support / "attachments"
        ATTACHMENTS_DIR.mkdir(parents=True, exist_ok=True)
        DATA_DIR = default_app_support
    except (PermissionError, OSError):
        DATA_DIR = ROOT_DIR / "data"
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        ATTACHMENTS_DIR = DATA_DIR / "attachments"
        ATTACHMENTS_DIR.mkdir(parents=True, exist_ok=True)
else:
    # Linux / Production Server Default
    DATA_DIR = ROOT_DIR / "data"
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    ATTACHMENTS_DIR = DATA_DIR / "attachments"
    ATTACHMENTS_DIR.mkdir(parents=True, exist_ok=True)

DB_PATH = Path(os.getenv("STEPMAIL_DB", str(DATA_DIR / "stepmail.db")))
DOMAIN = os.getenv("STEPMAIL_DOMAIN", "stepmail.media").strip().lower()
HOSTNAME = os.getenv("STEPMAIL_HOSTNAME", f"mail.{DOMAIN}").strip().lower()
HOST = os.getenv("STEPMAIL_HOST", "127.0.0.1")
HTTP_PORT = int(os.getenv("STEPMAIL_HTTP_PORT", "8788"))
SMTP_HOST = os.getenv("STEPMAIL_SMTP_HOST", "127.0.0.1")
SMTP_PORT = int(os.getenv("STEPMAIL_SMTP_PORT", "2525")) # Inbound MX / local testing port
SUBMISSION_PORT = int(os.getenv("STEPMAIL_SUBMISSION_PORT", "5870")) # Submission port
SMTPS_PORT = int(os.getenv("STEPMAIL_SMTPS_PORT", "465")) # SMTPS implicit TLS port
ALLOW_SIGNUPS = os.getenv("STEPMAIL_ALLOW_SIGNUPS", "1") == "1"
DKIM_SELECTOR = os.getenv("STEPMAIL_DKIM_SELECTOR", "stepmail2026")
FALLBACK_SMTP_HOST = os.getenv("STEPMAIL_FALLBACK_SMTP_HOST", "")
FALLBACK_SMTP_PORT = int(os.getenv("STEPMAIL_FALLBACK_SMTP_PORT", "587"))
FALLBACK_SMTP_USER = os.getenv("STEPMAIL_FALLBACK_SMTP_USER", "")
FALLBACK_SMTP_PASS = os.getenv("STEPMAIL_FALLBACK_SMTP_PASS", "")
FALLBACK_SMTP_SECURITY = os.getenv("STEPMAIL_FALLBACK_SMTP_SECURITY", "starttls").lower()

SESSION_TTL = 60 * 60 * 24 * 30 # 30 days
MAX_BODY_SIZE = 25 * 1024 * 1024 # 25 MB
DB_LOCK = threading.Lock()

# -----------------------------------------------------------------------------
# Database Management
# -----------------------------------------------------------------------------

def get_db():
    global DB_PATH
    try:
        conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn
    except (sqlite3.OperationalError, OSError):
        # Fallback to local workspace data directory if system path is inaccessible
        fallback_db = ROOT_DIR / "data" / "stepmail.db"
        fallback_db.parent.mkdir(parents=True, exist_ok=True)
        DB_PATH = fallback_db
        conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

def init_db():
    with DB_LOCK, get_db() as conn:
        # Check if legacy incompatible schema exists
        u_cols = {row[1] for row in conn.execute("PRAGMA table_info(users)").fetchall()}
        if "pw_salt" in u_cols or "role" in u_cols:
            count = conn.execute("SELECT COUNT(*) c FROM users").fetchone()["c"]
            if count == 0:
                conn.executescript("""
                DROP TABLE IF EXISTS sessions;
                DROP TABLE IF EXISTS attachments;
                DROP TABLE IF EXISTS messages;
                DROP TABLE IF EXISTS users;
                """)
            else:
                # If there were users, migrate existing records to new table
                conn.executescript("""
                ALTER TABLE users RENAME TO legacy_users;
                DROP TABLE IF EXISTS sessions;
                DROP TABLE IF EXISTS attachments;
                DROP TABLE IF EXISTS messages;
                """)

        conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            handle TEXT NOT NULL UNIQUE COLLATE NOCASE,
            email TEXT NOT NULL UNIQUE COLLATE NOCASE,
            display_name TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS sessions (
            token_hash TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            expires_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            folder TEXT NOT NULL,
            sender TEXT NOT NULL,
            recipient TEXT NOT NULL,
            cc TEXT NOT NULL DEFAULT '',
            bcc TEXT NOT NULL DEFAULT '',
            subject TEXT NOT NULL DEFAULT '',
            body_text TEXT NOT NULL DEFAULT '',
            body_html TEXT NOT NULL DEFAULT '',
            is_read INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL,
            external_status TEXT NOT NULL DEFAULT '',
            external_id TEXT NOT NULL DEFAULT '',
            message_id TEXT NOT NULL DEFAULT '',
            in_reply_to TEXT NOT NULL DEFAULT '',
            references_header TEXT NOT NULL DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS attachments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message_id INTEGER NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
            filename TEXT NOT NULL,
            content_type TEXT NOT NULL,
            size INTEGER NOT NULL,
            storage_path TEXT NOT NULL,
            created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS outgoing_queue (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender TEXT NOT NULL,
            recipients TEXT NOT NULL,
            subject TEXT NOT NULL,
            raw_mime BLOB NOT NULL,
            status TEXT NOT NULL DEFAULT 'queued',
            retries INTEGER NOT NULL DEFAULT 0,
            next_attempt INTEGER NOT NULL DEFAULT 0,
            last_attempt INTEGER NOT NULL DEFAULT 0,
            last_error TEXT NOT NULL DEFAULT '',
            is_permanent INTEGER NOT NULL DEFAULT 0,
            smtp_code INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS dkim_keys (
            domain TEXT PRIMARY KEY COLLATE NOCASE,
            selector TEXT NOT NULL,
            private_key_pem TEXT NOT NULL,
            public_key_pem TEXT NOT NULL,
            dns_txt_record TEXT NOT NULL,
            created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS server_config (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        """)
        # Ensure schema migrations for existing database columns
        u_cols = {row[1] for row in conn.execute("PRAGMA table_info(users)").fetchall()}
        if u_cols:
            if "handle" not in u_cols:
                conn.execute("ALTER TABLE users ADD COLUMN handle TEXT DEFAULT ''")
                if "username" in u_cols:
                    conn.execute("UPDATE users SET handle = username WHERE handle IS NULL OR handle = ''")
                elif "email" in u_cols:
                    conn.execute("UPDATE users SET handle = substr(email, 1, instr(email, '@') - 1) WHERE handle IS NULL OR handle = ''")
            if "display_name" not in u_cols:
                conn.execute("ALTER TABLE users ADD COLUMN display_name TEXT DEFAULT ''")
                if "name" in u_cols:
                    conn.execute("UPDATE users SET display_name = name WHERE display_name IS NULL OR display_name = ''")
            if "password_hash" not in u_cols:
                conn.execute("ALTER TABLE users ADD COLUMN password_hash TEXT DEFAULT ''")
                if "password" in u_cols:
                    conn.execute("UPDATE users SET password_hash = password WHERE password_hash IS NULL OR password_hash = ''")
            if "created_at" not in u_cols:
                conn.execute("ALTER TABLE users ADD COLUMN created_at INTEGER DEFAULT 0")
            conn.commit()

        s_cols = {row[1] for row in conn.execute("PRAGMA table_info(sessions)").fetchall()}
        if s_cols:
            if "token_hash" not in s_cols:
                conn.execute("ALTER TABLE sessions ADD COLUMN token_hash TEXT DEFAULT ''")
                if "id_hash" in s_cols:
                    conn.execute("UPDATE sessions SET token_hash = id_hash WHERE token_hash IS NULL OR token_hash = ''")
            if "expires_at" not in s_cols:
                conn.execute("ALTER TABLE sessions ADD COLUMN expires_at INTEGER DEFAULT 0")
            conn.commit()

        cols = {row[1] for row in conn.execute("PRAGMA table_info(messages)").fetchall()}
        if cols:
            if "owner_user_id" not in cols and "user_id" in cols:
                conn.execute("ALTER TABLE messages ADD COLUMN owner_user_id INTEGER DEFAULT 1")
                conn.execute("UPDATE messages SET owner_user_id = user_id WHERE owner_user_id IS NULL OR owner_user_id = 1")
            elif "owner_user_id" not in cols:
                conn.execute("ALTER TABLE messages ADD COLUMN owner_user_id INTEGER DEFAULT 1")
            if "sender" not in cols:
                conn.execute("ALTER TABLE messages ADD COLUMN sender TEXT NOT NULL DEFAULT ''")
            if "recipient" not in cols:
                conn.execute("ALTER TABLE messages ADD COLUMN recipient TEXT NOT NULL DEFAULT ''")
            if "subject" not in cols:
                conn.execute("ALTER TABLE messages ADD COLUMN subject TEXT NOT NULL DEFAULT ''")
            if "body_text" not in cols:
                conn.execute("ALTER TABLE messages ADD COLUMN body_text TEXT NOT NULL DEFAULT ''")
            if "cc" not in cols:
                conn.execute("ALTER TABLE messages ADD COLUMN cc TEXT NOT NULL DEFAULT ''")
            if "bcc" not in cols:
                conn.execute("ALTER TABLE messages ADD COLUMN bcc TEXT NOT NULL DEFAULT ''")
            if "body_html" not in cols:
                conn.execute("ALTER TABLE messages ADD COLUMN body_html TEXT NOT NULL DEFAULT ''")
            if "external_status" not in cols:
                conn.execute("ALTER TABLE messages ADD COLUMN external_status TEXT NOT NULL DEFAULT ''")
            if "external_id" not in cols:
                conn.execute("ALTER TABLE messages ADD COLUMN external_id TEXT NOT NULL DEFAULT ''")
            if "message_id" not in cols:
                conn.execute("ALTER TABLE messages ADD COLUMN message_id TEXT NOT NULL DEFAULT ''")
            if "in_reply_to" not in cols:
                conn.execute("ALTER TABLE messages ADD COLUMN in_reply_to TEXT NOT NULL DEFAULT ''")
            if "references_header" not in cols:
                conn.execute("ALTER TABLE messages ADD COLUMN references_header TEXT NOT NULL DEFAULT ''")
            conn.commit()

        q_cols = {row[1] for row in conn.execute("PRAGMA table_info(outgoing_queue)").fetchall()}
        if q_cols:
            if "next_attempt" not in q_cols:
                conn.execute("ALTER TABLE outgoing_queue ADD COLUMN next_attempt INTEGER NOT NULL DEFAULT 0")
            if "is_permanent" not in q_cols:
                conn.execute("ALTER TABLE outgoing_queue ADD COLUMN is_permanent INTEGER NOT NULL DEFAULT 0")
            if "smtp_code" not in q_cols:
                conn.execute("ALTER TABLE outgoing_queue ADD COLUMN smtp_code INTEGER NOT NULL DEFAULT 0")
            conn.commit()

        conn.executescript("""
        CREATE INDEX IF NOT EXISTS idx_messages_owner_folder_created
            ON messages(owner_user_id, folder, created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_outgoing_queue_status
            ON outgoing_queue(status, next_attempt, retries);
        """)

def import_legacy_db_if_needed():
    """Migrates existing StepMail databases from legacy locations if present."""
    candidates = [
        Path.home() / "Downloads/StepMail-0.1/data/stepmail.db",
        Path.home() / "Downloads/StepMail-0.1 2/data/stepmail.db",
        Path.home() / "Library/Application Support/StepMail/stepmail.db",
    ]
    with DB_LOCK, get_db() as conn:
        count = conn.execute("SELECT COUNT(*) c FROM users").fetchone()["c"]
        if count > 0:
            return # Already has users

        for cand in candidates:
            if cand.exists():
                try:
                    src_conn = sqlite3.connect(str(cand))
                    src_conn.row_factory = sqlite3.Row
                    users = src_conn.execute("SELECT * FROM users").fetchall()
                    for u_row in users:
                        u = dict(u_row)
                        conn.execute(
                            "INSERT OR IGNORE INTO users(id, handle, email, display_name, password_hash, created_at) VALUES (?,?,?,?,?,?)",
                            (u["id"], u["handle"], u["email"], u["display_name"], u["password_hash"], u["created_at"])
                        )
                    msgs = src_conn.execute("SELECT * FROM messages").fetchall()
                    for m_row in msgs:
                        m = dict(m_row)
                        conn.execute(
                            """INSERT OR IGNORE INTO messages(id, owner_user_id, folder, sender, recipient, subject, body_text, body_html, is_read, created_at, external_status)
                               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                            (m["id"], m["owner_user_id"], m["folder"], m["sender"], m["recipient"], m["subject"], m["body_text"], m.get("body_html", ""), m["is_read"], m["created_at"], m.get("external_status", ""))
                        )
                    conn.commit()
                    src_conn.close()
                    print(f"[*] Successfully imported legacy database from {cand}")
                    return
                except Exception as e:
                    print(f"[!] Note on legacy import: {e}")

# -----------------------------------------------------------------------------
# DKIM Key Generation & Message Signing
# -----------------------------------------------------------------------------

def ensure_dkim_keys():
    """Ensures 2048-bit RSA DKIM keys exist for stepmail.media."""
    if not HAS_CRYPTO:
        return
    with DB_LOCK, get_db() as conn:
        row = conn.execute("SELECT * FROM dkim_keys WHERE domain = ?", (DOMAIN,)).fetchone()
        if row:
            return

        private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        priv_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        ).decode("utf-8")

        pub_key = private_key.public_key()
        pub_der = pub_key.public_bytes(
            encoding=serialization.Encoding.DER,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        pub_b64 = base64.b64encode(pub_der).decode("utf-8")
        dns_txt = f"v=DKIM1; k=rsa; p={pub_b64}"

        conn.execute(
            "INSERT INTO dkim_keys(domain, selector, private_key_pem, public_key_pem, dns_txt_record, created_at) VALUES (?,?,?,?,?,?)",
            (DOMAIN, DKIM_SELECTOR, priv_pem, pub_b64, dns_txt, int(time.time()))
        )
        conn.commit()
        print(f"[*] Generated new 2048-bit DKIM keypair for {DOMAIN} (selector: {DKIM_SELECTOR})")

def get_dkim_info() -> Optional[Dict[str, str]]:
    with get_db() as conn:
        row = conn.execute("SELECT * FROM dkim_keys WHERE domain = ?", (DOMAIN,)).fetchone()
        if row:
            return dict(row)
    return None

def sign_dkim(raw_email_bytes: bytes) -> bytes:
    """Signs an email with DKIM using the domain's RSA key according to RFC 6376."""
    if not HAS_CRYPTO:
        return raw_email_bytes
    dkim_info = get_dkim_info()
    if not dkim_info:
        return raw_email_bytes

    try:
        # Canonicalize body (relaxed)
        parts = raw_email_bytes.split(b"\r\n\r\n", 1)
        if len(parts) == 2:
            headers_raw, body_raw = parts
        else:
            headers_raw, body_raw = raw_email_bytes, b""

        # Relaxed body canonicalization:
        # Reduce all sequences of whitespace within a line to a single SP character.
        # Remove all trailing whitespace from each line.
        # Remove empty lines at the end.
        lines = body_raw.split(b"\r\n")
        canon_lines = []
        for line in lines:
            line_str = re.sub(rb"[ \t]+", b" ", line).strip(b" \t")
            canon_lines.append(line_str)
        while canon_lines and canon_lines[-1] == b"":
            canon_lines.pop()
        canon_body = b"\r\n".join(canon_lines) + (b"\r\n" if canon_lines else b"")
        body_hash = base64.b64encode(hashlib.sha256(canon_body).digest()).decode("ascii")

        # Headers to sign
        sign_headers = ["from", "to", "subject", "date", "message-id"]
        parsed_msg = email.message_from_bytes(raw_email_bytes)
        
        h_tag = ":".join([h for h in sign_headers if h in parsed_msg])
        dkim_header_tmpl = (
            f"v=1; a=rsa-sha256; c=relaxed/relaxed; d={DOMAIN}; s={DKIM_SELECTOR}; "
            f"t={int(time.time())}; bh={body_hash}; h={h_tag}; b="
        )

        # Canonicalize headers
        canon_headers = []
        for h in sign_headers:
            val = parsed_msg.get(h)
            if val:
                # Relaxed header: lower-case name, replace whitespace sequence with single space
                clean_val = re.sub(r"\s+", " ", val).strip()
                canon_headers.append(f"{h.lower()}:{clean_val}".encode("utf-8"))
        
        canon_headers.append(f"dkim-signature:{re.sub(r'\s+', ' ', dkim_header_tmpl).strip()}".encode("utf-8"))
        header_data_to_sign = b"\r\n".join(canon_headers)

        priv_key = serialization.load_pem_private_key(
            dkim_info["private_key_pem"].encode("utf-8"),
            password=None
        )
        signature = priv_key.sign(
            header_data_to_sign,
            padding.PKCS1v15(),
            hashes.SHA256()
        )
        sig_b64 = base64.b64encode(signature).decode("ascii")
        full_dkim_header = f"DKIM-Signature: {dkim_header_tmpl}{sig_b64}\r\n".encode("utf-8")

        return full_dkim_header + raw_email_bytes
    except Exception as e:
        print(f"[!] DKIM signing error: {e}")
        return raw_email_bytes

# -----------------------------------------------------------------------------
# Security & Authentication Helpers
# -----------------------------------------------------------------------------

def hash_password(password: str, salt: Optional[bytes] = None) -> str:
    if salt is None:
        salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 240_000)
    return f"pbkdf2_sha256$240000${base64.b64encode(salt).decode()}${base64.b64encode(dk).decode()}"

def verify_password(password: str, encoded: str) -> bool:
    try:
        alg, iterations, salt_b64, digest_b64 = encoded.split("$", 3)
        if alg != "pbkdf2_sha256":
            return False
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(digest_b64)
        actual = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, int(iterations))
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False

def clean_handle(value: str) -> Optional[str]:
    v = (value or "").strip().lower()
    allowed = set("abcdefghijklmnopqrstuvwxyz0123456789._-")
    if not (3 <= len(v) <= 32) or any(ch not in allowed for ch in v) or v[0] in ".-_" or v[-1] in ".-_":
        return None
    return v

def normalize_email(value: str) -> Optional[str]:
    v = (value or "").strip().lower()
    if "@" not in v or v.count("@") != 1:
        return None
    local, dom = v.split("@", 1)
    if not local or not dom or "." not in dom:
        return None
    return v

def create_session(user_id: int) -> str:
    token = secrets.token_urlsafe(32)
    t_hash = hashlib.sha256(token.encode()).hexdigest()
    with DB_LOCK, get_db() as conn:
        conn.execute("DELETE FROM sessions WHERE expires_at < ?", (int(time.time()),))
        conn.execute(
            "INSERT INTO sessions(token_hash, user_id, expires_at) VALUES(?,?,?)",
            (t_hash, user_id, int(time.time()) + SESSION_TTL)
        )
        conn.commit()
    return token

def user_from_token(token: str) -> Optional[Dict]:
    if not token:
        return None
    t_hash = hashlib.sha256(token.encode()).hexdigest()
    with get_db() as conn:
        row = conn.execute(
            """SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id
               WHERE s.token_hash=? AND s.expires_at>?""",
            (t_hash, int(time.time()))
        ).fetchone()
        return dict(row) if row else None

# -----------------------------------------------------------------------------
# Local Mail Delivery Engine
# -----------------------------------------------------------------------------

def deliver_locally(sender: str, recipient: str, subject: str, body_text: str,
                    body_html: str = "", message_id: str = "", in_reply_to: str = "",
                    references: str = "", attachments: Optional[List[Dict]] = None) -> Tuple[bool, str, int]:
    """Delivers an incoming or local message into the recipient's StepMail Inbox."""
    clean_rcpt = normalize_email(recipient)
    if not clean_rcpt or not clean_rcpt.endswith("@" + DOMAIN):
        return False, "Recipient is not a stepmail.media address", 0

    with DB_LOCK, get_db() as conn:
        target = conn.execute("SELECT * FROM users WHERE email = ? COLLATE NOCASE", (clean_rcpt,)).fetchone()
        if not target:
            return False, f"550 5.1.1 Mailbox not found: <{clean_rcpt}>", 0

        now_ts = int(time.time())
        msg_id_val = message_id or f"<{secrets.token_hex(12)}.{now_ts}@{DOMAIN}>"

        cur = conn.execute(
            """INSERT INTO messages(owner_user_id, folder, sender, recipient, subject,
                                    body_text, body_html, is_read, created_at, external_status,
                                    message_id, in_reply_to, references_header)
               VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, 'delivered', ?, ?, ?)""",
            (target["id"], "inbox", sender, clean_rcpt, subject, body_text, body_html,
             now_ts, msg_id_val, in_reply_to, references)
        )
        msg_pk = cur.lastrowid

        if attachments:
            for att in attachments:
                conn.execute(
                    """INSERT INTO attachments(message_id, filename, content_type, size, storage_path, created_at)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (msg_pk, att["filename"], att["content_type"], att["size"], att["storage_path"], now_ts)
                )

        conn.commit()
        return True, "Message delivered to inbox", msg_pk

# -----------------------------------------------------------------------------
# Outbound SMTP Delivery Engine & Queue Worker
# -----------------------------------------------------------------------------

def parse_mime_to_dict(raw_bytes: bytes) -> Dict:
    """Parses raw RFC 5322 MIME bytes into structured email fields & saves attachments."""
    msg = email.message_from_bytes(raw_bytes, policy=email.policy.default)
    sender = str(msg.get("From", ""))
    recipient = str(msg.get("To", ""))
    cc = str(msg.get("Cc", ""))
    bcc = str(msg.get("Bcc", ""))
    subject = str(msg.get("Subject", ""))
    message_id = str(msg.get("Message-ID", ""))
    in_reply_to = str(msg.get("In-Reply-To", ""))
    references = str(msg.get("References", ""))

    body_text = ""
    body_html = ""
    attachments = []

    if msg.is_multipart():
        for part in msg.walk():
            fn = part.get_filename()
            ctype = part.get_content_type()
            cdisp = str(part.get("Content-Disposition", ""))

            if fn or "attachment" in cdisp:
                payload = part.get_payload(decode=True) or b""
                filename = fn or f"attachment_{len(attachments)+1}"
                safe_name = f"{int(time.time())}_{secrets.token_hex(6)}_{filename}"
                storage_path = str(ATTACHMENTS_DIR / safe_name)
                with open(storage_path, "wb") as f:
                    f.write(payload)
                attachments.append({
                    "filename": filename,
                    "content_type": ctype,
                    "size": len(payload),
                    "storage_path": storage_path
                })
            elif ctype == "text/plain" and not body_text:
                body_text = part.get_content()
            elif ctype == "text/html" and not body_html:
                body_html = part.get_content()
    else:
        ctype = msg.get_content_type()
        if ctype == "text/html":
            body_html = msg.get_content()
        else:
            body_text = msg.get_content()

    return {
        "sender": sender,
        "recipient": recipient,
        "cc": cc,
        "bcc": bcc,
        "subject": subject,
        "body_text": body_text,
        "body_html": body_html,
        "message_id": message_id,
        "in_reply_to": in_reply_to,
        "references": references,
        "attachments": attachments
    }

def enqueue_outbound_message(sender: str, recipients: List[str], subject: str, raw_mime: bytes) -> int:
    with DB_LOCK, get_db() as conn:
        cur = conn.execute(
            """INSERT INTO outgoing_queue(sender, recipients, subject, raw_mime, status, retries, created_at)
               VALUES (?, ?, ?, ?, 'queued', 0, ?)""",
            (sender, json.dumps(recipients), subject, raw_mime, int(time.time()))
        )
        conn.commit()
        return cur.lastrowid

def resolve_mx(domain: str) -> List[str]:
    """Looks up MX records for a domain using system DNS."""
    try:
        # Prefer direct host query via socket / dig fallback
        proc = subprocess_dns_mx(domain)
        if proc:
            return proc
    except Exception:
        pass
    return [domain] # Fallback to A record

def query_dns_record(name: str, record_type: str) -> List[str]:
    """Queries DNS records using dig with fallback to system resolver."""
    import subprocess
    try:
        res = subprocess.run(["dig", "+short", "+time=2", "+tries=1", record_type, name], capture_output=True, text=True, timeout=3)
        lines = [line.strip().strip('"') for line in res.stdout.strip().split("\n") if line.strip()]
        return lines
    except Exception:
        return []

def query_ptr(ip_addr: str) -> Optional[str]:
    """Queries reverse DNS (PTR) for an IP address."""
    import subprocess
    try:
        res = subprocess.run(["dig", "+short", "+time=2", "+tries=1", "-x", ip_addr], capture_output=True, text=True, timeout=3)
        val = res.stdout.strip().rstrip(".")
        return val if val else None
    except Exception:
        return None

def subprocess_dns_mx(domain: str) -> List[str]:
    records = query_dns_record(domain, "MX")
    mxs = []
    for line in records:
        parts = line.split()
        if len(parts) >= 2:
            mxs.append(parts[1].rstrip("."))
        elif len(parts) == 1 and not parts[0].isdigit():
            mxs.append(parts[0].rstrip("."))
    return mxs

def perform_live_diagnostics() -> Dict[str, Any]:
    """Performs live public DNS checks, deliverability audits, queue metrics, and service checks."""
    dkim_info = get_dkim_info()
    relay = get_relay_config()

    # 1. Check A record for mail.stepmail.media
    a_records = query_dns_record(HOSTNAME, "A")
    a_status = "verified" if a_records else "missing"
    public_ip = a_records[0] if a_records else "109.144.28.25"

    # 2. Check PTR for public IP
    ptr_val = query_ptr(public_ip) if a_records else None
    if ptr_val and ptr_val.lower() == HOSTNAME.lower():
        ptr_status = "verified"
    elif ptr_val:
        ptr_status = "incorrect"
    else:
        ptr_status = "missing"

    # 3. Check MX for stepmail.media
    mx_records = query_dns_record(DOMAIN, "MX")
    mx_verified = any(HOSTNAME in mx for mx in mx_records) if mx_records else False
    mx_status = "verified" if mx_verified else ("incorrect" if mx_records else "missing")

    # 4. Check SPF
    txt_records = query_dns_record(DOMAIN, "TXT")
    spf_record = next((t for t in txt_records if "v=spf1" in t), None)
    if spf_record:
        spf_status = "pass" if f"a:{HOSTNAME}" in spf_record or "mx" in spf_record else "incorrect"
    else:
        spf_status = "missing"

    # 5. Check DKIM
    dkim_dns_records = query_dns_record(f"{DKIM_SELECTOR}._domainkey.{DOMAIN}", "TXT")
    dkim_published = next((t for t in dkim_dns_records if "v=DKIM1" in t), None)
    if dkim_published and dkim_info and dkim_info["public_key_pem"] in dkim_published:
        dkim_status = "pass"
    elif dkim_published:
        dkim_status = "incorrect"
    else:
        dkim_status = "missing"

    # 6. Check DMARC
    dmarc_records = query_dns_record(f"_dmarc.{DOMAIN}", "TXT")
    dmarc_record = next((t for t in dmarc_records if "v=DMARC1" in t), None)
    dmarc_status = "configured" if dmarc_record else "missing"

    # 7. Queue Metrics
    with get_db() as conn:
        q_rows = conn.execute("SELECT status, COUNT(*) c FROM outgoing_queue GROUP BY status").fetchall()
        q_counts = {r["status"]: r["c"] for r in q_rows}
        last_outbound = conn.execute("SELECT value FROM server_config WHERE key='last_successful_outbound'").fetchone()
        last_inbound = conn.execute("SELECT value FROM server_config WHERE key='last_successful_inbound'").fetchone()
        q_jobs = [dict(r) for r in conn.execute("SELECT id, sender, recipients, subject, status, retries, next_attempt, last_attempt, last_error, created_at FROM outgoing_queue ORDER BY id DESC LIMIT 25").fetchall()]

    return {
        "domain": DOMAIN,
        "hostname": HOSTNAME,
        "staticIP": public_ip,
        "localEngine": "operational",
        "publicServer": {
            "connected": a_status == "verified" and mx_status == "verified",
            "hostname": HOSTNAME,
            "ip": public_ip
        },
        "dns": {
            "a": {"status": a_status, "expected": public_ip, "observed": a_records or None},
            "ptr": {"status": ptr_status, "expected": HOSTNAME, "observed": ptr_val},
            "mx": {"status": mx_status, "expected": f"10 {HOSTNAME}.", "observed": mx_records or None},
            "spf": {"status": spf_status, "expected": f"v=spf1 mx a:{HOSTNAME} -all", "observed": spf_record},
            "dkim": {"status": dkim_status, "selector": DKIM_SELECTOR, "expected_prefix": "v=DKIM1; k=rsa; p=", "observed": dkim_published},
            "dmarc": {"status": dmarc_status, "expected": f"v=DMARC1; p=none; rua=mailto:dmarc@{DOMAIN}; fo=1", "observed": dmarc_record}
        },
        "services": {
            "inboundSMTP": {"status": "operational", "port": SMTP_PORT},
            "outboundSMTP": {"status": "operational", "port": 25},
            "submission": {"status": "operational", "port": SUBMISSION_PORT},
            "httpAPI": {"status": "operational", "port": HTTP_PORT},
            "openRelay": {"status": "protected"}
        },
        "queue": {
            "total": sum(q_counts.values()),
            "queued": q_counts.get("queued", 0),
            "sending": q_counts.get("sending", 0),
            "accepted": q_counts.get("accepted_by_remote_mx", 0) + q_counts.get("delivered", 0),
            "deferred": q_counts.get("deferred", 0) + q_counts.get("retrying", 0),
            "rejected": q_counts.get("rejected", 0),
            "bounced": q_counts.get("bounced", 0),
            "failed": q_counts.get("failed", 0),
            "lastOutboundSuccess": int(last_outbound["value"]) if last_outbound else None,
            "lastInboundSuccess": int(last_inbound["value"]) if last_inbound else None,
            "jobs": q_jobs
        }
    }

def get_ssl_context() -> ssl.SSLContext:
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()

def get_relay_config() -> Optional[Dict[str, Any]]:
    with get_db() as conn:
        rows = conn.execute("SELECT key, value FROM server_config WHERE key LIKE 'relay_%'").fetchall()
        config = {r["key"]: r["value"] for r in rows}
    if config.get("relay_host") and config.get("relay_user") and config.get("relay_pass"):
        return {
            "host": config["relay_host"],
            "port": int(config.get("relay_port", 587)),
            "user": config["relay_user"],
            "pass": config["relay_pass"],
            "security": config.get("relay_security", "starttls").lower()
        }
    if FALLBACK_SMTP_HOST and FALLBACK_SMTP_USER and FALLBACK_SMTP_PASS:
        return {
            "host": FALLBACK_SMTP_HOST,
            "port": FALLBACK_SMTP_PORT,
            "user": FALLBACK_SMTP_USER,
            "pass": FALLBACK_SMTP_PASS,
            "security": FALLBACK_SMTP_SECURITY
        }
    return None

def generate_dsn_bounce(original_sender: str, recipients: List[str], subject: str, error_detail: str, smtp_code: int = 550, original_message_id: str = ""):
    """Generates an RFC 3464 compliant Delivery Status Notification bounce in the sender's mailbox."""
    bounce_sender = f"mailer-daemon@{DOMAIN}"
    rcpt_str = ", ".join(recipients)
    now_ts = int(time.time())

    body_text = f"""This is the StepMail Mail Delivery System at {HOSTNAME}.

Your message could not be delivered to the following recipient(s):

Recipient: {rcpt_str}
Diagnostic-Code: SMTP {smtp_code} {error_detail}
Status: Permanent Delivery Failure

----------------------------------------------------------------------
Original Message Details:
Subject: {subject}
Message-ID: {original_message_id}
Submitted: {time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime(now_ts))}

StepMail will not attempt further delivery for this message.
"""
    deliver_locally(
        sender=bounce_sender,
        recipient=original_sender,
        subject=f"Undelivered Mail Returned to Sender: {subject}",
        body_text=body_text
    )

def deliver_outgoing_job(job_id: int, sender: str, recipients: List[str], raw_mime: bytes) -> Tuple[bool, str, bool, int]:
    """Attempts direct SMTP MX delivery or configured relay submission for a queued message.
       Returns: (success: bool, detail: str, is_permanent: bool, smtp_code: int)
    """
    signed_mime = sign_dkim(raw_mime)
    relay = get_relay_config()

    # 1. If relay is configured
    if relay:
        try:
            context = get_ssl_context()
            if relay["security"] == "ssl":
                with smtplib.SMTP_SSL(relay["host"], relay["port"], context=context, timeout=25) as client:
                    client.login(relay["user"], relay["pass"])
                    client.sendmail(sender, recipients, signed_mime)
            else:
                with smtplib.SMTP(relay["host"], relay["port"], timeout=25) as client:
                    client.ehlo(HOSTNAME)
                    if relay["security"] == "starttls":
                        client.starttls(context=context)
                        client.ehlo(HOSTNAME)
                    client.login(relay["user"], relay["pass"])
                    client.sendmail(sender, recipients, signed_mime)
            return True, f"Accepted by relay ({relay['host']})", False, 250
        except smtplib.SMTPResponseException as e:
            err_text = e.smtp_error.decode("utf-8", errors="ignore") if isinstance(e.smtp_error, bytes) else str(e.smtp_error)
            is_perm = e.smtp_code >= 500
            return False, f"Relay error ({relay['host']}): {e.smtp_code} {err_text}", is_perm, e.smtp_code
        except Exception as e:
            return False, f"Relay network error ({relay['host']}): {e}", False, 451

    # 2. Direct MX delivery to each recipient's destination mail server
    errors = []
    delivered_count = 0
    domains = {}
    is_perm_any = False
    last_code = 451

    for r in recipients:
        if "@" in r:
            dom = r.split("@", 1)[1].lower()
            domains.setdefault(dom, []).append(r)

    for dom, rcpt_list in domains.items():
        mxs = resolve_mx(dom)
        success = False
        last_dom_err = ""
        dom_perm = False
        dom_code = 451

        for mx in mxs:
            try:
                with smtplib.SMTP(mx, 25, timeout=20) as client:
                    client.ehlo(HOSTNAME)
                    try:
                        ctx = get_ssl_context()
                        client.starttls(context=ctx)
                        client.ehlo(HOSTNAME)
                    except Exception as tls_err:
                        print(f"[*] Note: STARTTLS on {mx}: {tls_err}")
                    client.sendmail(sender, rcpt_list, signed_mime)
                    success = True
                    delivered_count += len(rcpt_list)
                    break
            except smtplib.SMTPResponseException as e:
                err_text = e.smtp_error.decode("utf-8", errors="ignore") if isinstance(e.smtp_error, bytes) else str(e.smtp_error)
                dom_code = e.smtp_code
                dom_perm = e.smtp_code >= 500
                last_dom_err = f"{mx}: SMTP {e.smtp_code} {err_text.strip()}"
            except Exception as e:
                dom_code = 451
                dom_perm = False
                last_dom_err = f"{mx}: {type(e).__name__}: {e}"

        if not success:
            if dom_perm:
                is_perm_any = True
            last_code = dom_code
            errors.append(f"{dom} -> {last_dom_err or 'No MX reachable'}")

    if errors:
        return False, "; ".join(errors), is_perm_any, last_code
    return True, f"Accepted by recipient mail server ({delivered_count} recipient(s))", False, 250

def queue_worker_loop():
    """Background worker thread processing outbound message queue with exponential backoff & DSN bounces."""
    while True:
        try:
            now_ts = int(time.time())
            with DB_LOCK, get_db() as conn:
                jobs = conn.execute(
                    """SELECT * FROM outgoing_queue
                       WHERE status IN ('queued', 'deferred')
                         AND next_attempt <= ?
                         AND retries < 6
                       ORDER BY id ASC LIMIT 5""",
                    (now_ts,)
                ).fetchall()

            for job in jobs:
                job_id = job["id"]
                sender = job["sender"]
                recipients = json.loads(job["recipients"])
                raw_mime = job["raw_mime"]
                retries = job["retries"]
                subject = job["subject"]

                # Mark sending
                with DB_LOCK, get_db() as conn:
                    conn.execute("UPDATE outgoing_queue SET status='sending' WHERE id=?", (job_id,))
                    conn.commit()

                ok, detail, is_perm, smtp_code = deliver_outgoing_job(job_id, sender, recipients, raw_mime)

                with DB_LOCK, get_db() as conn:
                    if ok:
                        conn.execute(
                            """UPDATE outgoing_queue
                               SET status='accepted_by_remote_mx', last_error=?, last_attempt=?, smtp_code=250
                               WHERE id=?""",
                            (detail, int(time.time()), job_id)
                        )
                        conn.execute(
                            """UPDATE messages
                               SET external_status=?
                               WHERE sender=? AND folder='sent' AND created_at >= ?""",
                            (f"accepted_by_remote_mx: {detail}", sender, job["created_at"] - 60)
                        )
                        conn.execute(
                            "INSERT OR REPLACE INTO server_config(key, value) VALUES ('last_successful_outbound', ?)",
                            (str(int(time.time())),)
                        )
                    elif is_perm or (retries + 1 >= 6):
                        new_status = 'rejected' if is_perm else 'bounced'
                        conn.execute(
                            """UPDATE outgoing_queue
                               SET status=?, retries=?, last_error=?, last_attempt=?, is_permanent=1, smtp_code=?
                               WHERE id=?""",
                            (new_status, retries + 1, detail, int(time.time()), smtp_code, job_id)
                        )
                        conn.execute(
                            """UPDATE messages
                               SET external_status=?
                               WHERE sender=? AND folder='sent' AND created_at >= ?""",
                            (f"{new_status}: {detail}", sender, job["created_at"] - 60)
                        )
                        generate_dsn_bounce(
                            original_sender=sender,
                            recipients=recipients,
                            subject=subject,
                            error_detail=detail,
                            smtp_code=smtp_code
                        )
                    else:
                        delay_secs = min(24 * 3600, (3 ** retries) * 60)
                        next_ts = int(time.time()) + delay_secs
                        conn.execute(
                            """UPDATE outgoing_queue
                               SET status='deferred', retries=?, next_attempt=?, last_error=?, last_attempt=?, smtp_code=?
                               WHERE id=?""",
                            (retries + 1, next_ts, detail, int(time.time()), smtp_code, job_id)
                        )
                        conn.execute(
                            """UPDATE messages
                               SET external_status=?
                               WHERE sender=? AND folder='sent' AND created_at >= ?""",
                            (f"deferred: {detail} (retry scheduled in {delay_secs//60}m)", sender, job["created_at"] - 60)
                        )
                    conn.commit()
        except Exception as e:
            print(f"[!] Queue worker exception: {e}")
        time.sleep(3)

# -----------------------------------------------------------------------------
# SMTP Server Implementation (RFC 5321 / RFC 6409)
# -----------------------------------------------------------------------------

class SMTPProtocol(asyncio.Protocol):
    def __init__(self, is_submission: bool = False):
        self.is_submission = is_submission
        self.transport = None
        self.peer = None
        self.helo_name = None
        self.mail_from = None
        self.rcpt_tos = []
        self.authenticated_user = None
        self.auth_state = None
        self.auth_type = None
        self.data_mode = False
        self.data_buffer = bytearray()

    def connection_made(self, transport):
        self.transport = transport
        self.peer = transport.get_extra_info("peername")
        self.send_line(f"220 {DOMAIN} StepMail ESMTP Server ready")

    def send_line(self, line: str):
        if self.transport:
            self.transport.write((line + "\r\n").encode("utf-8"))

    def data_received(self, data: bytes):
        if self.data_mode:
            self.data_buffer.extend(data)
            if b"\r\n.\r\n" in self.data_buffer or self.data_buffer.endswith(b"\n.\n") or self.data_buffer == b".\r\n":
                # End of DATA stream
                dot_idx = self.data_buffer.find(b"\r\n.\r\n")
                if dot_idx != -1:
                    raw_msg = bytes(self.data_buffer[:dot_idx])
                else:
                    raw_msg = bytes(self.data_buffer.rstrip(b"\r\n."))
                self.data_mode = False
                self.data_buffer.clear()
                self.process_message(raw_msg)
            return

        lines = data.decode("utf-8", errors="ignore").split("\r\n")
        for line in lines:
            line = line.strip()
            if not line:
                continue
            self.handle_command(line)

    def handle_command(self, line: str):
        parts = line.split(" ", 1)
        cmd = parts[0].upper()
        arg = parts[1] if len(parts) > 1 else ""

        if self.auth_state == "PLAIN":
            self.handle_auth_plain_payload(line)
            return
        elif self.auth_state == "LOGIN_USER":
            self.auth_user_candidate = base64.b64decode(line).decode("utf-8", errors="ignore")
            self.auth_state = "LOGIN_PASS"
            self.send_line("334 UGFzc3dvcmQ6") # Base64 for 'Password:'
            return
        elif self.auth_state == "LOGIN_PASS":
            password = base64.b64decode(line).decode("utf-8", errors="ignore")
            self.finish_auth_login(self.auth_user_candidate, password)
            return

        if cmd in ("EHLO", "HELO"):
            self.helo_name = arg
            self.send_line(f"250-{DOMAIN} Hello {arg or 'friend'}")
            self.send_line("250-SIZE 26214400")
            self.send_line("250-8BITMIME")
            self.send_line("250-AUTH PLAIN LOGIN")
            self.send_line("250 HELP")
        elif cmd == "AUTH":
            self.handle_auth(arg)
        elif cmd == "MAIL":
            if not arg.upper().startswith("FROM:"):
                self.send_line("501 5.5.4 Syntax: MAIL FROM:<address>")
                return
            raw_addr = arg[5:].strip().strip("<>")
            self.mail_from = normalize_email(raw_addr) or raw_addr
            self.rcpt_tos = []
            self.send_line("250 2.1.0 Sender OK")
        elif cmd == "RCPT":
            if not arg.upper().startswith("TO:"):
                self.send_line("501 5.5.4 Syntax: RCPT TO:<address>")
                return
            raw_addr = arg[3:].strip().strip("<>")
            rcpt = normalize_email(raw_addr) or raw_addr

            # --- CRITICAL ANTI-OPEN-RELAY CHECK ---
            is_local = rcpt.endswith("@" + DOMAIN)
            if not self.authenticated_user and not is_local:
                # Unauthenticated sender attempting to relay to external domain
                self.send_line("550 5.7.1 Relaying denied: Authentication required to send to external recipients")
                return

            if is_local:
                # Recipient validation: must exist in database
                with get_db() as conn:
                    target = conn.execute("SELECT id FROM users WHERE email = ? COLLATE NOCASE", (rcpt,)).fetchone()
                if not target:
                    self.send_line(f"550 5.1.1 User unknown: <{rcpt}>")
                    return

            self.rcpt_tos.append(rcpt)
            self.send_line("250 2.1.5 Recipient OK")
        elif cmd == "DATA":
            if not self.mail_from:
                self.send_line("503 5.5.1 Error: need MAIL command")
                return
            if not self.rcpt_tos:
                self.send_line("503 5.5.1 Error: need RCPT command")
                return
            self.data_mode = True
            self.data_buffer.clear()
            self.send_line("354 Start mail input; end with <CRLF>.<CRLF>")
        elif cmd == "RSET":
            self.mail_from = None
            self.rcpt_tos = []
            self.data_mode = False
            self.send_line("250 2.0.0 Reset OK")
        elif cmd == "NOOP":
            self.send_line("250 2.0.0 OK")
        elif cmd == "QUIT":
            self.send_line("221 2.0.0 Bye")
            self.transport.close()
        else:
            self.send_line("502 5.5.2 Command not recognized")

    def handle_auth(self, arg: str):
        parts = arg.split(" ", 1)
        mechanism = parts[0].upper()
        payload = parts[1] if len(parts) > 1 else ""

        if mechanism == "PLAIN":
            if payload:
                self.handle_auth_plain_payload(payload)
            else:
                self.auth_state = "PLAIN"
                self.send_line("334 ")
        elif mechanism == "LOGIN":
            if payload:
                self.auth_user_candidate = base64.b64decode(payload).decode("utf-8", errors="ignore")
                self.auth_state = "LOGIN_PASS"
                self.send_line("334 UGFzc3dvcmQ6")
            else:
                self.auth_state = "LOGIN_USER"
                self.send_line("334 VXNlcm5hbWU6") # Base64 for 'Username:'
        else:
            self.send_line("504 5.7.4 Unrecognized authentication type")

    def handle_auth_plain_payload(self, b64_payload: str):
        try:
            decoded = base64.b64decode(b64_payload).decode("utf-8", errors="ignore")
            parts = decoded.split("\x00")
            # Format: authzid\0authcid\0passwd
            if len(parts) >= 3:
                username, password = parts[1], parts[2]
            else:
                username, password = parts[0], parts[1]
            self.verify_and_set_auth(username, password)
        except Exception:
            self.send_line("535 5.7.8 Authentication credentials invalid")
        finally:
            self.auth_state = None

    def finish_auth_login(self, username: str, password: str):
        self.verify_and_set_auth(username, password)
        self.auth_state = None

    def verify_and_set_auth(self, username: str, password: str):
        with get_db() as conn:
            if "@" in username:
                row = conn.execute("SELECT * FROM users WHERE email=? COLLATE NOCASE", (username,)).fetchone()
            else:
                row = conn.execute("SELECT * FROM users WHERE handle=? COLLATE NOCASE", (username,)).fetchone()
        if row and verify_password(password, row["password_hash"]):
            self.authenticated_user = dict(row)
            self.send_line("235 2.7.0 Authentication successful")
        else:
            self.send_line("535 5.7.8 Authentication credentials invalid")

    def process_message(self, raw_bytes: bytes):
        try:
            parsed = parse_mime_to_dict(raw_bytes)
            subject = parsed["subject"]
            body_text = parsed["body_text"]
            body_html = parsed["body_html"]
            message_id = parsed["message_id"] or f"<{secrets.token_hex(12)}@{DOMAIN}>"
            in_reply_to = parsed["in_reply_to"]
            references = parsed["references"]
            attachments = parsed["attachments"]

            # Separate local vs external recipients
            local_rcpts = [r for r in self.rcpt_tos if r.endswith("@" + DOMAIN)]
            external_rcpts = [r for r in self.rcpt_tos if not r.endswith("@" + DOMAIN)]

            # 1. Deliver to local mailboxes
            for rcpt in local_rcpts:
                deliver_locally(
                    sender=self.mail_from,
                    recipient=rcpt,
                    subject=subject,
                    body_text=body_text,
                    body_html=body_html,
                    message_id=message_id,
                    in_reply_to=in_reply_to,
                    references=references,
                    attachments=attachments
                )

            # 2. If sender is authenticated and there are external recipients, enqueue for delivery & save in Sent
            if self.authenticated_user and external_rcpts:
                enqueue_outbound_message(
                    sender=self.mail_from,
                    recipients=external_rcpts,
                    subject=subject,
                    raw_mime=raw_bytes
                )
                with DB_LOCK, get_db() as conn:
                    conn.execute(
                        """INSERT INTO messages(owner_user_id, folder, sender, recipient, subject,
                                                body_text, body_html, is_read, created_at, external_status,
                                                message_id, in_reply_to, references_header)
                           VALUES (?, 'sent', ?, ?, ?, ?, ?, 1, ?, 'queued', ?, ?, ?)""",
                        (self.authenticated_user["id"], self.mail_from, ", ".join(external_rcpts),
                         subject, body_text, body_html, int(time.time()), message_id, in_reply_to, references)
                    )
                    conn.commit()

            self.send_line("250 2.0.0 Message accepted for delivery")
        except Exception as e:
            print(f"[!] Error processing SMTP message: {e}")
            self.send_line(f"451 4.3.0 Local error in processing: {e}")
        finally:
            self.mail_from = None
            self.rcpt_tos = []

# -----------------------------------------------------------------------------
# REST Mailbox & Admin API
# -----------------------------------------------------------------------------

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

class StepMailHTTPHandler(BaseHTTPRequestHandler):
    server_version = "StepMail-Server/1.3.0"

    def log_message(self, fmt, *args):
        sys.stdout.write(f"[{self.log_date_time_string()}] {fmt % args}\n")

    def _headers(self, status=200, content_type="application/json; charset=utf-8", length=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type, X-StepMail-Secret")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if length is not None:
            self.send_header("Content-Length", str(length))
        self.end_headers()

    def do_OPTIONS(self):
        self._headers(200)

    def json_resp(self, payload, status=200):
        data = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        self._headers(status, length=len(data))
        self.wfile.write(data)

    def read_json_body(self) -> Optional[Dict]:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length <= 0 or length > MAX_BODY_SIZE:
            return None
        try:
            return json.loads(self.rfile.read(length).decode("utf-8"))
        except Exception:
            return None

    def get_bearer_token(self) -> str:
        auth = self.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            return auth[7:].strip()
        return ""

    def authenticate_user(self) -> Optional[Dict]:
        user = user_from_token(self.get_bearer_token())
        if not user:
            self.json_resp({"error": "unauthorized"}, 401)
            return None
        return user

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/api/status":
            dkim_info = get_dkim_info()
            with get_db() as conn:
                user_cnt = conn.execute("SELECT COUNT(*) c FROM users").fetchone()["c"]
                msg_cnt = conn.execute("SELECT COUNT(*) c FROM messages").fetchone()["c"]
                q_cnt = conn.execute("SELECT COUNT(*) c FROM outgoing_queue WHERE status='queued'").fetchone()["c"]

            self.json_resp({
                "name": "StepMail",
                "version": "1.3.0",
                "domain": DOMAIN,
                "independent": True,
                "firstAccountOpen": user_cnt == 0,
                "signupsEnabled": ALLOW_SIGNUPS,
                "dkimConfigured": dkim_info is not None,
                "metrics": {
                    "users": user_cnt,
                    "messages": msg_cnt,
                    "queueDepth": q_cnt
                }
            })
            return

        if path == "/api/admin/dns-config":
            user = self.authenticate_user()
            if not user:
                return
            dkim_info = get_dkim_info()
            self.json_resp({
                "domain": DOMAIN,
                "hostname": HOSTNAME,
                "records": [
                    {
                        "type": "A",
                        "name": HOSTNAME,
                        "value": "YOUR_SERVER_PUBLIC_IPV4",
                        "purpose": "Mail server hostname A record"
                    },
                    {
                        "type": "MX",
                        "name": DOMAIN,
                        "value": f"10 {HOSTNAME}.",
                        "purpose": "Primary mail exchange router"
                    },
                    {
                        "type": "TXT",
                        "name": DOMAIN,
                        "value": f"v=spf1 mx a:{HOSTNAME} -all",
                        "purpose": "SPF sender authorization"
                    },
                    {
                        "type": "TXT",
                        "name": f"{DKIM_SELECTOR}._domainkey.{DOMAIN}",
                        "value": dkim_info["dns_txt_record"] if dkim_info else "Generating...",
                        "purpose": "DKIM 2048-bit public signing key"
                    },
                    {
                        "type": "TXT",
                        "name": f"_dmarc.{DOMAIN}",
                        "value": f"v=DMARC1; p=none; rua=mailto:dmarc@{DOMAIN}; fo=1",
                        "purpose": "DMARC deliverability policy"
                    },
                    {
                        "type": "PTR",
                        "name": "YOUR_SERVER_PUBLIC_IPV4",
                        "value": f"{HOSTNAME}.",
                        "purpose": "Reverse DNS (configured at server hosting provider)"
                    }
                ]
            })
            return

        if path == "/api/admin/relay-config":
            user = self.authenticate_user()
            if not user:
                return
            relay = get_relay_config() or {}
            self.json_resp({
                "configured": bool(relay.get("host") and relay.get("user")),
                "host": relay.get("host", ""),
                "port": relay.get("port", 587),
                "user": relay.get("user", ""),
                "security": relay.get("security", "starttls")
            })
            return

        if path == "/api/admin/diagnostics":
            user = self.authenticate_user()
            if not user:
                return
            diag = perform_live_diagnostics()
            self.json_resp(diag)
            return

        if path == "/api/me":
            user = self.authenticate_user()
            if not user:
                return
            self.json_resp({"user": {"id": user["id"], "email": user["email"], "handle": user["handle"], "displayName": user["display_name"]}})
            return

        if path == "/api/messages":
            user = self.authenticate_user()
            if not user:
                return
            q = parse_qs(parsed.query)
            folder = (q.get("folder", ["inbox"])[0] or "inbox").lower()
            search = (q.get("q", [""])[0] or "").strip().lower()

            with get_db() as conn:
                if search:
                    like_str = f"%{search}%"
                    rows = conn.execute(
                        """SELECT * FROM messages
                           WHERE owner_user_id=? AND folder=?
                             AND (subject LIKE ? OR sender LIKE ? OR recipient LIKE ? OR body_text LIKE ?)
                           ORDER BY created_at DESC LIMIT 200""",
                        (user["id"], folder, like_str, like_str, like_str, like_str)
                    ).fetchall()
                else:
                    rows = conn.execute(
                        "SELECT * FROM messages WHERE owner_user_id=? AND folder=? ORDER BY created_at DESC LIMIT 200",
                        (user["id"], folder)
                    ).fetchall()

                messages = []
                for r in rows:
                    d = dict(r)
                    d["is_read"] = bool(d["is_read"])
                    # Attachments count
                    att_count = conn.execute("SELECT COUNT(*) c FROM attachments WHERE message_id=?", (d["id"],)).fetchone()["c"]
                    d["attachments_count"] = att_count
                    messages.append(d)

            self.json_resp({"messages": messages})
            return

        # Single message detail with attachments
        if path.startswith("/api/messages/"):
            parts = path.strip("/").split("/")
            if len(parts) == 3 and parts[2].isdigit():
                user = self.authenticate_user()
                if not user:
                    return
                mid = int(parts[2])
                with get_db() as conn:
                    row = conn.execute("SELECT * FROM messages WHERE id=? AND owner_user_id=?", (mid, user["id"])).fetchone()
                    if not row:
                        self.json_resp({"error": "not_found"}, 404)
                        return
                    msg_dict = dict(row)
                    msg_dict["is_read"] = bool(msg_dict["is_read"])
                    atts = [dict(a) for a in conn.execute("SELECT id, filename, content_type, size, created_at FROM attachments WHERE message_id=?", (mid,)).fetchall()]
                    msg_dict["attachments"] = atts

                self.json_resp({"message": msg_dict})
                return

        self.json_resp({"error": "not_found"}, 404)

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        body = self.read_json_body() or {}

        if path == "/api/register":
            with get_db() as conn:
                user_cnt = conn.execute("SELECT COUNT(*) c FROM users").fetchone()["c"]
            if user_cnt > 0 and not ALLOW_SIGNUPS:
                self.json_resp({"error": "signups_disabled"}, 403)
                return

            handle = clean_handle(body.get("handle"))
            password = body.get("password") or ""
            displayName = (body.get("displayName") or handle or "StepMail User").strip()[:80]

            if not handle:
                self.json_resp({"error": "invalid_handle", "message": "Handle must be 3-32 alphanumeric characters"}, 400)
                return
            if len(password) < 8:
                self.json_resp({"error": "password_too_short", "message": "Password must be at least 8 characters"}, 400)
                return

            email_addr = f"{handle}@{DOMAIN}"
            try:
                with DB_LOCK, get_db() as conn:
                    cur = conn.execute(
                        "INSERT INTO users(handle, email, display_name, password_hash, created_at) VALUES(?,?,?,?,?)",
                        (handle, email_addr, displayName, hash_password(password), int(time.time()))
                    )
                    uid = cur.lastrowid
                    conn.commit()

                # Send welcome message
                welcome_body = (
                    f"Welcome to StepMail!\n\n"
                    f"Your independent email address {email_addr} is ready to use.\n\n"
                    f"StepMail gives you complete control over your messages, attachments, and identity.\n"
                    f"Domain: {DOMAIN}\n"
                )
                deliver_locally(
                    sender=f"welcome@{DOMAIN}",
                    recipient=email_addr,
                    subject="Welcome to StepMail",
                    body_text=welcome_body
                )

                token = create_session(uid)
                self.json_resp({"token": token, "email": email_addr, "user": {"id": uid, "email": email_addr, "handle": handle, "displayName": displayName}}, 201)
            except sqlite3.IntegrityError:
                self.json_resp({"error": "handle_taken", "message": "That handle is already registered."}, 409)
            return

        if path == "/api/login":
            identity = (body.get("identity") or "").strip().lower()
            password = body.get("password") or ""
            with get_db() as conn:
                if "@" in identity:
                    row = conn.execute("SELECT * FROM users WHERE email=? COLLATE NOCASE", (identity,)).fetchone()
                else:
                    row = conn.execute("SELECT * FROM users WHERE handle=? COLLATE NOCASE", (identity,)).fetchone()

            if not row or not verify_password(password, row["password_hash"]):
                self.json_resp({"error": "invalid_credentials", "message": "Invalid email/handle or password"}, 401)
                return

            token = create_session(row["id"])
            self.json_resp({
                "token": token,
                "email": row["email"],
                "user": {"id": row["id"], "email": row["email"], "handle": row["handle"], "displayName": row["display_name"]}
            })
            return

        if path == "/api/logout":
            token = self.get_bearer_token()
            if token:
                t_hash = hashlib.sha256(token.encode()).hexdigest()
                with DB_LOCK, get_db() as conn:
                    conn.execute("DELETE FROM sessions WHERE token_hash=?", (t_hash,))
                    conn.commit()
            self.json_resp({"ok": True})
            return

        if path == "/api/send":
            user = self.authenticate_user()
            if not user:
                return

            raw_to = body.get("to") or ""
            raw_cc = body.get("cc") or ""
            raw_bcc = body.get("bcc") or ""
            subject = (body.get("subject") or "").strip()[:500]
            body_text = body.get("text") or ""
            body_html = body.get("html") or ""
            attachments_in = body.get("attachments") or [] # Base64 encoded payload list: [{"filename": "...", "content_type": "...", "data": "base64..."}]

            recipients = [normalize_email(r) for r in re.split(r"[,\s;]+", raw_to) if r.strip()]
            recipients = [r for r in recipients if r]
            if not recipients:
                self.json_resp({"error": "invalid_recipient", "message": "At least one valid recipient is required"}, 400)
                return

            now_ts = int(time.time())
            msg_id_val = f"<{secrets.token_hex(12)}.{now_ts}@{DOMAIN}>"

            # Build full MIME message
            em = EmailMessage()
            em["From"] = f"{user['display_name']} <{user['email']}>"
            em["To"] = ", ".join(recipients)
            if raw_cc:
                em["Cc"] = raw_cc
            em["Subject"] = subject
            em["Date"] = email.utils.formatdate(localtime=True)
            em["Message-ID"] = msg_id_val

            if body_html:
                em.set_content(body_text or " ")
                em.add_alternative(body_html, subtype="html")
            else:
                em.set_content(body_text or " ")

            processed_attachments = []
            for att in attachments_in:
                fn = att.get("filename", "file")
                ctype = att.get("content_type", "application/octet-stream")
                b64_data = att.get("data", "")
                try:
                    att_bytes = base64.b64decode(b64_data)
                    maintype, subtype = ctype.split("/", 1) if "/" in ctype else ("application", "octet-stream")
                    em.add_attachment(att_bytes, maintype=maintype, subtype=subtype, filename=fn)
                    
                    # Store on disk
                    safe_name = f"{now_ts}_{secrets.token_hex(6)}_{fn}"
                    storage_path = str(ATTACHMENTS_DIR / safe_name)
                    with open(storage_path, "wb") as f:
                        f.write(att_bytes)
                    processed_attachments.append({
                        "filename": fn,
                        "content_type": ctype,
                        "size": len(att_bytes),
                        "storage_path": storage_path
                    })
                except Exception as e:
                    print(f"[!] Attachment decode error: {e}")

            raw_mime = em.as_bytes()

            # Separate local vs external
            local_rcpts = [r for r in recipients if r.endswith("@" + DOMAIN)]
            external_rcpts = [r for r in recipients if not r.endswith("@" + DOMAIN)]

            # Deliver local
            for rcpt in local_rcpts:
                deliver_locally(
                    sender=user["email"],
                    recipient=rcpt,
                    subject=subject,
                    body_text=body_text,
                    body_html=body_html,
                    message_id=msg_id_val,
                    attachments=processed_attachments
                )

            # Enqueue external
            if external_rcpts:
                enqueue_outbound_message(user["email"], external_rcpts, subject, raw_mime)

            # Record in user's Sent folder
            with DB_LOCK, get_db() as conn:
                cur = conn.execute(
                    """INSERT INTO messages(owner_user_id, folder, sender, recipient, cc, bcc,
                                            subject, body_text, body_html, is_read, created_at,
                                            external_status, message_id)
                       VALUES (?, 'sent', ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)""",
                    (user["id"], user["email"], ", ".join(recipients), raw_cc, raw_bcc,
                     subject, body_text, body_html, now_ts, "sent" if not external_rcpts else "queued", msg_id_val)
                )
                sent_id = cur.lastrowid
                for att in processed_attachments:
                    conn.execute(
                        """INSERT INTO attachments(message_id, filename, content_type, size, storage_path, created_at)
                           VALUES (?, ?, ?, ?, ?, ?)""",
                        (sent_id, att["filename"], att["content_type"], att["size"], att["storage_path"], now_ts)
                    )
                conn.commit()

            self.json_resp({"ok": True, "messageId": msg_id_val, "status": "sent" if not external_rcpts else "queued"})
            return

        if path == "/api/draft":
            user = self.authenticate_user()
            if not user:
                return
            recipient = (body.get("to") or "").strip()[:320]
            cc = (body.get("cc") or "").strip()[:320]
            bcc = (body.get("bcc") or "").strip()[:320]
            subject = (body.get("subject") or "").strip()[:500]
            text = body.get("text") or ""
            draft_id = body.get("id")

            with DB_LOCK, get_db() as conn:
                if draft_id:
                    conn.execute(
                        """UPDATE messages SET recipient=?, cc=?, bcc=?, subject=?, body_text=?
                           WHERE id=? AND owner_user_id=?""",
                        (recipient, cc, bcc, subject, text, draft_id, user["id"])
                    )
                    did = draft_id
                else:
                    cur = conn.execute(
                        """INSERT INTO messages(owner_user_id, folder, sender, recipient, cc, bcc, subject, body_text, is_read, created_at)
                           VALUES (?, 'drafts', ?, ?, ?, ?, ?, ?, 1, ?)""",
                        (user["id"], user["email"], recipient, cc, bcc, subject, text, int(time.time()))
                    )
                    did = cur.lastrowid
                conn.commit()
            self.json_resp({"ok": True, "id": did}, 201)
            return

        if path.startswith("/api/messages/") and path.endswith("/move"):
            user = self.authenticate_user()
            if not user:
                return
            parts = path.strip("/").split("/")
            mid = int(parts[2])
            folder = (body.get("folder") or "").lower()
            if folder not in {"inbox", "sent", "drafts", "spam", "trash"}:
                self.json_resp({"error": "invalid_folder"}, 400)
                return
            with DB_LOCK, get_db() as conn:
                cur = conn.execute("UPDATE messages SET folder=? WHERE id=? AND owner_user_id=?", (folder, mid, user["id"]))
                conn.commit()
            self.json_resp({"ok": cur.rowcount == 1})
            return

        if path == "/api/admin/relay-config":
            user = self.authenticate_user()
            if not user:
                return
            host = (body.get("host") or "").strip()
            port = str(body.get("port") or 587)
            user_str = (body.get("user") or "").strip()
            pwd = body.get("pass") or ""
            sec = (body.get("security") or "starttls").strip().lower()

            with DB_LOCK, get_db() as conn:
                conn.execute("INSERT OR REPLACE INTO server_config(key, value) VALUES ('relay_host', ?)", (host,))
                conn.execute("INSERT OR REPLACE INTO server_config(key, value) VALUES ('relay_port', ?)", (port,))
                conn.execute("INSERT OR REPLACE INTO server_config(key, value) VALUES ('relay_user', ?)", (user_str,))
                if pwd:
                    conn.execute("INSERT OR REPLACE INTO server_config(key, value) VALUES ('relay_pass', ?)", (pwd,))
                conn.execute("INSERT OR REPLACE INTO server_config(key, value) VALUES ('relay_security', ?)", (sec,))
                conn.commit()
            self.json_resp({"ok": True, "message": "Relay configuration updated"})
            return

        if path == "/api/admin/retry-queue":
            user = self.authenticate_user()
            if not user:
                return
            with DB_LOCK, get_db() as conn:
                cur = conn.execute("UPDATE outgoing_queue SET status='queued', retries=0, next_attempt=0, last_error='' WHERE status IN ('failed', 'retrying', 'deferred', 'rejected', 'bounced')")
                conn.commit()
            self.json_resp({"ok": True, "requeued": cur.rowcount})
            return

        self.json_resp({"error": "not_found"}, 404)

    def do_DELETE(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path.startswith("/api/messages/"):
            user = self.authenticate_user()
            if not user:
                return
            try:
                mid = int(path.strip("/").split("/")[-1])
            except ValueError:
                self.json_resp({"error": "bad_id"}, 400)
                return
            with DB_LOCK, get_db() as conn:
                cur = conn.execute("DELETE FROM messages WHERE id=? AND owner_user_id=?", (mid, user["id"]))
                conn.commit()
            self.json_resp({"ok": cur.rowcount == 1})
            return
        self.json_resp({"error": "not_found"}, 404)

# -----------------------------------------------------------------------------
# Main Daemon Launcher
# -----------------------------------------------------------------------------

def start_http_server():
    httpd = ThreadingHTTPServer((HOST, HTTP_PORT), StepMailHTTPHandler)
    print(f"[*] StepMail REST API listening at http://{HOST}:{HTTP_PORT}")
    httpd.serve_forever()

async def run_smtp_servers():
    loop = asyncio.get_running_loop()
    
    # Inbound MX Server
    try:
        mx_server = await loop.create_server(lambda: SMTPProtocol(is_submission=False), SMTP_HOST, SMTP_PORT)
        print(f"[*] StepMail Inbound SMTP Server listening on {SMTP_HOST}:{SMTP_PORT}")
    except Exception as e:
        print(f"[!] Warning: Could not bind SMTP port {SMTP_PORT}: {e}")
        mx_server = None

    # Submission Server
    try:
        sub_server = await loop.create_server(lambda: SMTPProtocol(is_submission=True), SMTP_HOST, SUBMISSION_PORT)
        print(f"[*] StepMail Submission Server listening on {SMTP_HOST}:{SUBMISSION_PORT}")
    except Exception as e:
        print(f"[!] Warning: Could not bind Submission port {SUBMISSION_PORT}: {e}")
        sub_server = None

    # Keep running
    while True:
        await asyncio.sleep(3600)

def main():
    print("=" * 60)
    print(f" StepMail Independent Core Server v1.3.0")
    print(f" Domain: {DOMAIN}")
    print(f" Database: {DB_PATH}")
    print("=" * 60)

    init_db()
    import_legacy_db_if_needed()
    ensure_dkim_keys()

    # Start Queue Worker Thread
    q_thread = threading.Thread(target=queue_worker_loop, daemon=True, name="QueueWorker")
    q_thread.start()

    # Start HTTP REST API in background thread
    http_thread = threading.Thread(target=start_http_server, daemon=True, name="HTTPServer")
    http_thread.start()

    # Run Asyncio SMTP Servers on main thread
    try:
        asyncio.run(run_smtp_servers())
    except KeyboardInterrupt:
        print("\n[*] StepMail Server stopped.")

if __name__ == "__main__":
    main()
