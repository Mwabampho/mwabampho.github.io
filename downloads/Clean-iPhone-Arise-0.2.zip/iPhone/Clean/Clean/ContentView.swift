import SwiftUI

private let cleanVersion = "Arise 0.2"
private let updateURL = URL(string: "https://shouldbe.media/clean/updates")!

struct ContentView: View {
    @State private var tab = 0
    var body: some View {
        TabView(selection: $tab) {
            NavigationStack { BrainScreen() }.tabItem { Label("Brain", systemImage: "brain.head.profile") }.tag(0)
            NavigationStack { ProjectsScreen() }.tabItem { Label("Projects", systemImage: "square.grid.2x2") }.tag(1)
            NavigationStack { VaultScreen() }.tabItem { Label("The Vault", systemImage: "lock.square.stack") }.tag(2)
            NavigationStack { MoreScreen() }.tabItem { Label("More", systemImage: "ellipsis.circle") }.tag(3)
        }.tint(.blue)
    }
}

struct CleanBackground: View {
    var body: some View { LinearGradient(colors: [Color(red:0.02,green:0.06,blue:0.12), Color(red:0.02,green:0.035,blue:0.07)], startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea() }
}

struct BrainScreen: View {
    @State private var entry = ""
    @State private var localEntries: [String] = []
    var body: some View {
        ZStack {
            CleanBackground()
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    CleanHeader(title: "Brain", subtitle: "Private by default")
                    InfoCard(icon: "checkmark.shield.fill", title: "Independent core", body: "Clean works without third-party API keys. External providers are optional and requested only when you choose to connect.")
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Local Brain notes").font(.headline)
                        ForEach(Array(localEntries.enumerated()), id: \.offset) { _, item in Text(item).padding(12).frame(maxWidth: .infinity, alignment: .leading).background(Color.white.opacity(0.06)).clipShape(RoundedRectangle(cornerRadius: 12)) }
                        TextField("Write something…", text: $entry).textFieldStyle(.roundedBorder)
                        Button("Save locally") {
                            let v = entry.trimmingCharacters(in: .whitespacesAndNewlines)
                            guard !v.isEmpty else { return }
                            localEntries.insert(v, at: 0); entry = ""
                        }.buttonStyle(.borderedProminent)
                    }.cardStyle()
                }.padding(16)
            }
        }.navigationTitle("Clean").navigationBarTitleDisplayMode(.inline)
    }
}

struct ProjectsScreen: View {
    var body: some View {
        ZStack { CleanBackground(); ScrollView { VStack(alignment:.leading,spacing:16) { CleanHeader(title:"Projects", subtitle:"Everything you are building"); ProjectTile(name:"Clean", detail:"Top-level control application", status:"Active"); ProjectTile(name:"ShouldBe", detail:"Primary ecosystem", status:"Managed") }.padding(16) } }
        .navigationTitle("Projects").navigationBarTitleDisplayMode(.inline)
    }
}

struct VaultScreen: View {
    @State private var idea = ""
    @State private var ideas: [String] = []
    var body: some View {
        ZStack { CleanBackground(); ScrollView { VStack(alignment:.leading,spacing:16) { CleanHeader(title:"The Vault", subtitle:"Private idea capture"); VStack(alignment:.leading,spacing:12) { TextField("Capture an idea…", text:$idea).textFieldStyle(.roundedBorder); Button("Save to Vault") { let v=idea.trimmingCharacters(in:.whitespacesAndNewlines); guard !v.isEmpty else{return}; ideas.insert(v,at:0); idea="" }.buttonStyle(.borderedProminent) }.cardStyle(); ForEach(Array(ideas.enumerated()), id:\.offset) { _, item in VStack(alignment:.leading,spacing:8) { Text(item).font(.headline); Button("Turn into project") { } }.cardStyle() } }.padding(16) } }
        .navigationTitle("The Vault").navigationBarTitleDisplayMode(.inline)
    }
}

struct MoreScreen: View {
    var body: some View {
        ZStack { CleanBackground(); List { Section { NavigationLink { SettingsScreen() } label: { Label("Settings", systemImage:"gearshape.fill") }; NavigationLink { UpdatesScreen() } label: { Label("Check for Updates", systemImage:"arrow.triangle.2.circlepath") } } header: { Text("Clean") }; Section { NavigationLink { ConnectionScreen() } label: { Label("Temporary API Connection", systemImage:"link") } } header: { Text("Connections") } }.scrollContentBackground(.hidden) }
        .navigationTitle("More")
    }
}

struct SettingsScreen: View {
    var body: some View {
        ZStack { CleanBackground(); ScrollView { VStack(alignment:.leading,spacing:16) { CleanHeader(title:"Settings", subtitle:cleanVersion); InfoCard(icon:"checkmark.shield.fill", title:"Zero-key core", body:"No OpenAI, Anthropic, Google or other third-party API key is required for Clean to open or work locally."); NavigationLink { ConnectionScreen() } label: { SettingRow(icon:"link", title:"Temporary external connection", subtitle:"Enter a key only when you choose to connect") }.buttonStyle(.plain); NavigationLink { UpdatesScreen() } label: { SettingRow(icon:"arrow.down.circle.fill", title:"Download / Update Clean", subtitle:"Visible update controls for Mac and iPhone") }.buttonStyle(.plain) }.padding(16) } }
        .navigationTitle("Settings").navigationBarTitleDisplayMode(.inline)
    }
}

struct ConnectionScreen: View {
    @State private var provider = ""
    @State private var key = ""
    @State private var connected = false

    var body: some View {
        ZStack {
            CleanBackground()
            Form {
                Section("Temporary connection") {
                    TextField("Provider or service", text: $provider)
                    SecureField("API key", text: $key)
                    Button(connected ? "Connected for this session" : "Connect") {
                        connected = !provider.isEmpty && !key.isEmpty
                    }
                    .disabled(provider.isEmpty || key.isEmpty)

                    Button("Clear key") {
                        key = ""
                        connected = false
                    }
                    .foregroundStyle(.red)
                }

                Section {
                    Text("The key stays in app memory for this session and is not saved to Clean storage by default.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .scrollContentBackground(.hidden)
        }
        .navigationTitle("API Connection")
    }
}

struct UpdatesScreen: View {
    @Environment(\.openURL) private var openURL
    @State private var checked = false
    var body: some View {
        ZStack { CleanBackground(); ScrollView { VStack(alignment:.leading,spacing:16) { CleanHeader(title:"Updates", subtitle:cleanVersion); InfoCard(icon:"checkmark.circle.fill", title:checked ? "Update centre opened" : "Current release: Arise 0.2", body:"Clean uses your first-party ShouldBe update centre. No third-party API key is required to check your own release feed."); Button { checked=true; openURL(updateURL) } label: { Label("Check for Updates", systemImage:"arrow.triangle.2.circlepath") }.buttonStyle(.bordered); Button { openURL(updateURL) } label: { Label("Download Arise 0.2", systemImage:"arrow.down.circle.fill") }.buttonStyle(.borderedProminent); Text("The download page contains Clean for Mac and the native iPhone Xcode project.").font(.footnote).foregroundStyle(.secondary) }.padding(16) } }
        .navigationTitle("Check for Updates").navigationBarTitleDisplayMode(.inline)
    }
}

struct CleanHeader: View { let title:String; let subtitle:String; var body: some View { VStack(alignment:.leading,spacing:5) { HStack { ZStack { RoundedRectangle(cornerRadius:10).fill(.blue.gradient).frame(width:42,height:46); Image(systemName:"checkmark.shield.fill").foregroundStyle(.white) }; VStack(alignment:.leading) { Text(title).font(.largeTitle.bold()); Text(subtitle).foregroundStyle(.secondary) } }; Text("Clean · \(cleanVersion)").font(.caption).foregroundStyle(.secondary) } } }
struct InfoCard: View { let icon:String; let title:String; let body:String; var body: some View { VStack(alignment:.leading,spacing:10) { Label(title, systemImage:icon).font(.headline).foregroundStyle(.green); Text(body).foregroundStyle(.secondary) }.cardStyle() } }
struct ProjectTile: View { let name:String; let detail:String; let status:String; var body: some View { VStack(alignment:.leading,spacing:9) { Image(systemName:"app.gift.fill").font(.title2).foregroundStyle(.blue); Text(name).font(.title2.bold()); Text(detail).foregroundStyle(.secondary); Text(status).font(.caption.bold()).foregroundStyle(.cyan) }.cardStyle() } }
struct SettingRow: View { let icon:String; let title:String; let subtitle:String; var body: some View { HStack(spacing:12) { Image(systemName:icon).foregroundStyle(.blue).frame(width:28); VStack(alignment:.leading,spacing:3) { Text(title).foregroundStyle(.primary).font(.headline); Text(subtitle).font(.caption).foregroundStyle(.secondary) }; Spacer(); Image(systemName:"chevron.right").foregroundStyle(.tertiary) }.cardStyle() } }

extension View {
    func cardStyle() -> some View { self.padding(16).frame(maxWidth:.infinity, alignment:.leading).background(.ultraThinMaterial.opacity(0.72)).overlay(RoundedRectangle(cornerRadius:18).stroke(Color.white.opacity(0.08))).clipShape(RoundedRectangle(cornerRadius:18)) }
}
