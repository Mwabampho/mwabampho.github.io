CLEAN — ARISE 0.2 — iPhone

Native SwiftUI Xcode project.

1. Open Clean/Clean.xcodeproj in Xcode.
2. Select the Clean target → Signing & Capabilities → choose your Apple Development Team.
3. Connect/select your iPhone and press Run.

Arise 0.2 changes:
- Core Clean requires zero third-party API keys.
- Brain, Projects, The Vault and More remain the main tabs.
- Settings now includes a visible “Download / Update Clean” row.
- “Check for Updates” remains visible in More.
- Updates screen now contains both “Check for Updates” and “Download Arise 0.2” buttons.
- External API keys are requested only when you deliberately open Temporary API Connection.
- The entered key stays in memory for the current session and is not persisted by default.
- Update centre: https://shouldbe.media/clean/updates
