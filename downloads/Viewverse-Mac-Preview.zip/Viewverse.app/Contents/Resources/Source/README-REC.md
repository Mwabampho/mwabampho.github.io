# Viewverse 0.4 — Rec pre-production preview

Rec is part of Viewverse: Rec → Space → Dressing Room → Studio → Review → Viewverse.
Open `/rec` after signing into the existing local creator account. Create Revelation to start a blank episode using the public character nickname Cactic G. No biographical events are invented or prefilled.

## Implemented
- Creator-authenticated SQLite project persistence, revision conflict detection and review invalidation.
- Typing and browser speech dictation where supported; macOS keyboard dictation remains a fallback.
- Personal-account, dramatised-memory and constructive-fiction labels, plus per-scene provenance.
- Character/outfit briefs, private PNG import, Space JSON handoff, editable/reorderable scene plan.
- Real FFmpeg MP4 storyboards (silent text cards, optional static character image). The renderer does not animate the character or interpret action directions.
- Explicit creator checks for story alignment, wardrobe, privacy and rights before local publication.
- Public metadata uses nicknames. Text and artwork still need manual privacy review.
- Updates screen with the existing official Mac download link.

## Not implemented / not claimed
- Automatic life-story truth verification, independent moderation, evidence corroboration.
- AI character creation, motion/lip-sync, cinematic generative video or voice acting.
- A live connection to the separate Space application; the JSON brief is a handoff contract.
- Shared cloud accounts/storage, multi-user service, cloud Viewverse publishing.
- Automatic signed update installation or Apple Developer ID notarisation. Existing workflow uses ad-hoc signing.
- Legacy capture/upload/live flows have not been converted into the new story review workflow. Their existing publication policy is not a platform-wide story verification system.

## Build and data
The Mac workflow overlays this tracked source into the existing native bundle. Node 22.13+ and FFmpeg are still required. Quit the old app before replacing it. Existing data stays at `~/Library/Application Support/Viewverse/data`; bundle source copying does not overwrite it because the repository excludes data, certificates and local environment files.

Run `node scripts/setup.js`, then `node server/index.js`. Production project source is tracked; never commit `data/`, `certs/`, `logs/`, `.env`, or generated media.

## Validation
Integration exercised authentication, project persistence, stale revisions, fiction lesson enforcement, MP4 rendering, private/public media, review checks, publishing, private display-name exclusion and invalidation after edits. macOS microphone dictation, native launch and UI interaction require device verification.
