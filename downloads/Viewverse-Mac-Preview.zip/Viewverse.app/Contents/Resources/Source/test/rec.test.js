import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'viewverse-rec-'));
process.env.VIEWVERSE_DATA_DIR=temp;
const {normalize,blockers}=await import('../server/routes/rec.js');
const valid={title:'Test',nickname:'Alias',story:'Story',character:'Character',outfit:'Coat',kind:'personal',scenes:[{text:'I remember this.',basis:'memory',seconds:8}]};
test('personal account cannot silently include reconstructed scenes',()=>{
 assert.deepEqual(blockers(normalize(valid)),[]);
 assert(blockers(normalize({...valid,scenes:[{text:'Imagined detail',basis:'fiction'}]})).some(x=>x.includes('dramatised')));
});
test('fiction needs a constructive lesson',()=>{
 assert(blockers(normalize({...valid,kind:'fiction'})).some(x=>x.includes('lesson')));
 assert.deepEqual(blockers(normalize({...valid,kind:'fiction',lesson:'Kindness matters'})),[]);
});
test('untrusted render durations and scene counts are bounded',()=>{
 const p=normalize({...valid,scenes:Array.from({length:100},()=>({text:'x',seconds:Infinity}))});
 assert.equal(p.scenes.length,30);assert(p.scenes.every(s=>s.seconds===30));
});
test.after(()=>{fs.rmSync(temp,{recursive:true,force:true})});
