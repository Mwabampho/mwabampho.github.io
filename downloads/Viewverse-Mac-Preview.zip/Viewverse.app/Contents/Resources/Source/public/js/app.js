import * as updates from './views/updates.js';
// App shell: session, routing, top bar and floating nav pill.
import { h, icon, api, toast, initial } from './lib.js';
import * as viewer from './views/viewer.js';
import * as rec from './views/rec.js';
import * as studio from './views/studio.js';
import * as review from './views/review.js';
import * as record from './views/record.js';
import * as golive from './views/golive.js';
import * as liveView from './views/live.js';

export const session = { me: null };
const app = document.getElementById('app');
let cleanup = null;

const routes = [
  [/^\/settings$/, updates.render, { creator: true }],
  [/^\/rec$/, rec.render, { creator: true }],
  [/^\/$/, viewer.home],
  [/^\/search$/, viewer.search],
  [/^\/watch\/([\w-]+)$/, viewer.watch],
  [/^\/creator$/, viewer.profile],
  [/^\/live\/([\w-]+)$/, liveView.render, { live: true }],
  [/^\/studio$/, studio.render, { creator: true }],
  [/^\/studio\/record$/, record.render, { creator: true }],
  [/^\/studio\/video\/([\w-]+)$/, review.render, { creator: true }],
  [/^\/studio\/live$/, golive.render, { creator: true }],
  [/^\/signin$/, signin, { open: true }],
  [/^\/setup$/, setup, { open: true }],
];

export function navigate(url, { replace = false } = {}) {
  if (replace) history.replaceState({}, '', url); else history.pushState({}, '', url);
  route();
}

async function route() {
  if (cleanup) { try { cleanup(); } catch {} cleanup = null; }
  const path = location.pathname;
  const match = routes.map(([re, fn, opts]) => [path.match(re), fn, opts || {}]).find(([m]) => m);
  const [m, fn, opts] = match || [null, notFound, {}];
  const me = session.me;
  if (me.setupNeeded && !opts.open) return navigate('/setup', { replace: true });
  if (!opts.open && !opts.live && !me.signedIn && (opts.creator || !me.guestViewing)) return navigate(`/signin?next=${encodeURIComponent(location.pathname + location.search)}`, { replace: true });
  renderChrome();
  app.replaceChildren();
  window.scrollTo(0, 0);
  try {
    const ctx = { params: m ? m.slice(1) : [], query: new URLSearchParams(location.search), onCleanup: (f) => { cleanup = f; } };
    const view = await fn(ctx);
    if (view) app.replaceChildren(view);
  } catch (e) {
    if (e.status === 401) return navigate(`/signin?next=${encodeURIComponent(location.pathname)}`, { replace: true });
    app.replaceChildren(h('div', { class: 'notice bad' }, e.message));
  }
}

function renderChrome() {
  const me = session.me;
  const path = location.pathname;
  const nav = document.getElementById('navpill');
  const items = [['/', 'home', 'Home'], ['/search', 'search', 'Search'], ['/rec', 'wave', 'Rec'], ['/studio', 'studio', 'Studio'], ['/creator', 'user', 'Profile'], ['/settings', 'info', 'Updates']];
  nav.replaceChildren(...items.map(([href, ic, label]) => {
    const active = href === '/' ? path === '/' || path.startsWith('/watch') || path.startsWith('/live') : path.startsWith(href);
    return h('a', { href, 'data-link': true, class: active ? 'active' : '', 'aria-label': label, title: label, 'aria-current': active ? 'page' : undefined }, icon(ic));
  }));
  nav.classList.toggle('hidden', !me.signedIn && !me.guestViewing);
  const top = document.getElementById('topactions');
  top.replaceChildren(...[themeButton(), me.signedIn
    ? h('button', { class: 'avatar', title: `Signed in as ${me.creator.displayName} — sign out`, onclick: signOut, 'aria-label': 'Sign out' }, initial(me.creator.displayName))
    : path !== '/signin' && path !== '/setup' && !me.setupNeeded ? h('a', { class: 'btn sm', href: '/signin', 'data-link': true }, 'Sign in') : null].filter(Boolean));
  const q = document.querySelector('#topsearch input');
  if (path === '/search') q.value = new URLSearchParams(location.search).get('q') || '';
}

function themeButton() {
  const order = ['system', 'light', 'dark'];
  let cur = 'system';
  try { cur = localStorage.getItem('vv-theme') || 'system'; } catch {}
  const icons = { system: 'phone', light: 'sun', dark: 'moon' };
  const labels = { system: 'Phone theme', light: 'Light theme', dark: 'Dark theme' };
  const b = h('button', { class: 'iconbtn', title: labels[cur], 'aria-label': labels[cur] }, icon(icons[cur]));
  b.onclick = () => {
    const next = order[(order.indexOf(cur) + 1) % 3];
    try { localStorage.setItem('vv-theme', next); } catch {}
    if (next === 'system') delete document.documentElement.dataset.theme; else document.documentElement.dataset.theme = next;
    toast(labels[next]);
    renderChrome();
  };
  return b;
}

async function signOut() {
  if (!confirm('Sign out of Viewverse on this device?')) return;
  await api('POST', '/api/logout');
  session.me = await api('GET', '/api/me');
  navigate('/signin');
}

function signin({ query }) {
  if (session.me.signedIn) { navigate(query.get('next') || '/', { replace: true }); return; }
  const err = h('div', { class: 'notice bad hidden' });
  const form = h('form', { class: 'card stack' },
    h('h1', {}, 'Sign in'),
    h('p', { class: 'muted' }, 'This is a private Viewverse prototype running on your laptop. Sign in with your creator account.'),
    h('label', { class: 'field' }, h('span', {}, 'Username'), h('input', { type: 'text', name: 'username', autocomplete: 'username', autocapitalize: 'none', required: true })),
    h('label', { class: 'field' }, h('span', {}, 'Password'), h('input', { type: 'password', name: 'password', autocomplete: 'current-password', required: true })),
    err,
    h('button', { class: 'btn primary', type: 'submit' }, 'Sign in'),
    h('p', { class: 'muted small' }, 'Forgot it? On the laptop run ', h('code', {}, 'npm run reset-password'), '.'));
  form.onsubmit = async (e) => {
    e.preventDefault();
    const f = new FormData(form);
    try {
      await api('POST', '/api/login', { username: f.get('username').trim().toLowerCase(), password: f.get('password') });
      session.me = await api('GET', '/api/me');
      navigate(query.get('next') || '/', { replace: true });
    } catch (x) { err.textContent = x.message; err.classList.remove('hidden'); }
  };
  return h('div', { class: 'auth' }, form);
}

function setup() {
  if (!session.me.setupNeeded) { navigate('/', { replace: true }); return; }
  if (!session.me.canSetupHere) {
    return h('div', { class: 'auth card stack' }, h('h1', {}, 'Finish setup on the laptop'),
      h('p', {}, 'For safety, the creator account can only be created on the laptop running Viewverse. Open ', h('code', {}, 'http://localhost:8080'), ' on the laptop, then come back to this device and sign in.'));
  }
  const err = h('div', { class: 'notice bad hidden' });
  const form = h('form', { class: 'card stack' },
    h('h1', {}, 'Create your creator account'),
    h('p', { class: 'muted' }, 'Only this account can see your unpublished recordings, originals and processing controls.'),
    h('label', { class: 'field' }, h('span', {}, 'Display name'), h('input', { type: 'text', name: 'displayName', maxlength: 50, required: true })),
    h('label', { class: 'field' }, h('span', {}, 'Username (lowercase, used to sign in)'), h('input', { type: 'text', name: 'username', pattern: '[a-z0-9_]{3,24}', autocapitalize: 'none', autocomplete: 'username', required: true })),
    h('label', { class: 'field' }, h('span', {}, 'Password (10+ characters)'), h('input', { type: 'password', name: 'password', minlength: 10, autocomplete: 'new-password', required: true })),
    err,
    h('button', { class: 'btn primary', type: 'submit' }, 'Create account'));
  form.onsubmit = async (e) => {
    e.preventDefault();
    const f = new FormData(form);
    try {
      await api('POST', '/api/setup', { displayName: f.get('displayName'), username: f.get('username').trim(), password: f.get('password') });
      session.me = await api('GET', '/api/me');
      navigate('/studio', { replace: true });
    } catch (x) { err.textContent = x.message; err.classList.remove('hidden'); }
  };
  return h('div', { class: 'auth' }, form);
}

function notFound() {
  return h('div', { class: 'empty' }, h('h1', {}, 'Page not found'), h('a', { class: 'btn', href: '/', 'data-link': true }, 'Go home'));
}

document.addEventListener('click', (e) => {
  const a = e.target.closest('a[data-link]');
  if (!a || e.metaKey || e.ctrlKey || e.shiftKey || a.target) return;
  e.preventDefault();
  navigate(a.getAttribute('href'));
});
window.addEventListener('popstate', route);
document.getElementById('topsearch').addEventListener('submit', (e) => {
  e.preventDefault();
  const q = new FormData(e.target).get('q').trim();
  navigate(`/search?q=${encodeURIComponent(q)}`);
});

(async () => {
  try { session.me = await api('GET', '/api/me'); }
  catch (e) { app.replaceChildren(h('div', { class: 'notice bad' }, e.message)); return; }
  route();
})();
