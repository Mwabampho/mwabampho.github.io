// Broadcaster screen for the delayed live workflow. Separate from uploads.
// Camera → 1 s numbered chunks → laptop (private ingest) → processing → delayed viewers.
import { h, icon, api, fmtDur, fmtBytes, toast } from '../lib.js';
import { navigate } from '../app.js';
import { pickRecorderMime, cameraErrorHelp, requestWakeLock } from '../media.js';
import { measureClockOffset, attachLivePlayer } from '../live-player.js';
import { LIVE_LABEL } from './live.js';

const MAX_LOCAL_BUFFER_SEC = 90;
const MAX_LOCAL_BUFFER_BYTES = 120 * 1024 * 1024;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export async function render({ onCleanup }) {
  const status = await api('GET', '/api/studio/status');
  const existing = (await api('GET', '/api/studio/live')).broadcasts;
  const running = existing.find((b) => !['ended', 'failed'].includes(b.status));

  const preview = h('video', { playsinline: true, autoplay: true, muted: true });
  const camBox = h('div', { class: 'camera' }, preview);
  const msg = h('div', {});
  const camMsg = h('div', {}); // camera/permission problems, kept separate from broadcast notes
  const statusChip = h('span', { class: 'chip' }, 'Not live');
  const statsEl = h('div', { class: 'stats' });
  const monitor = h('video', { playsinline: true, autoplay: true, muted: true, controls: true });
  const monitorBox = h('div', { class: 'hidden stack' }, h('b', {}, 'What viewers see (processed, delayed)'), h('div', { class: 'player' }, monitor));

  let stream = null, recorder = null, facing = 'user', wake = null;
  let bc = running || null; // broadcast state from the server
  let run = 0, offset = 0;
  let queue = [], sending = false, live = false, localState = 'idle', lastError = null, sent = 0, monitorPlayer = null;

  // --- settings ---
  const title = h('input', { type: 'text', value: 'Live from my studio', maxlength: 100 });
  const segSel = h('select', {}, [1, 2, 3, 4, 6].map((n) => h('option', { value: n, selected: n === status.live.segmentSec }, `${n} s`)));
  const delayInput = h('input', { type: 'number', min: 4, max: 60, step: 1, value: status.live.targetDelaySec });
  const captions = h('input', { type: 'checkbox', checked: true });
  const publish = h('input', { type: 'checkbox' }); // off by default – explicit opt-in
  const settings = h('div', { class: 'card stack' },
    h('label', { class: 'field' }, h('span', {}, 'Title'), title),
    h('div', { class: 'row' },
      h('label', { class: 'field', style: { flex: 1 } }, h('span', {}, 'Segment length'), segSel),
      h('label', { class: 'field', style: { flex: 1 } }, h('span', {}, 'Target delay (seconds)'), delayInput)),
    h('label', { class: 'check' }, captions, h('div', {}, h('b', {}, 'Live captions when processing speed allows'), h('div', { class: 'small muted' }, 'On-device transcription; skipped if it can’t keep up'))),
    h('label', { class: 'check' }, publish, h('div', {}, h('b', {}, 'Show this broadcast to viewers in my Viewverse feed'),
      h('div', { class: 'small muted' }, 'Off = private preview only you can watch. Nothing leaves your Wi-Fi either way.'))),
    h('p', { class: 'small muted', style: { margin: 0 } }, 'Live processing keeps your timeline exactly as recorded: no silence trimming or reordering. Audio gets a rumble filter, gentle compression and a peak limiter.'));

  async function openCamera() {
    stream?.getTracks().forEach((t) => t.stop());
    if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) {
      camMsg.replaceChildren(h('div', { class: 'notice warn' }, 'Live broadcasting needs the camera, which browsers only allow on secure (HTTPS) pages. Install the Viewverse certificate on this device (README → “Connect your phone”) and reload.'));
      return false;
    }
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: facing, width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 30 } }, audio: { echoCancellation: true, noiseSuppression: true } });
      preview.srcObject = stream;
      await new Promise((r) => (preview.onloadedmetadata = r));
      camBox.classList.toggle('portrait', preview.videoHeight > preview.videoWidth);
      camMsg.replaceChildren();
      return true;
    } catch (e) {
      const help = cameraErrorHelp(e);
      camMsg.replaceChildren(h('div', { class: 'notice bad stack' }, h('b', {}, help.title), h('p', { style: { margin: 0 } }, help.body), h('button', { class: 'btn ghost', onclick: openCamera }, icon('retry'), 'Try again')));
      return false;
    }
  }

  function startRecorder() {
    const mime = pickRecorderMime('live');
    const rec = new MediaRecorder(stream, { ...(mime ? { mimeType: mime } : {}), videoBitsPerSecond: 2_500_000, audioBitsPerSecond: 128_000 });
    const myRun = run;
    let mySeq = 0, myStart = Date.now() + offset;
    recorder = rec;
    rec.onstart = () => { myStart = Date.now() + offset; };
    rec.ondataavailable = (e) => {
      // Ignore the last piece from a recorder that has been replaced by a new session.
      if (!e.data.size || recorder !== rec) return;
      queue.push({ run: myRun, seq: mySeq++, blob: e.data, t: Date.now() + offset, runStart: myStart });
      enforceBuffer();
      pump();
    };
    rec.start(1000);
  }

  function enforceBuffer() {
    const bytes = queue.reduce((a, c) => a + c.blob.size, 0);
    if (queue.length > MAX_LOCAL_BUFFER_SEC || bytes > MAX_LOCAL_BUFFER_BYTES) {
      stopLocal(`Stopped: the laptop couldn’t accept video for over ${MAX_LOCAL_BUFFER_SEC} s (${fmtBytes(bytes)} waiting on this device). Nothing was shown to viewers unprocessed. Check the Wi-Fi, then resume.`);
    }
  }

  async function pump() {
    if (sending) return;
    sending = true;
    let failures = 0;
    while (queue.length) {
      const c = queue[0];
      try {
        const r = await fetch(`/api/studio/live/${bc.id}/ingest?run=${c.run}&seq=${c.seq}&t=${c.t}&runStart=${c.runStart}`, { method: 'POST', headers: { 'x-viewverse': '1' }, body: c.blob });
        const data = await r.json();
        if (data.state) bc = data.state;
        if (r.ok) { queue.shift(); sent++; failures = 0; localState = 'live'; }
        else if (r.status === 503) { localState = 'holding'; await sleep(data.retryAfterMs || 1000); }
        else if (r.status === 409 && data.expected) {
          if (data.expected.run === c.run && data.expected.seq > c.seq) queue.shift(); // already there
          else { lastError = 'A piece of video went missing, so a new recording session was started.'; restartRun(); break; }
        } else if (r.status === 410) { stopLocal(data.error); break; }
        else { lastError = data.error; await sleep(1000); }
      } catch {
        failures++;
        localState = 'reconnecting';
        paint();
        await sleep(Math.min(5000, 500 * 2 ** Math.min(failures, 4)));
      }
      paint();
    }
    sending = false;
  }

  function restartRun() {
    queue = [];
    try { recorder?.stop(); } catch {}
    run = (bc?.nextRun ?? run + 1);
    startRecorder();
  }

  async function goLive() {
    if (!stream && !(await openCamera())) return;
    try {
      offset = await measureClockOffset();
      if (!bc || ['ended', 'failed'].includes(bc.status)) {
        bc = await api('POST', '/api/studio/live', {
          title: title.value, segmentSec: Number(segSel.value), targetDelaySec: Number(delayInput.value), captions: captions.checked,
          publishLive: publish.checked, orientation: preview.videoHeight > preview.videoWidth ? 'portrait' : 'landscape',
        });
        run = 0;
      } else run = bc.nextRun; // resuming an interrupted broadcast
      queue = [];
      live = true; lastError = null; localState = 'live';
      wake = await requestWakeLock();
      startRecorder();
      settings.classList.add('hidden');
      monitorBox.classList.remove('hidden');
      paint();
    } catch (e) { toast(e.message, 6000); }
  }

  function stopLocal(reason) {
    live = false;
    const r = recorder;
    recorder = null; // its final piece is discarded; resuming starts a new session
    try { r?.stop(); } catch {}
    wake?.release?.();
    if (reason) lastError = reason;
    paint();
  }

  async function endBroadcast() {
    if (!confirm('End the broadcast for everyone?')) return;
    try { recorder?.state === 'recording' && recorder.stop(); } catch {}
    live = false;
    // Give the last chunks a moment to arrive so the ending isn't cut off.
    const t0 = Date.now();
    while (queue.length && Date.now() - t0 < 8000) { await sleep(300); pump(); }
    bc = await api('POST', `/api/studio/live/${bc.id}/end`);
    wake?.release?.();
    queue = [];
    paint();
    toast('Broadcast ended');
  }

  const startBtn = h('button', { class: 'btn live', onclick: goLive }, icon('live'), running ? 'Resume camera' : 'Start broadcast');
  const endBtn = h('button', { class: 'btn', onclick: endBroadcast }, 'End broadcast');
  const flipBtn = h('button', { class: 'btn', onclick: () => { facing = facing === 'user' ? 'environment' : 'user'; openCamera(); } }, icon('flip'), 'Switch camera');
  const viewLink = h('a', { class: 'btn', href: '#', 'data-link': true }, 'Open viewer page');

  const stat = (label, value) => h('div', { class: 'stat' }, h('span', { class: 'small muted' }, label), h('b', {}, value ?? '—'));
  function paint() {
    const s = bc?.stats || {};
    const serverStatus = bc?.status;
    const label = !bc ? 'Not live' : live && localState === 'reconnecting' ? 'Reconnecting' : LIVE_LABEL[serverStatus] || serverStatus;
    statusChip.textContent = label;
    statusChip.className = `chip ${serverStatus === 'broadcasting' && localState !== 'reconnecting' ? 'livechip' : ['ended', 'failed'].includes(serverStatus) ? '' : bc ? 'warn' : ''}`;
    const waitingSec = queue.length;
    statsEl.replaceChildren(
      stat('Processing lag (measured)', s.processingLagAvgSec != null ? `${s.processingLagAvgSec} s avg` : null),
      stat('Target viewer delay', bc ? `${bc.targetDelaySec} s` : null),
      stat('Waiting on this device', `${waitingSec} s`),
      stat('Processing backlog', s.backlogSec != null ? `${s.backlogSec} s` : null),
      stat('Captions', bc && !bc.captions ? 'Off' : s.captionLagSec != null ? `${s.captionLagSec} s behind` : 'Waiting'),
      stat('Reconnects', s.reconnects ?? 0),
      stat('Duration', s.broadcastSec ? fmtDur(s.broadcastSec) : null),
      stat('Visible to', bc ? (bc.publishLive ? 'Feed viewers' : 'Only you') : null));
    const notes = [lastError, s.captionsNote, bc?.endReason].filter(Boolean);
    msg.replaceChildren(...notes.map((n) => h('div', { class: 'notice warn', style: { marginBottom: '8px' } }, n)));
    startBtn.classList.toggle('hidden', live);
    startBtn.textContent = '';
    startBtn.append(icon('live'), bc && !['ended', 'failed'].includes(bc.status) ? 'Resume camera' : 'Start broadcast');
    endBtn.classList.toggle('hidden', !bc || ['ended', 'failed'].includes(bc.status));
    if (bc && ['ended', 'failed'].includes(bc.status)) { settings.classList.remove('hidden'); startBtn.classList.remove('hidden'); bcReset(); }
    if (bc) { viewLink.setAttribute('href', `/live/${bc.id}`); viewLink.classList.remove('hidden'); } else viewLink.classList.add('hidden');
    if (bc && s.segments > 0 && !monitorPlayer && !['ended', 'failed'].includes(bc.status)) {
      monitorPlayer = true;
      attachLivePlayer(monitor, `/api/live/${bc.id}/playlist.m3u8`, { targetDelaySec: bc.targetDelaySec, clockOffsetMs: offset }).then((p) => (monitorPlayer = p)).catch(() => {});
    }
  }
  function bcReset() {
    // After an end, the next Start creates a new broadcast.
    if (monitorPlayer && monitorPlayer.destroy) { monitorPlayer.destroy(); monitorPlayer = null; }
    monitorBox.classList.add('hidden');
  }

  // Refresh server-side state (status, measured lag) even when no chunk was just sent.
  const timer = setInterval(async () => {
    if (!bc) return;
    try { bc = await api('GET', `/api/live/${bc.id}`); } catch {}
    paint();
  }, 1500);
  const beforeUnload = (e) => { if (live) { e.preventDefault(); e.returnValue = ''; } };
  window.addEventListener('beforeunload', beforeUnload);
  onCleanup(() => {
    clearInterval(timer);
    window.removeEventListener('beforeunload', beforeUnload);
    try { recorder?.state === 'recording' && recorder.stop(); } catch {}
    stream?.getTracks().forEach((t) => t.stop());
    monitorPlayer?.destroy?.();
    wake?.release?.();
  });

  const past = existing.filter((b) => ['ended', 'failed'].includes(b.status));
  const pastList = h('div', { class: 'card stack' }, h('b', {}, 'Past broadcasts'),
    past.length ? past.map((b) => h('div', { class: 'row small' },
      h('a', { href: `/live/${b.id}`, 'data-link': true, style: { flex: 1 } }, b.title, h('span', { class: 'muted' }, ` · ${new Date(b.createdAt).toLocaleString()} · ${fmtDur(b.stats?.broadcastSec || 0)}`)),
      h('button', { class: 'iconbtn', title: 'Delete broadcast', onclick: async (e) => {
        if (!confirm('Delete this broadcast’s processed video and captions from the laptop?')) return;
        try { await api('DELETE', `/api/studio/live/${b.id}`); e.target.closest('.row').remove(); toast('Broadcast deleted'); } catch (x) { toast(x.message); }
      } }, icon('trash')))) : h('div', { class: 'small muted' }, 'None yet. Processed segments are kept until you delete them here.'));

  openCamera().then(paint);
  return h('div', { class: 'stack' },
    h('div', { class: 'row' }, h('a', { class: 'btn sm ghost', href: '/studio', 'data-link': true }, icon('back'), 'Studio'), h('h1', { style: { margin: 0, flex: 1 } }, 'Go live'), statusChip),
    running ? h('div', { class: 'notice' }, `A broadcast (“${running.title}”) is still open. Resume the camera to continue it, or end it.`) : null,
    camMsg, msg,
    h('div', { class: 'review' },
      h('div', { class: 'stack' }, camBox, h('div', { class: 'row' }, startBtn, endBtn, flipBtn, viewLink), statsEl, monitorBox),
      h('div', { class: 'stack' }, settings,
        h('div', { class: 'card small muted' },
          h('b', { style: { color: 'var(--text)' } }, 'How the delay works. '),
          'Your camera sends one-second pieces to the laptop. The laptop processes them into short segments, and viewers are held about the target delay behind you. The delay shown to viewers is measured, not estimated. If processing falls behind, viewers see a holding screen and the delay grows. Unprocessed video is never shown.'), pastList)));
}

