// Resumable chunked upload. If Wi-Fi drops, it waits and resumes from the byte the
// laptop confirms it has, so nothing is sent twice and nothing is skipped.
import { api, ApiError } from './lib.js';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export async function startUpload(file, { source = 'upload', options, name } = {}) {
  const created = await api('POST', '/api/studio/uploads', { name: name || file.name, size: file.size, mime: file.type, source, options });
  return created.id;
}

// onProgress({sent, total, state: 'uploading'|'reconnecting'|'done', message})
export async function sendFile(id, file, { onProgress, signal } = {}) {
  const info = await api('GET', `/api/studio/uploads/${id}`);
  if (info.size !== file.size) throw new Error('That file doesn’t match the interrupted upload (different size). Pick the same file.');
  const chunk = 4 * 1024 * 1024;
  let offset = info.received;
  let failures = 0;
  while (offset < file.size) {
    if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');
    const end = Math.min(file.size, offset + chunk);
    try {
      const r = await api('PUT', `/api/studio/uploads/${id}?offset=${offset}`, file.slice(offset, end), { raw: true, signal });
      offset = r.received;
      failures = 0;
      onProgress?.({ sent: offset, total: file.size, state: r.status === 'queued' ? 'done' : 'uploading' });
    } catch (e) {
      if (e.name === 'AbortError') throw e;
      if (e instanceof ApiError && e.status === 409 && e.data?.received !== undefined) { offset = e.data.received; continue; }
      if (e instanceof ApiError && e.status && e.status !== 0 && e.status < 500) throw e; // validation errors aren't retried
      failures++;
      if (failures > 30) throw new Error('Upload stopped after repeated connection failures. Open Studio later and press Resume.');
      const wait = Math.min(15000, 1000 * 2 ** Math.min(failures, 4));
      onProgress?.({ sent: offset, total: file.size, state: 'reconnecting', message: `Connection lost — retrying in ${Math.round(wait / 1000)} s` });
      await sleep(wait);
      try { offset = (await api('GET', `/api/studio/uploads/${id}`)).received; } catch {}
    }
  }
  onProgress?.({ sent: file.size, total: file.size, state: 'done' });
}
