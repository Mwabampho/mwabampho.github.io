// Viewer screens: home feed, search, watch page, creator profile.
// These never show processing details – just the finished, published videos.
import { h, icon, api, fmtDur, fmtAgo, initial, empty, toast } from '../lib.js';
import { session, navigate } from '../app.js';

export function videoCard(v, creatorName) {
  return h('a', { class: 'vcard', href: `/watch/${v.id}`, 'data-link': true },
    h('div', { class: `thumb ${v.orientation === 'portrait' ? 'portrait' : ''}` },
      h('img', { src: v.thumb, alt: '', loading: 'lazy' }),
      v.duration ? h('span', { class: 'dur' }, fmtDur(v.duration)) : null),
    h('div', { class: 'vmeta' },
      h('div', { class: 'avatar' }, initial(creatorName)),
      h('div', {},
        h('div', { class: 'vtitle' }, v.title),
        h('div', { class: 'muted small' }, creatorName, ' · ', fmtAgo(v.publishedAt)),
        v.matchedSpeech ? h('div', { class: 'small muted' }, 'Mentioned in the video') : null)));
}

function liveBanner(b) {
  return h('a', { class: 'livebanner', href: `/live/${b.id}`, 'data-link': true },
    h('span', { class: 'chip livechip' }, h('span', { class: 'dot pulse' }), 'LIVE'),
    h('div', {}, h('b', {}, b.title), h('div', { class: 'small muted' }, `Broadcasting with a ${b.targetDelaySec}-second delay`)),
    h('span', { class: 'spacer' }), icon('play'));
}

const creatorName = () => session.me.creator?.displayName || 'Creator';

export async function home() {
  const feed = await api('GET', '/api/feed');
  const name = creatorName();
  return h('div', {},
    feed.live.map(liveBanner),
    feed.videos.length
      ? h('div', { class: 'grid' }, feed.videos.map((v) => videoCard(v, name)))
      : empty('play', 'Nothing published yet',
        h('p', {}, session.me.signedIn ? 'Record or upload your first video in Studio. After you approve the edit, it appears here.' : 'Check back soon.'),
        session.me.signedIn ? h('a', { class: 'btn primary', href: '/studio', 'data-link': true }, icon('studio'), 'Open Studio') : null));
}

export async function search({ query }) {
  const q = query.get('q') || '';
  const input = h('input', { type: 'search', value: q, placeholder: 'Search titles, descriptions and what’s said in videos', 'aria-label': 'Search', autofocus: true });
  const form = h('form', { class: 'row', onsubmit: (e) => { e.preventDefault(); navigate(`/search?q=${encodeURIComponent(input.value.trim())}`, { replace: true }); } },
    h('div', { style: { flex: 1 } }, input), h('button', { class: 'btn primary', type: 'submit' }, icon('search'), 'Search'));
  const results = h('div', {});
  if (q) {
    const r = await api('GET', `/api/search?q=${encodeURIComponent(q)}`);
    results.append(r.videos.length
      ? h('div', {}, h('p', { class: 'muted' }, `${r.videos.length} result${r.videos.length > 1 ? 's' : ''} for “${q}”`), h('div', { class: 'grid' }, r.videos.map((v) => videoCard(v, creatorName()))))
      : empty('search', `No videos match “${q}”`, h('p', {}, 'Try fewer or different words.')));
  }
  return h('div', {}, h('h1', {}, 'Search'), form, h('div', { style: { height: '18px' } }), results);
}

export async function watch({ params }) {
  const v = await api('GET', `/api/videos/${params[0]}`);
  const video = h('video', { controls: true, playsinline: true, preload: 'metadata', poster: v.thumb, src: v.src });
  if (v.captions) {
    const track = h('track', { kind: 'captions', src: v.captions, srclang: 'en', label: 'English (auto, reviewed by creator)', default: true });
    video.append(track);
  }
  document.title = `${v.title} · Viewverse`;
  return h('div', { class: 'watch' },
    h('div', {},
      h('div', { class: 'player' }, video),
      h('h1', { style: { marginTop: '14px' } }, v.title),
      h('div', { class: 'row' },
        h('a', { class: 'row', href: '/creator', 'data-link': true }, h('div', { class: 'avatar' }, initial(v.creator.displayName)),
          h('div', {}, h('b', {}, v.creator.displayName), h('div', { class: 'small muted' }, `@${v.creator.username}`))),
        h('span', { class: 'spacer' }),
        h('button', { class: 'btn sm', onclick: () => { navigator.clipboard?.writeText(location.href).then(() => toast('Link copied (works on your Wi-Fi only)')); } }, 'Copy link')),
      h('div', { class: 'desc' }, h('div', { class: 'small muted', style: { marginBottom: '6px' } }, fmtAgo(v.publishedAt), v.duration ? ` · ${fmtDur(v.duration)}` : ''), v.description || 'No description.')),
    h('aside', { class: 'side-list' },
      h('h3', { style: { marginTop: 0 } }, 'More from this creator'),
      v.more.length ? v.more.map((x) => videoCard(x, v.creator.displayName)) : h('p', { class: 'muted' }, 'No other videos yet.')));
}

export async function profile() {
  const c = await api('GET', '/api/creator');
  const nameEl = h('h1', { style: { margin: 0 } }, c.displayName);
  const bioEl = h('p', { class: 'muted', style: { margin: '6px 0 0', maxWidth: '640px' } }, c.bio || (session.me.signedIn ? 'Add a short bio so viewers know what your channel is about.' : ''));
  const edit = session.me.signedIn ? h('button', { class: 'btn sm', onclick: () => editProfile(c, nameEl, bioEl) }, 'Edit profile') : null;
  return h('div', {},
    h('div', { class: 'profile-head' },
      h('div', { class: 'avatar lg' }, initial(c.displayName)),
      h('div', { style: { flex: 1, minWidth: '220px' } }, nameEl,
        h('div', { class: 'muted' }, `@${c.username} · ${c.videoCount} video${c.videoCount === 1 ? '' : 's'} · joined ${new Date(c.joinedAt).toLocaleDateString()}`),
        bioEl),
      edit),
    c.live.map(liveBanner),
    h('h2', {}, 'Videos'),
    c.videos.length ? h('div', { class: 'grid' }, c.videos.map((v) => videoCard(v, c.displayName))) : empty('play', 'No published videos yet'));
}

function editProfile(c, nameEl, bioEl) {
  const name = h('input', { type: 'text', value: c.displayName, maxlength: 50 });
  const bio = h('textarea', { maxlength: 500 }, c.bio);
  const box = h('div', { class: 'card stack', style: { marginBottom: '18px' } },
    h('label', { class: 'field' }, h('span', {}, 'Display name'), name),
    h('label', { class: 'field' }, h('span', {}, 'Bio'), bio),
    h('div', { class: 'row' },
      h('button', { class: 'btn primary', onclick: async () => {
        try {
          const r = await api('PATCH', '/api/studio/profile', { displayName: name.value, bio: bio.value });
          c.displayName = r.display_name; c.bio = r.bio;
          nameEl.textContent = r.display_name; bioEl.textContent = r.bio;
          session.me.creator.displayName = r.display_name;
          box.remove(); toast('Profile saved');
        } catch (e) { toast(e.message); }
      } }, 'Save'),
      h('button', { class: 'btn ghost', onclick: () => box.remove() }, 'Cancel')));
  document.querySelector('.profile-head').after(box);
}
