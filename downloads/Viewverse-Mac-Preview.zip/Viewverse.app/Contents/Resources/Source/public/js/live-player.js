// Delayed live player. Plays the processed HLS stream and holds playback at the
// broadcast's target delay, measured against the capture time stamped on every segment
// (EXT-X-PROGRAM-DATE-TIME). The delay shown is measured, not assumed.

let hlsLoader = null;
function loadHls() {
  if (window.Hls) return Promise.resolve(window.Hls);
  hlsLoader ||= new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = '/vendor/hls.min.js';
    s.onload = () => resolve(window.Hls);
    s.onerror = () => reject(new Error('Could not load the video player library'));
    document.head.append(s);
  });
  return hlsLoader;
}

export async function attachLivePlayer(video, playlistUrl, { targetDelaySec, clockOffsetMs = 0, onStats }) {
  let hls = null;
  const Hls = await loadHls().catch(() => null);
  if (Hls && Hls.isSupported()) {
    hls = new Hls({
      lowLatencyMode: false,
      liveSyncDuration: Math.max(2, targetDelaySec - 4), // start near the target; the controller below does the rest
      liveMaxLatencyDuration: 600, // never jump ahead on its own; we manage delay explicitly
      maxLiveSyncPlaybackRate: 1,
      manifestLoadingMaxRetry: 20, levelLoadingMaxRetry: 20, fragLoadingMaxRetry: 20,
    });
    hls.loadSource(playlistUrl);
    hls.attachMedia(video);
    hls.on(Hls.Events.ERROR, (_, data) => {
      if (data.fatal && data.type === Hls.ErrorTypes.NETWORK_ERROR) setTimeout(() => hls.startLoad(), 1500);
      else if (data.fatal && data.type === Hls.ErrorTypes.MEDIA_ERROR) hls.recoverMediaError();
    });
  } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
    video.src = playlistUrl; // Safari's built-in HLS
  } else {
    throw new Error('This browser can’t play the live stream.');
  }

  // Wall-clock capture time of the frame being shown right now.
  const playingDate = () => {
    if (hls?.playingDate) return hls.playingDate.getTime();
    const d = video.getStartDate?.();
    if (d && !Number.isNaN(d.getTime())) return d.getTime() + video.currentTime * 1000;
    return null;
  };

  let delay = null;
  const tick = () => {
    const pd = playingDate();
    const serverNow = Date.now() + clockOffsetMs;
    delay = pd ? (serverNow - pd) / 1000 : null;
    const ahead = video.buffered.length ? video.buffered.end(video.buffered.length - 1) - video.currentTime : 0;
    if (delay !== null && !video.paused) {
      // Gentle speed changes keep the delay near the target without skipping content.
      if (delay < targetDelaySec - 0.6) video.playbackRate = 0.9;
      else if (delay > targetDelaySec + 0.8 && ahead > 1.5) video.playbackRate = 1.1;
      else video.playbackRate = 1;
    }
    onStats?.({ delaySec: delay, bufferedAheadSec: ahead, waiting: video.readyState < 3 && !video.paused, capturedAt: pd });
  };
  const timer = setInterval(tick, 500);
  return {
    destroy() { clearInterval(timer); hls?.destroy(); video.removeAttribute('src'); video.load(); },
    playingDate,
  };
}

export async function measureClockOffset() {
  // Server clock minus this device's clock, from a few round trips.
  let best = null;
  for (let i = 0; i < 3; i++) {
    const t0 = Date.now();
    const r = await fetch('/api/live/time', { cache: 'no-store' }).then((x) => x.json());
    const t1 = Date.now();
    const rtt = t1 - t0;
    if (!best || rtt < best.rtt) best = { rtt, offset: r.serverNow - (t0 + rtt / 2) };
  }
  return best.offset;
}
