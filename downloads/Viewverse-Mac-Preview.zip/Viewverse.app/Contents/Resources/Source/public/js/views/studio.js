// Creator Studio home: record / upload / go live, and every video's pipeline state.
import { h, icon, api, fmtDur, fmtAgo, fmtBytes, empty, toast } from '../lib.js';
import { navigate } from '../app.js';
import { startUpload, sendFile } from '../uploader.js';

export const STATUS = {
  draft: ['Draft', ''], uploading: ['Uploading', 'accent'], queued: ['Queued', 'accent'], processing: ['Processing', 'accent'],
  ready: ['Ready for review', 'warn'], published: ['Published', 'ok'], failed: ['Failed', 'bad'], cancelled: ['Cancelled', ''],
};

// Uploads in progress in this tab, so the list can show live progress.
const active = new Map();

export async function render({ onCleanup }) {
  const [status, list, connect] = await Promise.all([api('GET', '/api/studio/status'), api('GET', '/api/studio/videos'), api('GET', '/api/studio/connect')]);
  const fileInput = h('input', { type: 'file', accept: 'video/mp4,video/quicktime,video/webm,video/x-matroska,video/3gpp,.mp4,.mov,.m4v,.webm,.mkv,.3gp', class: 'hidden' });
  fileInput.onchange = () => { if (fileInput.files[0]) beginUpload(fileInput.files[0]); fileInput.value = ''; };

  const listEl = h('div', {});
  const draw = (videos) => listEl.replaceChildren(...(videos.length ? videos.map(row) : [empty('camera', 'No recordings yet', h('p', {}, 'Record with your camera or upload a video to try the editing pipeline.'))]));
  draw(list.videos);

  const timer = setInterval(async () => {
    try { draw((await api('GET', '/api/studio/videos')).videos); } catch {}
  }, 1500);
  onCleanup(() => clearInterval(timer));

  const ai = status.ai;
  const storagePct = Math.min(100, (status.storage.usedBytes / status.storage.quotaBytes) * 100);
  return h('div', {},
    h('div', { class: 'studio-head' }, h('h1', { style: { margin: 0 } }, 'Creator Studio'), h('a', {href:'/rec', 'data-link':true, class:'btn primary'}, 'Rec · Tell your story'), h('span', { class: 'spacer' }),
      h('span', { class: 'chip' }, icon('lock'), 'Private to you')),
    h('div', { class: 'actions3' },
      h('button', { class: 'action', onclick: () => navigate('/studio/record') }, icon('camera'), h('div', {}, h('b', {}, 'Record'), h('div', { class: 'small muted' }, 'Use this device’s camera'))),
      h('button', { class: 'action', onclick: () => fileInput.click() }, icon('upload'), h('div', {}, h('b', {}, 'Upload'), h('div', { class: 'small muted' }, `MP4, MOV, WebM · up to ${status.limits.maxUploadMB} MB, ${Math.round(status.limits.maxDurationSec / 60)} min`))),
      h('button', { class: 'action live', onclick: () => navigate('/studio/live') }, icon('live'), h('div', {}, h('b', {}, 'Go live'), h('div', { class: 'small muted' }, 'Delayed broadcast with processing')))),
    fileInput,
    h('h2', {}, 'Your videos'),
    listEl,
    h('h2', {}, 'Connect your phone'),
    h('div', { class: 'card stack small' },
      h('div', {}, '1. Put the phone on the same Wi-Fi as this laptop.'),
      h('div', {}, '2. One time only: on the phone open ', connect.setupUrls.map((u, i) => [i ? ' or ' : '', h('code', {}, u)]), ' and follow the steps to trust the Viewverse certificate.'),
      h('div', {}, '3. Then open ', connect.appUrls.map((u, i) => [i ? ' or ' : '', h('code', {}, u)]), ' and sign in.'),
      connect.caFingerprint ? h('div', { class: 'muted', style: { wordBreak: 'break-all' } }, 'Certificate fingerprint to compare on the phone: ', h('code', {}, connect.caFingerprint)) : null),
    h('h2', {}, 'This laptop'),
    h('div', { class: 'card stack' },
      h('div', { class: 'row' }, h('b', {}, 'Storage'), h('span', { class: 'spacer' }), h('span', { class: 'muted small' }, `${fmtBytes(status.storage.usedBytes)} of ${fmtBytes(status.storage.quotaBytes)} used · ${status.storage.freeDiskBytes ? fmtBytes(status.storage.freeDiskBytes) + ' free on disk' : ''}`)),
      h('div', { class: 'progress' }, h('i', { style: { width: `${storagePct}%` } })),
      h('div', { class: 'row small' }, h('b', {}, 'Captions: '), aiLine(ai.transcription)),
      h('div', { class: 'row small' }, h('b', {}, 'Title suggestions: '), aiLine(ai.suggestions)),
      h('p', { class: 'small muted', style: { margin: 0 } }, 'AI runs on this Mac. Your recordings and transcripts are not sent to any online service.'),
      h('div', { class: 'row' },
        h('button', { class: 'btn sm danger', onclick: async () => {
          if (!confirm('Delete every video that is not published (drafts, failed, cancelled and unpublished reviews)? Originals are deleted too. This can’t be undone.')) return;
          const r = await api('POST', '/api/studio/cleanup', { scope: 'unpublished' });
          toast(`Deleted ${r.deleted} test recording${r.deleted === 1 ? '' : 's'}`);
          draw((await api('GET', '/api/studio/videos')).videos);
        } }, icon('trash'), 'Delete unpublished test recordings'))));
}

function aiLine(s) {
  return s.available ? h('span', { class: 'chip ok' }, h('span', { class: 'dot' }), `${s.engine} — ready`) : h('span', { class: 'chip warn' }, `Unavailable: ${s.reason}`);
}

function row(v) {
  const [label, tone] = STATUS[v.status] || [v.status, ''];
  const local = active.get(v.id);
  const pct = v.status === 'uploading' || v.status === 'draft' ? (local ? local.sent / local.total : v.receivedBytes / v.sizeBytes) : v.progress;
  const busy = ['uploading', 'queued', 'processing'].includes(v.status);
  const thumb = v.hasThumb ? h('img', { src: `/api/studio/videos/${v.id}/media/thumb?n=${v.selectedThumb}&v=${v.updatedAt}`, alt: '' }) : h('div', { style: { display: 'grid', placeItems: 'center', height: '100%', color: 'var(--muted)' } }, icon(v.source === 'browser-recording' ? 'camera' : 'upload'));
  const actions = [];
  if (['ready', 'published'].includes(v.status)) actions.push(h('a', { class: 'btn sm primary', href: `/studio/video/${v.id}`, 'data-link': true }, v.status === 'ready' ? 'Review' : 'Manage'));
  if (v.status === 'published') actions.push(h('a', { class: 'btn sm', href: `/watch/${v.publicId}`, 'data-link': true }, icon('play'), 'Watch'));
  if (['queued', 'processing'].includes(v.status)) actions.push(h('button', { class: 'btn sm', onclick: () => act(v, 'cancel') }, 'Cancel'));
  if (['failed', 'cancelled'].includes(v.status) && v.attempts < v.maxAttempts) actions.push(h('button', { class: 'btn sm', onclick: () => act(v, 'retry') }, icon('retry'), 'Retry'));
  if (['draft', 'uploading'].includes(v.status) && !local) actions.push(resumeButton(v));
  if (!busy || (['draft', 'uploading'].includes(v.status) && !local)) actions.push(h('button', { class: 'btn sm danger', title: 'Delete', onclick: () => del(v) }, icon('trash')));
  return h('div', { class: 'vrow' },
    h('a', { class: 'thumb', href: `/studio/video/${v.id}`, 'data-link': true }, thumb),
    h('div', { style: { minWidth: 0 } },
      h('a', { href: `/studio/video/${v.id}`, 'data-link': true }, h('div', { class: 'vtitle' }, v.title || v.originalName)),
      h('div', { class: 'row small muted', style: { marginTop: '4px' } },
        h('span', { class: `chip ${tone}` }, busy ? h('span', { class: 'dot pulse' }) : null, label),
        v.duration ? h('span', {}, fmtDur(v.duration)) : null, h('span', {}, fmtAgo(v.createdAt))),
      busy ? h('div', { style: { marginTop: '8px' } }, h('div', { class: 'progress' }, h('i', { style: { width: `${Math.round(pct * 100)}%` } })),
        h('div', { class: 'small muted', style: { marginTop: '4px' } }, local?.message || v.step || (v.status === 'queued' ? 'Waiting for the laptop to start processing' : v.status === 'uploading' ? `Uploaded ${fmtBytes(v.receivedBytes)} of ${fmtBytes(v.sizeBytes)}` : ''))) : null,
      v.error && ['failed', 'cancelled'].includes(v.status) ? h('div', { class: 'small', style: { color: v.status === 'failed' ? 'var(--bad)' : 'var(--muted)', marginTop: '6px' } }, v.error) : null,
      ['draft', 'uploading'].includes(v.status) && !local ? h('div', { class: 'small muted', style: { marginTop: '6px' } }, 'Upload interrupted. Press Resume and choose the same file to continue where it stopped.') : null),
    h('div', { class: 'row-actions' }, actions));
}

function resumeButton(v) {
  const input = h('input', { type: 'file', accept: 'video/*', class: 'hidden' });
  input.onchange = () => { const f = input.files[0]; if (f) runUpload(v.id, f); };
  return h('span', {}, input, h('button', { class: 'btn sm', onclick: () => input.click() }, icon('upload'), 'Resume'));
}

async function act(v, what) {
  try { await api('POST', `/api/studio/videos/${v.id}/${what}`, {}); toast(what === 'retry' ? 'Queued again' : 'Cancelled'); }
  catch (e) { toast(e.message); }
}

async function del(v) {
  if (!confirm(`Delete “${v.title || v.originalName}”? The original and all edited copies are removed from this laptop.`)) return;
  try { await api('DELETE', `/api/studio/videos/${v.id}`); toast('Deleted'); } catch (e) { toast(e.message); }
}

export async function beginUpload(file, { source = 'upload', name } = {}) {
  try {
    const id = await startUpload(file, { source, name });
    runUpload(id, file);
    return id;
  } catch (e) { toast(e.message, 6000); throw e; }
}

async function runUpload(id, file) {
  active.set(id, { sent: 0, total: file.size });
  try {
    await sendFile(id, file, { onProgress: (p) => active.set(id, { ...p }) });
    toast('Upload complete — processing started');
  } catch (e) {
    toast(e.message, 6000);
  } finally { active.delete(id); }
}
