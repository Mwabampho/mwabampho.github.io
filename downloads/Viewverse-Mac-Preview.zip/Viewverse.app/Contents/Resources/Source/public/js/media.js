// Browser media capability helpers shared by recording and live.

// 'file' prefers MP4 (plays everywhere after upload); 'live' prefers WebM, which streams
// into the laptop's encoder most reliably. Both are supported by the server.
export function pickRecorderMime(purpose) {
  if (typeof MediaRecorder === 'undefined') return null;
  const mp4 = ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4;codecs=avc1,mp4a', 'video/mp4'];
  const webm = ['video/webm;codecs=vp8,opus', 'video/webm;codecs=vp9,opus', 'video/webm'];
  const order = purpose === 'live' ? [...webm, ...mp4] : [...mp4, ...webm];
  return order.find((m) => MediaRecorder.isTypeSupported?.(m)) || null;
}

export function cameraErrorHelp(e) {
  const ios = /iPhone|iPad|iPod/.test(navigator.userAgent);
  switch (e?.name) {
    case 'NotAllowedError':
    case 'SecurityError':
      return {
        title: 'Camera or microphone permission was denied.',
        body: ios
          ? 'On iPhone: tap “aA” in Safari’s address bar → Website Settings → set Camera and Microphone to Allow, then try again. (Or Settings → Apps → Safari → Camera/Microphone.)'
          : 'In Chrome: tap the icon left of the address → Permissions → allow Camera and Microphone, then try again. On a laptop, also check System Settings → Privacy & Security → Camera.',
      };
    case 'NotFoundError':
    case 'OverconstrainedError':
      return { title: 'No camera was found.', body: 'This device has no camera the browser can use (or the requested camera isn’t available).' };
    case 'NotReadableError':
    case 'AbortError':
      return { title: 'The camera is busy.', body: 'Another app or tab may be using the camera. Close it and try again.' };
    default:
      return { title: 'The camera could not be started.', body: e?.message || 'Unknown error.' };
  }
}

export async function requestWakeLock() {
  try { return await navigator.wakeLock?.request('screen'); } catch { return null; }
}
