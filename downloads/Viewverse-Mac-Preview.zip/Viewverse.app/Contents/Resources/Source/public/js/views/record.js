// In-browser recording. Needs a secure context (HTTPS with a trusted certificate) for the
// camera. If that's not available, or permission is denied, the phone's own camera app
// can be used through a normal file picker instead – that works everywhere.
import { h, icon, api, fmtDur, fmtBytes, toast } from '../lib.js';
import { navigate } from '../app.js';
import { beginUpload } from './studio.js';
import { pickRecorderMime, cameraErrorHelp, requestWakeLock } from '../media.js';

export async function render({ onCleanup }) {
  const status = await api('GET', '/api/studio/status');
  const maxSec = status.limits.maxDurationSec;
  const preview = h('video', { playsinline: true, autoplay: true, muted: true });
  const box = h('div', { class: 'camera' }, preview);
  const msg = h('div', {});
  const timer = h('span', { class: 'chip livechip rec hidden' }, h('span', { class: 'dot pulse' }), '0:00');
  box.append(timer);
  let stream = null, recorder = null, chunks = [], facing = 'user', started = 0, tick = null, wake = null;

  // Fallback that always works on phones: the native camera app via a file input.
  const nativeInput = h('input', { type: 'file', accept: 'video/*', capture: 'user', class: 'hidden' });
  nativeInput.onchange = async () => { const f = nativeInput.files[0]; if (f) { await beginUpload(f, { source: 'upload' }); navigate('/studio'); } };
  const nativeBtn = h('button', { class: 'btn', onclick: () => nativeInput.click() }, icon('camera'), 'Use the phone’s camera app instead');

  const stopTracks = () => { stream?.getTracks().forEach((t) => t.stop()); stream = null; };
  onCleanup(() => { clearInterval(tick); if (recorder?.state === 'recording') recorder.stop(); stopTracks(); wake?.release?.(); });

  async function openCamera() {
    stopTracks();
    msg.replaceChildren();
    if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) {
      msg.replaceChildren(h('div', { class: 'notice warn stack' },
        h('b', {}, 'This browser won’t allow the camera on this connection.'),
        h('p', { style: { margin: 0 } }, 'Browsers only allow camera recording on secure (HTTPS) pages. Install the Viewverse certificate on this phone (see the README, “Connect your phone”), then reload. Until then, record with your phone’s camera app:'),
        nativeBtn));
      recBtn.disabled = true;
      return;
    }
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: facing, width: { ideal: 1920 }, height: { ideal: 1080 }, frameRate: { ideal: 30 } },
        audio: { echoCancellation: true, noiseSuppression: false, autoGainControl: false },
      });
      preview.srcObject = stream;
      preview.classList.toggle('mirror', facing === 'user');
      recBtn.disabled = false;
      await new Promise((r) => (preview.onloadedmetadata = r));
      box.classList.toggle('portrait', preview.videoHeight > preview.videoWidth);
    } catch (e) {
      recBtn.disabled = true;
      msg.replaceChildren(h('div', { class: 'notice bad stack' }, h('b', {}, cameraErrorHelp(e).title), h('p', { style: { margin: 0 } }, cameraErrorHelp(e).body), nativeBtn,
        h('button', { class: 'btn ghost', onclick: openCamera }, icon('retry'), 'Try again')));
    }
  }

  const recBtn = h('button', { class: 'bigrec', 'aria-label': 'Start recording', disabled: true });
  const flipBtn = h('button', { class: 'btn', onclick: () => { facing = facing === 'user' ? 'environment' : 'user'; openCamera(); } }, icon('flip'), 'Switch camera');
  recBtn.onclick = async () => {
    if (recorder?.state === 'recording') { recorder.stop(); return; }
    const mime = pickRecorderMime('file');
    try { recorder = new MediaRecorder(stream, mime ? { mimeType: mime, videoBitsPerSecond: 6_000_000 } : undefined); }
    catch (e) { toast(`Recording isn’t supported in this browser: ${e.message}`); return; }
    chunks = [];
    recorder.ondataavailable = (e) => { if (e.data.size) chunks.push(e.data); };
    recorder.onstop = () => finish(recorder.mimeType || mime || 'video/webm');
    recorder.start(1000);
    started = Date.now();
    wake = await requestWakeLock();
    recBtn.classList.add('on'); recBtn.setAttribute('aria-label', 'Stop recording');
    flipBtn.disabled = true;
    timer.classList.remove('hidden');
    tick = setInterval(() => {
      const s = (Date.now() - started) / 1000;
      timer.lastChild.textContent = fmtDur(s);
      if (s >= maxSec) { recorder.stop(); toast(`Stopped at the ${Math.round(maxSec / 60)}-minute limit`); }
    }, 250);
  };

  function finish(mime) {
    clearInterval(tick); wake?.release?.();
    recBtn.classList.remove('on'); flipBtn.disabled = false; timer.classList.add('hidden');
    const blob = new Blob(chunks, { type: mime.split(';')[0] });
    const ext = blob.type.includes('mp4') ? 'mp4' : 'webm';
    const dur = (Date.now() - started) / 1000;
    const url = URL.createObjectURL(blob);
    const take = h('video', { src: url, controls: true, playsinline: true });
    stopTracks();
    const panel = h('div', { class: 'card stack' },
      h('h2', { style: { margin: 0 } }, 'Your take'),
      take,
      h('div', { class: 'muted small' }, `${fmtDur(dur)} · ${fmtBytes(blob.size)} · ${ext.toUpperCase()}`),
      h('div', { class: 'row' },
        h('button', { class: 'btn primary', onclick: async (e) => {
          e.target.disabled = true;
          const stamp = new Date().toISOString().slice(0, 16).replace('T', ' ').replace(':', '.');
          const file = new File([blob], `Recording ${stamp}.${ext}`, { type: blob.type });
          try { await beginUpload(file, { source: 'browser-recording' }); URL.revokeObjectURL(url); navigate('/studio'); }
          catch { e.target.disabled = false; }
        } }, icon('upload'), 'Use this take'),
        h('button', { class: 'btn', onclick: () => { URL.revokeObjectURL(url); panel.remove(); box.classList.remove('hidden'); controls.classList.remove('hidden'); openCamera(); } }, icon('retry'), 'Retake')));
    box.classList.add('hidden'); controls.classList.add('hidden');
    page.append(panel);
  }

  const controls = h('div', { class: 'recbar' }, flipBtn, recBtn, h('span', { class: 'muted small', style: { width: '160px' } }, `Up to ${Math.round(maxSec / 60)} min. Keep the phone in one orientation while recording.`));
  const page = h('div', { class: 'stack' },
    h('div', { class: 'row' }, h('a', { class: 'btn sm ghost', href: '/studio', 'data-link': true }, icon('back'), 'Studio'), h('h1', { style: { margin: 0 } }, 'Record')),
    msg, box, controls, nativeInput,
    h('p', { class: 'muted small' }, 'The recording stays on this device until you choose “Use this take”. It is then stored privately on your laptop and processed there.'));
  openCamera();
  return page;
}
