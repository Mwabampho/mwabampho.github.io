// Live viewer page. Shows the processed, delayed stream with an honest status and the
// delay measured on this device.
import { h, icon, api, fmtDur } from '../lib.js';
import { attachLivePlayer, measureClockOffset } from '../live-player.js';

export const LIVE_LABEL = {
  starting: 'Starting', processing: 'Processing', broadcasting: 'Broadcasting with delay', holding: 'Holding',
  reconnecting: 'Reconnecting', ended: 'Ended', failed: 'Stopped',
};
const HOLD_TEXT = {
  starting: 'Starting — waiting for the broadcaster’s camera.',
  processing: 'Processing the first seconds of video…',
  reconnecting: 'The broadcaster’s connection dropped. Holding until it comes back.',
  holding: 'Processing is catching up. Holding rather than showing unprocessed video.',
};

export async function render({ params, onCleanup }) {
  const id = params[0];
  let st;
  try { st = await api('GET', `/api/live/${id}`); }
  catch (e) { return h('div', { class: 'empty' }, icon('lock'), h('p', {}, e.message)); }

  const video = h('video', { playsinline: true, autoplay: true, controls: true, muted: true });
  const statusChip = h('span', { class: 'chip' });
  const delayChip = h('span', { class: 'chip' });
  const hold = h('div', { class: 'hold hidden' });
  const caption = h('div', { class: 'captionbar hidden' });
  const unmute = h('button', { class: 'btn sm', onclick: () => { video.muted = false; unmute.remove(); } }, 'Tap for sound');
  const replayNote = h('div', { class: 'notice hidden' }, 'This broadcast has ended. You are watching a replay of the processed stream, not a live picture.');

  let offset = 0;
  try { offset = await measureClockOffset(); } catch {}
  let stats = {};
  let player = null;
  const startPlayer = async () => {
    if (player) return;
    player = await attachLivePlayer(video, `/api/live/${id}/playlist.m3u8`, { targetDelaySec: st.targetDelaySec, clockOffsetMs: offset, onStats: (s) => { stats = s; paint(); } });
  };

  let cues = [];
  const startedEl = h('p', { class: 'muted small' });
  const paint = () => {
    const ended = ['ended', 'failed'].includes(st.status);
    statusChip.replaceChildren(...[st.status === 'broadcasting' ? h('span', { class: 'dot pulse' }) : null, LIVE_LABEL[st.status] || st.status].filter(Boolean));
    startedEl.textContent = st.startedAt ? `Started ${new Date(st.startedAt).toLocaleTimeString()}${st.stats.broadcastSec ? ` · ${fmtDur(st.stats.broadcastSec)}` : ''}` : '';
    statusChip.className = `chip ${st.status === 'broadcasting' ? 'livechip' : ended ? '' : 'warn'}`;
    if (!ended && stats.delaySec != null) {
      delayChip.textContent = `${stats.delaySec.toFixed(1)} s behind real time (target ${st.targetDelaySec} s)`;
      delayChip.classList.remove('hidden');
    } else delayChip.classList.add('hidden');
    const holdMsg = HOLD_TEXT[st.status] || (!ended && stats.waiting ? 'Holding for the next processed segment…' : null);
    hold.textContent = holdMsg || '';
    hold.classList.toggle('hidden', !holdMsg || (st.status === 'broadcasting' && !stats.waiting));
    replayNote.classList.toggle('hidden', !ended);
    const cue = stats.capturedAt ? cues.find((c) => stats.capturedAt >= c.start && stats.capturedAt <= c.end + 400) : null;
    caption.textContent = cue ? cue.text : '';
    caption.classList.toggle('hidden', !cue);
  };

  const poll = async () => {
    try { st = await api('GET', `/api/live/${id}`); } catch {}
    if (st.stats.segments > 0) startPlayer();
    if (st.captions && stats.capturedAt) {
      try { cues = (await api('GET', `/api/live/${id}/captions?since=${Math.round(stats.capturedAt - 15000)}`)).cues; } catch {}
    }
    paint();
  };
  await poll();
  const timer = setInterval(poll, 1500);
  onCleanup(() => { clearInterval(timer); player?.destroy(); });

  return h('div', { class: 'stack' },
    h('div', { class: 'player' }, video, h('div', { class: 'live-overlay' }, statusChip, delayChip), hold, caption),
    h('div', { class: 'row' }, h('h1', { style: { margin: 0, flex: 1 } }, st.title), unmute),
    replayNote,
    h('p', { class: 'muted small' }, `Viewverse broadcasts are delayed by about ${st.targetDelaySec} seconds so the video can be processed before you see it. The delay shown above is measured on this device.`),
    startedEl);
}
