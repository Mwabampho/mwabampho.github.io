// Review screen: compare original vs edited, see exactly what was applied, toggle
// optional edits, correct captions, choose thumbnail/title, then approve or reject.
import { h, icon, api, fmtDur, fmtAgo, fmtBytes, fmtTime, toast, errorBox } from '../lib.js';
import { navigate } from '../app.js';
import { STATUS } from './studio.js';

const FLOW = ['draft', 'uploading', 'queued', 'processing', 'ready', 'published'];
const OPTION_LABELS = {
  captions: ['Captions', 'Transcribe speech on this Mac (AI)'],
  normalize: ['Even out audio level', 'Conservative loudness normalisation to −16 LUFS'],
  denoise: ['Reduce background noise', 'Gentle noise reduction; best for fans, hum or traffic'],
  trimSilence: ['Trim long silences', 'Cut pauses longer than 1.5 s (keeps a little room around speech)'],
  suggest: ['Suggest a title & description', 'Written by the on-device language model from your words (AI)'],
};
const STATE_ICON = { applied: ['check', 'var(--ok)'], checked: ['check', 'var(--muted)'], skipped: ['minus', 'var(--muted)'], disabled: ['off', 'var(--muted)'], unavailable: ['alert', 'var(--warn)'], failed: ['alert', 'var(--bad)'] };
const STATE_TEXT = { applied: 'Applied', checked: 'Checked', skipped: 'Not needed', disabled: 'Off', unavailable: 'Unavailable', failed: 'Failed' };

export async function render({ params, onCleanup }) {
  const id = params[0];
  const root = h('div', {});
  let v = await api('GET', `/api/studio/videos/${id}`);
  let lastStatus = null;

  const draw = () => {
    lastStatus = v.status;
    root.replaceChildren(header(v), ['ready', 'published'].includes(v.status) ? reviewBody(v, (nv) => { v = nv; draw(); }) : progressBody(v));
  };
  draw();
  // While processing, poll; redraw fully when the state changes.
  const timer = setInterval(async () => {
    const inProgress = (s) => ['draft', 'uploading', 'queued', 'processing'].includes(s);
    if (!inProgress(v.status)) return;
    try {
      const nv = await api('GET', `/api/studio/videos/${id}`);
      v = nv;
      if (nv.status !== lastStatus || inProgress(nv.status)) draw();
    } catch {}
  }, 1200);
  onCleanup(() => clearInterval(timer));
  return root;
}

function header(v) {
  const bad = ['failed', 'cancelled'].includes(v.status);
  const idx = FLOW.indexOf(v.status);
  const steps = FLOW.map((s, i) => h('span', { class: s === v.status ? 'now' : i < idx ? 'done' : '' }, STATUS[s][0]));
  if (bad) steps.push(h('span', { class: 'badnow' }, STATUS[v.status][0]));
  return h('div', {},
    h('div', { class: 'row' }, h('a', { class: 'btn sm ghost', href: '/studio', 'data-link': true }, icon('back'), 'Studio'),
      h('h1', { style: { margin: 0, flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } }, v.title || v.originalName)),
    h('div', { class: 'timeline', 'aria-label': 'Pipeline state' }, steps),
    h('div', { class: 'muted small', style: { marginBottom: '14px' } }, `${v.source === 'browser-recording' ? 'Recorded in browser' : 'Uploaded'} ${fmtAgo(v.createdAt)} · original “${v.originalName}” (${fmtBytes(v.sizeBytes)}) kept privately`));
}

function progressBody(v) {
  const box = h('div', { class: 'card stack' });
  if (['uploading', 'draft'].includes(v.status)) {
    box.append(h('b', {}, 'Uploading…'), h('div', { class: 'progress' }, h('i', { style: { width: `${Math.round((v.receivedBytes / v.sizeBytes) * 100)}%` } })),
      h('p', { class: 'muted small' }, 'If the upload stopped, go back to Studio and press Resume.'));
  } else if (['queued', 'processing'].includes(v.status)) {
    box.append(h('b', {}, v.step || 'Waiting to start'), h('div', { class: 'progress' }, h('i', { style: { width: `${Math.round(v.progress * 100)}%` } })),
      reportList(v.report),
      h('div', { class: 'row' }, h('button', { class: 'btn', onclick: async () => { await api('POST', `/api/studio/videos/${v.id}/cancel`); toast('Cancelled'); } }, 'Cancel processing')));
  } else {
    box.append(errorBox({ message: v.error || 'Processing did not finish.' }));
    if (v.report?.length) box.append(h('h3', {}, 'Steps completed before it stopped'), reportList(v.report));
    const opts = optionsForm(v.options);
    box.append(h('h3', {}, 'Try again with these edits'), opts.el,
      h('div', { class: 'row' },
        v.attempts < v.maxAttempts ? h('button', { class: 'btn primary', onclick: () => retry(v, opts.value()) }, icon('retry'), `Retry (attempt ${v.attempts + 1} of ${v.maxAttempts})`) : h('span', { class: 'muted' }, 'No retries left for this file.'),
        h('button', { class: 'btn danger', onclick: () => remove(v) }, icon('trash'), 'Delete')));
  }
  return box;
}

function reportList(report = []) {
  if (!report.length) return h('div', {});
  return h('div', { class: 'report' }, h('ul', {}, report.map((r) => {
    const [ic, color] = STATE_ICON[r.status] || ['info', 'var(--muted)'];
    return h('li', {}, h('span', { style: { color } }, icon(ic)),
      h('div', {}, h('div', { class: 'row', style: { gap: '6px' } }, h('b', {}, r.label), h('span', { class: `chip ${r.kind === 'ai' ? 'accent' : ''}` }, r.kind === 'ai' ? 'AI · on-device' : 'Media processing'), h('span', { class: 'small muted' }, STATE_TEXT[r.status] || r.status)),
        h('div', { class: 'small muted' }, r.detail)));
  })));
}

function optionsForm(options) {
  const inputs = {};
  const el = h('div', {}, Object.entries(OPTION_LABELS).map(([k, [label, sub]]) => {
    inputs[k] = h('input', { type: 'checkbox', checked: !!options[k] });
    return h('label', { class: 'check' }, inputs[k], h('div', {}, h('b', {}, label), h('div', { class: 'small muted' }, sub)));
  }));
  return { el, value: () => Object.fromEntries(Object.entries(inputs).map(([k, i]) => [k, i.checked])) };
}

async function retry(v, options) {
  try { await api('POST', `/api/studio/videos/${v.id}/retry`, { options }); toast('Processing again'); location.reload(); }
  catch (e) { toast(e.message, 6000); }
}

async function remove(v) {
  if (!confirm('Delete this video, its original and all edited copies from the laptop?')) return;
  await api('DELETE', `/api/studio/videos/${v.id}`);
  navigate('/studio');
}

function reviewBody(v, setV) {
  const base = `/api/studio/videos/${v.id}/media`;
  const stamp = v.updatedAt;
  const edited = h('video', { controls: true, playsinline: true, preload: 'metadata', src: `${base}/edited?v=${stamp}` },
    h('track', { kind: 'captions', src: `${base}/captions?v=${stamp}`, srclang: 'en', label: 'Captions (draft)', default: true }));
  const original = h('video', { controls: true, playsinline: true, preload: 'metadata', src: `${base}/comparison?v=${stamp}` });
  // Only one plays at a time so you can hear the difference.
  edited.onplay = () => original.pause();
  original.onplay = () => edited.pause();
  const probe = v.probe || {};

  // --- Title & description ---
  const title = h('input', { type: 'text', value: v.title, maxlength: 100, placeholder: 'Add a title' });
  const desc = h('textarea', { maxlength: 2000, placeholder: 'Describe your video' }, v.description);
  const useSuggestion = v.suggestion && (v.suggestion.title !== v.title || v.suggestion.description !== v.description)
    ? h('button', { class: 'btn sm', onclick: () => { title.value = v.suggestion.title; desc.value = v.suggestion.description; } }, icon('spark'), 'Use AI suggestion') : null;

  // --- Thumbnails ---
  let selThumb = v.selectedThumb;
  const thumbBtns = v.thumbs.map((t) => h('button', { class: t.index === selThumb ? 'sel' : '', title: `Frame at ${fmtDur(t.time)}`, onclick: (e) => {
    selThumb = t.index; thumbBtns.forEach((b) => b.classList.remove('sel')); e.currentTarget.classList.add('sel');
  } }, h('img', { src: `${base}/thumb?n=${t.index}&v=${stamp}`, alt: `Frame at ${fmtDur(t.time)}` })));

  // --- Captions editor ---
  let cues = v.captions.map((c) => ({ ...c }));
  const cueList = h('div', { class: 'cues' });
  const drawCues = () => cueList.replaceChildren(...(cues.length ? cues.map((c, i) => h('div', { class: 'cue' },
    h('span', { class: 't', title: 'Play from here', onclick: () => { edited.currentTime = c.start; edited.play(); } }, `${fmtTime(c.start)}–${fmtTime(c.end)}`),
    h('input', { type: 'text', value: c.text, 'aria-label': `Caption ${i + 1}`, oninput: (e) => { c.text = e.target.value; } }),
    h('button', { class: 'iconbtn', title: 'Remove caption', onclick: () => { cues.splice(i, 1); drawCues(); } }, icon('x')))) : [h('p', { class: 'muted small' }, 'No captions for this video.')]));
  drawCues();

  const save = async (extra = {}) => {
    const nv = await api('PATCH', `/api/studio/videos/${v.id}`, { title: title.value, description: desc.value, selectedThumb: selThumb, captions: cues, ...extra });
    return nv;
  };

  const opts = optionsForm(v.options);
  const published = v.status === 'published';
  const publishBtn = h('button', { class: 'btn primary', onclick: async () => {
    try {
      await save();
      const nv = await api('POST', `/api/studio/videos/${v.id}/publish`, { version: 'edited' });
      toast('Published to your Viewverse feed'); setV(nv);
    } catch (e) { toast(e.message, 6000); }
  } }, icon('check'), published && v.publishedVersion === 'edited' ? 'Save changes' : 'Approve edited version & publish');
  const originalBtn = h('button', { class: 'btn', onclick: async () => {
    if (!confirm('Publish the original, unedited version instead? None of the edits (trimming, audio, noise) will be applied. Your captions, title and thumbnail are still used.')) return;
    try { await save(); const nv = await api('POST', `/api/studio/videos/${v.id}/publish`, { version: 'original' }); toast('Published the original version'); setV(nv); }
    catch (e) { toast(e.message, 6000); }
  } }, published && v.publishedVersion === 'original' ? 'Save changes (original published)' : 'Reject edits — publish original');

  return h('div', { class: 'review' },
    h('div', { class: 'stack' },
      published ? h('div', { class: 'notice' }, h('b', {}, `Published (${v.publishedVersion === 'original' ? 'original version' : 'edited version'}). `),
        h('a', { href: `/watch/${v.publicId}`, 'data-link': true, style: { color: 'var(--accent)' } }, 'Watch it in the feed →')) : null,
      h('div', { class: 'compare' },
        h('div', {}, h('div', { class: 'row', style: { marginBottom: '6px' } }, h('b', {}, 'Edited'), h('span', { class: 'muted small' }, fmtDur(probe.editedDuration))), edited),
        h('div', {}, h('div', { class: 'row', style: { marginBottom: '6px' } }, h('b', {}, 'Original'), h('span', { class: 'muted small' }, `${fmtDur(probe.duration)} · unedited`)), original)),
      h('div', { class: 'card' }, h('h3', { style: { marginTop: 0 } }, 'What changed'), reportList(v.report)),
      h('div', { class: 'card' },
        h('div', { class: 'row' }, h('h3', { style: { margin: 0 } }, 'Captions'), h('span', { class: 'spacer' }), h('span', { class: 'small muted' }, 'Auto-transcribed — please check spelling and names')),
        cueList,
        cues.length ? h('button', { class: 'btn sm', style: { marginTop: '10px' }, onclick: async () => { try { const nv = await save(); toast('Captions saved'); edited.querySelector('track').src = `${base}/captions?v=${nv.updatedAt}`; } catch (e) { toast(e.message); } } }, 'Save captions') : null)),
    h('div', { class: 'stack' },
      h('div', { class: 'card stack' },
        h('label', { class: 'field' }, h('span', {}, 'Title'), title),
        h('label', { class: 'field' }, h('span', {}, 'Description'), desc),
        useSuggestion,
        h('div', {}, h('div', { class: 'small muted', style: { marginBottom: '6px', fontWeight: 600 } }, 'Thumbnail (real frames from your video)'), h('div', { class: 'thumbs' }, thumbBtns)),
        publishBtn, originalBtn,
        published ? h('button', { class: 'btn ghost', onclick: async () => { const nv = await api('POST', `/api/studio/videos/${v.id}/unpublish`); toast('Removed from the feed'); setV(nv); } }, 'Unpublish') : null,
        h('p', { class: 'small muted', style: { margin: 0 } }, 'Publishing only makes the video visible inside your private Viewverse on this Wi-Fi. Nothing is posted online.')),
      h('details', { class: 'card' }, h('summary', { style: { cursor: 'pointer', fontWeight: 700 } }, 'Change edits and re-process'),
        opts.el,
        h('button', { class: 'btn', disabled: published, title: published ? 'Unpublish first' : '', onclick: async () => {
          await save(); await retry(v, opts.value());
        } }, icon('retry'), 'Re-process with these edits')),
      h('div', { class: 'card stack' },
        h('b', {}, 'Original file'),
        h('div', { class: 'small muted' }, `${probe.displayW}×${probe.displayH} ${probe.orientation || ''}, ${fmtDur(probe.duration)}. Stored unchanged and never shown to viewers.`),
        h('div', { class: 'row' },
          h('a', { class: 'btn sm', href: `${base}/original?download=1` }, 'Download original'),
          h('button', { class: 'btn sm danger', onclick: () => remove(v) }, icon('trash'), 'Delete video')))));
}
