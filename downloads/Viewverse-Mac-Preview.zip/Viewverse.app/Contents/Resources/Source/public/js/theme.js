// Applies the saved theme before first paint (Phone / Light / Dark, like the native app).
try {
  const t = localStorage.getItem('vv-theme');
  if (t === 'light' || t === 'dark') document.documentElement.dataset.theme = t;
} catch {}
