// Buffered (delayed) live broadcasting.
//
//   camera (browser MediaRecorder) ──1 s chunks, numbered──▶ private ingest (this file)
//     ──stdin──▶ one continuous ffmpeg per recorder session ("run")
//        (fixed output frame, light audio chain, H.264/AAC, keyframe every segment)
//     ──▶ ordered HLS segments ──▶ playlist written by us, with capture-time
//        PROGRAM-DATE-TIME tags so every viewer can measure its real delay
//     ──▶ viewer player holds playback at the target delay
//
// Timeline is preserved: nothing is cut or reordered. A continuous encoder per run keeps
// audio and video in sync across segment boundaries. If processing falls behind by more
// than LIVE_MAX_BACKLOG_SEC, new chunks are refused (the broadcaster keeps them buffered
// and retries) and viewers see a holding state – video is never passed through unprocessed.
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { db, now } from '../db.js';
import { config } from '../config.js';
import { HttpError } from '../http.js';
import { newId, liveDir, ensureDir, rmrf } from '../storage.js';
import { run } from '../media/run.js';
import { ai, aiStatus } from '../ai/index.js';

const active = new Map(); // broadcastId -> state
const MAX_CHUNK_BYTES = 8 * 1024 * 1024;
const MAX_STDIN_BUFFER = 48 * 1024 * 1024;

export function recoverBroadcasts() {
  db.prepare(`UPDATE broadcasts SET status = 'ended', ended_at = ?, error = COALESCE(error, 'Ended because Viewverse restarted.') WHERE status NOT IN ('ended', 'failed')`).run(now());
}

const row = (id) => db.prepare('SELECT * FROM broadcasts WHERE id = ?').get(id);

export function createBroadcast(b) {
  if ([...active.values()].some((s) => !s.ended)) throw new HttpError(409, 'A broadcast is already running. End it first.');
  const seg = clamp(Number(b.segmentSec) || config.liveSegmentSec, 1, 6);
  const delay = clamp(Number(b.targetDelaySec) || config.liveTargetDelaySec, Math.max(4, seg * 2), 60);
  const id = newId();
  const orientation = b.orientation === 'portrait' ? 'portrait' : 'landscape';
  db.prepare(`INSERT INTO broadcasts (id, status, title, publish_live, segment_sec, target_delay_sec, captions, orientation, created_at)
    VALUES (?, 'starting', ?, ?, ?, ?, ?, ?, ?)`).run(id, String(b.title || 'Live').trim().slice(0, 100) || 'Live', b.publishLive === true ? 1 : 0, seg, delay, b.captions === false ? 0 : 1, orientation, now());
  ensureDir(liveDir(id));
  const s = {
    id, seg, delay, orientation, publishLive: b.publishLive === true, captions: b.captions !== false,
    runs: [], segments: [], cues: [], captionPending: [], captionBusy: false,
    lastChunkAt: null, createdAt: now(), startedAt: null, ended: false, failed: null,
    stats: { chunks: 0, duplicates: 0, outOfOrder: 0, refusedBackpressure: 0, bytes: 0, reconnects: 0, lagSamples: [], captionWindows: 0, captionSkippedSec: 0, captionLagSamples: [], captionsNote: null },
  };
  active.set(id, s);
  s.watchdog = setInterval(() => watchdog(s), 1000);
  return publicState(s);
}

const clamp = (x, a, b) => Math.min(b, Math.max(a, x));

function outputBox(o) { return o === 'portrait' ? [720, 1280] : [1280, 720]; }

function startRun(s, index, startWall) {
  const dir = ensureDir(path.join(liveDir(s.id), `run-${index}`));
  const [W, H] = outputBox(s.orientation);
  const fps = 30;
  const args = [
    '-hide_banner', '-nostdin', '-loglevel', 'info', '-fflags', '+genpts', '-i', 'pipe:0',
    '-map', '0:v:0', '-map', '0:a:0?',
    '-vf', `scale=${W}:${H}:force_original_aspect_ratio=decrease,pad=${W}:${H}:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1,fps=${fps},format=yuv420p`,
    '-c:v', config.videoEncoder === 'libx264' ? 'libx264' : 'h264_videotoolbox',
    ...(config.videoEncoder === 'libx264' ? ['-preset', 'veryfast', '-tune', 'zerolatency'] : ['-realtime', '1', '-allow_sw', '1']),
    '-b:v', '2500k', '-maxrate', '3000k', '-bufsize', '5000k',
    '-g', String(fps * s.seg), '-force_key_frames', `expr:gte(t,n_forced*${s.seg})`,
    // Light, low-latency audio: rumble filter, gentle compression, peak limiter.
    // aresample=async keeps audio locked to the video clock across chunk boundaries.
    '-af', 'highpass=f=80,acompressor=threshold=-20dB:ratio=3:attack=5:release=150:makeup=2,alimiter=limit=0.95,aresample=48000:async=1:first_pts=0',
    '-c:a', 'aac', '-b:a', '128k', '-ac', '2',
    '-f', 'hls', '-hls_time', String(s.seg), '-hls_list_size', '0', '-hls_segment_type', 'mpegts',
    '-hls_flags', 'independent_segments+temp_file', '-hls_segment_filename', path.join(dir, 'seg-%05d.ts'), path.join(dir, 'index.m3u8'),
  ];
  const proc = spawn(config.ffmpeg, args, { stdio: ['pipe', 'ignore', 'pipe'] });
  const r = { index, dir, proc, startWall, nextSeq: 0, ingestedMedia: 0, processedMedia: 0, seen: 0, closed: false, exitCode: null, stderrTail: '' };
  proc.stdin.on('error', () => {}); // EPIPE if ffmpeg exits; handled by 'close'
  proc.stderr.on('data', (d) => {
    const txt = d.toString();
    r.stderrTail = (r.stderrTail + txt).slice(-3000);
    const m = txt.match(/time=(\d+):(\d+):(\d+\.?\d*)/g);
    if (m) { const t = m[m.length - 1].match(/(\d+):(\d+):(\d+\.?\d*)/); r.processedMedia = Number(t[1]) * 3600 + Number(t[2]) * 60 + Number(t[3]); }
  });
  proc.on('close', (code) => {
    r.closed = true; r.exitCode = code;
    collectSegments(s, r);
    if (code !== 0 && !s.ended && r.endRequested !== true) {
      const msg = r.stderrTail.split('\n').filter((l) => /error|invalid/i.test(l)).slice(-2).join(' ').slice(0, 300);
      fail(s, `Live processing stopped unexpectedly${msg ? `: ${msg}` : ''}.`);
    }
  });
  r.poll = setInterval(() => collectSegments(s, r), 400);
  s.runs.push(r);
  return r;
}

function collectSegments(s, r) {
  let txt;
  try { txt = fs.readFileSync(path.join(r.dir, 'index.m3u8'), 'utf8'); } catch { return; }
  const lines = txt.split('\n');
  const found = [];
  for (let i = 0; i < lines.length; i++) {
    const m = lines[i].match(/^#EXTINF:([\d.]+)/);
    if (m && lines[i + 1] && /^seg-\d+\.ts$/.test(lines[i + 1].trim())) found.push({ dur: Number(m[1]), file: lines[i + 1].trim() });
  }
  if (found.length <= r.seen) { if (r.closed) clearInterval(r.poll); return; }
  let mediaStart = r.segmentsMediaEnd || 0;
  for (let i = r.seen; i < found.length; i++) {
    const f = found[i];
    const wallStart = r.startWall + mediaStart * 1000;
    const availableAt = now();
    const seg = { run: r.index, file: f.file, dur: f.dur, mediaStart, wallStart, availableAt, lagSec: (availableAt - (wallStart + f.dur * 1000)) / 1000 };
    s.segments.push(seg);
    s.stats.lagSamples.push(seg.lagSec);
    if (s.stats.lagSamples.length > 30) s.stats.lagSamples.shift();
    mediaStart += f.dur;
    if (s.captions) queueCaptions(s, seg);
  }
  r.segmentsMediaEnd = mediaStart;
  r.seen = found.length;
  if (r.closed) clearInterval(r.poll);
}

// ---- Captions: transcribe windows of a few seconds when the laptop has time. ----
function queueCaptions(s, seg) {
  s.captionPending.push(seg);
  const window = Math.max(4, s.seg * 2);
  const pendingDur = s.captionPending.reduce((a, x) => a + x.dur, 0);
  const runChanged = s.captionPending.length > 1 && s.captionPending[0].run !== seg.run;
  if (pendingDur >= window || runChanged) {
    const batch = runChanged ? s.captionPending.splice(0, s.captionPending.length - 1) : s.captionPending.splice(0);
    s.captionWindows = s.captionWindows || [];
    s.captionWindows.push(batch);
    // Bounded: if more than 2 windows are waiting, drop the oldest rather than fall behind.
    while (s.captionWindows.length > 2) {
      const dropped = s.captionWindows.shift();
      s.stats.captionSkippedSec += dropped.reduce((a, x) => a + x.dur, 0);
      s.stats.captionsNote = 'Some captions were skipped because transcription could not keep up.';
    }
    pumpCaptions(s);
  }
}

async function pumpCaptions(s) {
  if (s.captionBusy || !s.captionWindows?.length) return;
  const status = await aiStatus();
  if (!status.transcription.available) { s.stats.captionsNote = `Captions unavailable: ${status.transcription.reason}`; s.captionWindows = []; return; }
  s.captionBusy = true;
  const batch = s.captionWindows.shift();
  const run0 = s.runs.find((r) => r.index === batch[0].run);
  const wav = path.join(liveDir(s.id), `cap-${batch[0].run}-${batch[0].file}.wav`);
  try {
    const input = 'concat:' + batch.map((x) => path.join(run0.dir, x.file)).join('|');
    await run(config.ffmpeg, ['-hide_banner', '-nostdin', '-y', '-i', input, '-vn', '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le', wav], { timeoutSec: 30 });
    const t = await ai.transcribe(wav, {});
    const base = batch[0].wallStart;
    const words = t.words.map((w) => ({ w: w.w, s: base + w.s * 1000, e: base + w.e * 1000 }));
    // Group into short cues on the broadcast's wall-clock timeline.
    let cur = null;
    for (const w of words) {
      if (!cur || w.s - cur.end > 800 || (cur.text + w.w).length > 60) { if (cur) s.cues.push(cur); cur = { start: w.s, end: w.e, text: w.w.trim() }; }
      else { cur.text += w.w.startsWith(' ') ? w.w : ' ' + w.w; cur.end = w.e; }
    }
    if (cur) s.cues.push(cur);
    if (s.cues.length > 2000) s.cues.splice(0, s.cues.length - 2000);
    const windowEnd = batch[batch.length - 1].wallStart + batch[batch.length - 1].dur * 1000;
    s.stats.captionLagSamples.push((now() - windowEnd) / 1000);
    if (s.stats.captionLagSamples.length > 20) s.stats.captionLagSamples.shift();
  } catch (e) {
    s.stats.captionsNote = `A caption window failed: ${e.message}`;
  } finally {
    fs.rmSync(wav, { force: true });
    s.captionBusy = false;
    if (s.captionWindows?.length) setImmediate(() => pumpCaptions(s));
  }
}

// ---- Ingest ----
export function ingestChunk(id, { run: runIndex, seq, captureMs, runStartMs }, body) {
  const s = active.get(id);
  if (!s) throw new HttpError(410, 'This broadcast is not running.');
  if (s.failed) throw new HttpError(410, s.failed);
  if (s.ended) throw new HttpError(410, 'This broadcast has ended.');
  if (!Number.isInteger(runIndex) || runIndex < 0 || !Number.isInteger(seq) || seq < 0) throw new HttpError(400, 'Bad sequence numbers');
  if (body.length > MAX_CHUNK_BYTES) throw new HttpError(413, 'Chunk too large');
  if ((now() - s.createdAt) / 60000 > config.liveMaxBroadcastMin) { endBroadcast(id, `Reached the ${config.liveMaxBroadcastMin}-minute limit (LIVE_MAX_BROADCAST_MIN).`); throw new HttpError(410, 'Time limit reached; broadcast ended.'); }

  let r = s.runs[s.runs.length - 1];
  if (!r || runIndex > r.index) {
    // A new recorder session (first start, or the broadcaster reconnected after a reload).
    if (seq !== 0) return { status: 409, body: { error: 'A new session must start at chunk 0', expected: { run: runIndex, seq: 0 } } };
    if (r) { r.endRequested = true; r.proc.stdin.end(); s.stats.reconnects++; }
    const start = Number.isFinite(runStartMs) ? runStartMs : now();
    r = startRun(s, runIndex, start);
    if (!s.startedAt) { s.startedAt = now(); db.prepare('UPDATE broadcasts SET started_at = ? WHERE id = ?').run(s.startedAt, id); }
  } else if (runIndex < r.index) {
    throw new HttpError(410, 'That recording session was replaced by a newer one.');
  }
  if (seq < r.nextSeq) { s.stats.duplicates++; s.lastChunkAt = now(); return { status: 200, body: { ok: true, duplicate: true, next: r.nextSeq } }; }
  if (seq > r.nextSeq) { s.stats.outOfOrder++; return { status: 409, body: { error: 'Missing earlier chunk', expected: { run: r.index, seq: r.nextSeq } } }; }
  if (r.closed) throw new HttpError(410, 'Processing for this session has stopped.');

  // Backpressure: never let processing build an unlimited backlog.
  const backlog = backlogSec(s);
  if (backlog > config.liveMaxBacklogSec || r.proc.stdin.writableLength > MAX_STDIN_BUFFER) {
    s.stats.refusedBackpressure++;
    s.holding = true;
    return { status: 503, body: { error: 'Processing is behind; hold this chunk and retry.', holding: true, retryAfterMs: 1000, backlogSec: backlog } };
  }
  s.holding = false;
  r.proc.stdin.write(body);
  if (config.liveKeepRecording) fs.appendFileSync(path.join(r.dir, 'ingest.raw'), body);
  r.nextSeq++;
  if (Number.isFinite(captureMs)) r.ingestedMedia = Math.max(r.ingestedMedia, (captureMs - r.startWall) / 1000);
  s.lastChunkAt = now();
  s.stats.chunks++; s.stats.bytes += body.length;
  return { status: 200, body: { ok: true, next: r.nextSeq } };
}

function backlogSec(s) {
  const r = s.runs[s.runs.length - 1];
  if (!r) return 0;
  return Math.max(0, r.ingestedMedia - r.processedMedia);
}

function watchdog(s) {
  if (s.ended) return;
  // Reconnect grace: if the camera stops sending for too long, end the broadcast cleanly.
  if (s.lastChunkAt && now() - s.lastChunkAt > config.liveReconnectGraceSec * 1000) {
    endBroadcast(s.id, `Ended after ${config.liveReconnectGraceSec}s without a connection from the camera.`);
  }
  persist(s);
}

function fail(s, message) {
  if (s.ended) return;
  s.failed = message;
  s.ended = true;
  s.endedAt = now();
  db.prepare(`UPDATE broadcasts SET status = 'failed', error = ?, ended_at = ? WHERE id = ?`).run(message, now(), s.id);
  cleanupRuns(s);
}

export function endBroadcast(id, reason) {
  const s = active.get(id);
  if (!s || s.ended) return;
  s.ended = true;
  s.endedAt = now();
  s.endReason = reason || null;
  for (const r of s.runs) { r.endRequested = true; try { r.proc.stdin.end(); } catch {} }
  db.prepare(`UPDATE broadcasts SET status = 'ended', ended_at = ?, error = ? WHERE id = ?`).run(now(), reason || null, id);
  cleanupRuns(s);
  persist(s);
}

function cleanupRuns(s) {
  clearInterval(s.watchdog);
  setTimeout(() => {
    for (const r of s.runs) { if (!r.closed) try { r.proc.kill('SIGKILL'); } catch {} collectSegments(s, r); clearInterval(r.poll); }
    persist(s);
  }, 8000);
}

function persist(s) {
  const status = computeStatus(s);
  db.prepare('UPDATE broadcasts SET status = ?, stats_json = ? WHERE id = ?').run(status, JSON.stringify(summaryStats(s)), s.id);
  // Keep the playlist + captions on disk so an ended broadcast can be replayed after a restart.
  try {
    fs.writeFileSync(path.join(liveDir(s.id), 'segments.json'), JSON.stringify({ segments: s.segments, cues: s.cues }));
  } catch {}
}

function computeStatus(s) {
  if (s.failed) return 'failed';
  if (s.ended) return 'ended';
  if (!s.lastChunkAt) return 'starting';
  if (now() - s.lastChunkAt > Math.max(4000, s.seg * 2000)) return 'reconnecting';
  if (s.holding || backlogSec(s) > config.liveMaxBacklogSec) return 'holding';
  if (!s.segments.length) return 'processing';
  return 'broadcasting';
}

const avg = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : null);
function summaryStats(s) {
  const lag = s.stats.lagSamples;
  return {
    segments: s.segments.length, chunks: s.stats.chunks, duplicates: s.stats.duplicates, outOfOrder: s.stats.outOfOrder,
    refusedBackpressure: s.stats.refusedBackpressure, reconnects: s.stats.reconnects, bytes: s.stats.bytes,
    processingLagSec: lag.length ? round1(lag[lag.length - 1]) : null, processingLagAvgSec: lag.length ? round1(avg(lag)) : null,
    processingLagMaxSec: lag.length ? round1(Math.max(...lag)) : null, backlogSec: round1(backlogSec(s)),
    captionLagSec: s.stats.captionLagSamples.length ? round1(avg(s.stats.captionLagSamples)) : null,
    captionSkippedSec: round1(s.stats.captionSkippedSec), captionsNote: s.stats.captionsNote,
    broadcastSec: s.startedAt ? round1(((s.endedAt || now()) - s.startedAt) / 1000) : 0,
  };
}
const round1 = (x) => (x === null || x === undefined ? x : Math.round(x * 10) / 10);

function publicState(s) {
  const r = row(s.id);
  return {
    id: s.id, title: r.title, status: computeStatus(s), publishLive: s.publishLive, segmentSec: s.seg, targetDelaySec: s.delay,
    captions: s.captions, orientation: s.orientation, createdAt: s.createdAt, startedAt: s.startedAt, endedAt: r.ended_at,
    endReason: s.failed || s.endReason || r.error, stats: summaryStats(s), serverNow: now(), nextRun: s.runs.length,
  };
}

// For ended broadcasts after a restart, rebuild a read-only state from disk.
function loadState(id) {
  if (active.has(id)) return active.get(id);
  const r = row(id);
  if (!r) return null;
  let saved = { segments: [], cues: [] };
  try { saved = JSON.parse(fs.readFileSync(path.join(liveDir(id), 'segments.json'), 'utf8')); } catch {}
  const s = { id, seg: r.segment_sec, delay: r.target_delay_sec, orientation: r.orientation, publishLive: !!r.publish_live, captions: !!r.captions,
    runs: [], segments: saved.segments, cues: saved.cues, ended: true, failed: r.status === 'failed' ? r.error : null, endReason: r.error,
    createdAt: r.created_at, startedAt: r.started_at,
    stats: { chunks: 0, duplicates: 0, outOfOrder: 0, refusedBackpressure: 0, bytes: 0, reconnects: 0, lagSamples: [], captionLagSamples: [], captionSkippedSec: 0, captionsNote: null },
    savedStats: r.stats_json ? JSON.parse(r.stats_json) : null };
  return s;
}

export function getState(id) {
  const s = loadState(id);
  if (!s) throw new HttpError(404, 'Broadcast not found');
  const st = publicState(s);
  if (!active.has(id) && s.savedStats) st.stats = s.savedStats;
  return st;
}

export function canView(id, isCreator) {
  const r = row(id);
  if (!r) throw new HttpError(404, 'Broadcast not found');
  if (isCreator) return true;
  if (!r.publish_live) throw new HttpError(403, 'This broadcast is a private preview. Only the creator can watch it.');
  if (!config.allowGuestViewing) throw new HttpError(401, 'Sign in to watch.');
  return true;
}

export function playlist(id) {
  const s = loadState(id);
  if (!s) throw new HttpError(404, 'Broadcast not found');
  const segs = s.segments;
  const target = Math.ceil(Math.max(s.seg, ...segs.map((x) => x.dur)));
  const out = ['#EXTM3U', '#EXT-X-VERSION:3', `#EXT-X-TARGETDURATION:${target}`, '#EXT-X-MEDIA-SEQUENCE:0', '#EXT-X-PLAYLIST-TYPE:EVENT', '#EXT-X-INDEPENDENT-SEGMENTS'];
  let prevRun = null;
  for (const x of segs) {
    if (prevRun !== null && x.run !== prevRun) out.push('#EXT-X-DISCONTINUITY');
    prevRun = x.run;
    out.push(`#EXT-X-PROGRAM-DATE-TIME:${new Date(x.wallStart).toISOString()}`, `#EXTINF:${x.dur.toFixed(3)},`, `seg/${x.run}/${x.file}`);
  }
  if (s.ended) out.push('#EXT-X-ENDLIST');
  return out.join('\n') + '\n';
}

export function segmentFile(id, runIndex, file) {
  if (!/^\d{1,3}$/.test(runIndex) || !/^seg-\d{5}\.ts$/.test(file)) throw new HttpError(400, 'Bad segment');
  return path.join(liveDir(id), `run-${runIndex}`, file);
}

export function captionsSince(id, sinceMs) {
  const s = loadState(id);
  if (!s) throw new HttpError(404, 'Broadcast not found');
  return s.cues.filter((c) => c.end >= sinceMs).slice(0, 200);
}

export function listBroadcasts() {
  return db.prepare('SELECT id FROM broadcasts ORDER BY created_at DESC LIMIT 50').all().map((x) => getState(x.id));
}

export function publicBroadcasts() {
  return [...active.values()].filter((s) => s.publishLive && !s.ended).map((s) => {
    const st = publicState(s);
    return { id: st.id, title: st.title, status: st.status, startedAt: st.startedAt, targetDelaySec: st.targetDelaySec };
  });
}

export function deleteBroadcast(id) {
  const s = active.get(id);
  if (s && !s.ended) throw new HttpError(409, 'End the broadcast before deleting it.');
  active.delete(id);
  rmrf(liveDir(id));
  db.prepare('DELETE FROM broadcasts WHERE id = ?').run(id);
}
