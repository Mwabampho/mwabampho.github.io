// Single protected creator account for the local prototype.
// Passwords: scrypt with per-password salt. Sessions: random 32-byte token in an
// HttpOnly + Secure + SameSite=Strict cookie; only a SHA-256 of the token is stored.
import crypto from 'node:crypto';
import { db, now } from './db.js';
import { config } from './config.js';
import { HttpError, parseCookies } from './http.js';

const COOKIE = 'vv_session';

export function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$${salt.toString('base64')}$${hash.toString('base64')}`;
}

function verifyPassword(password, stored) {
  const [, saltB64, hashB64] = stored.split('$');
  const expected = Buffer.from(hashB64, 'base64');
  const actual = crypto.scryptSync(password, Buffer.from(saltB64, 'base64'), expected.length, { N: 16384, r: 8, p: 1 });
  return crypto.timingSafeEqual(expected, actual);
}

export const getCreator = () => db.prepare('SELECT id, username, display_name, bio, created_at FROM creator WHERE id = 1').get();

export function validateNewAccount({ username, displayName, password }) {
  if (typeof username !== 'string' || !/^[a-z0-9_]{3,24}$/.test(username)) throw new HttpError(400, 'Username must be 3–24 characters: lowercase letters, numbers or _.');
  if (typeof displayName !== 'string' || displayName.trim().length < 1 || displayName.length > 50) throw new HttpError(400, 'Display name must be 1–50 characters.');
  if (typeof password !== 'string' || password.length < 10 || password.length > 200) throw new HttpError(400, 'Password must be at least 10 characters.');
}

export function createCreator({ username, displayName, password }) {
  validateNewAccount({ username, displayName, password });
  if (getCreator()) throw new HttpError(409, 'A creator account already exists.');
  db.prepare('INSERT INTO creator (id, username, display_name, password_hash, created_at) VALUES (1, ?, ?, ?, ?)')
    .run(username, displayName.trim(), hashPassword(password), now());
}

export function setPassword(password) {
  if (typeof password !== 'string' || password.length < 10) throw new Error('Password must be at least 10 characters.');
  db.prepare('UPDATE creator SET password_hash = ? WHERE id = 1').run(hashPassword(password));
  db.prepare('DELETE FROM sessions').run();
}

// Simple in-memory login throttle: 8 failures per address per 15 minutes.
const failures = new Map();
function throttle(ip) {
  const t = now();
  const list = (failures.get(ip) || []).filter((x) => t - x < 15 * 60 * 1000);
  failures.set(ip, list);
  if (list.length >= 8) throw new HttpError(429, 'Too many failed sign-in attempts. Wait 15 minutes and try again.');
  return list;
}

export function login(req, res, { username, password }) {
  const ip = req.socket.remoteAddress || 'unknown';
  const list = throttle(ip);
  const row = db.prepare('SELECT username, password_hash FROM creator WHERE id = 1').get();
  const ok = row && typeof username === 'string' && typeof password === 'string'
    && username === row.username && verifyPassword(password, row.password_hash);
  if (!ok) { list.push(now()); throw new HttpError(401, 'Incorrect username or password.'); }
  failures.delete(ip);
  const token = crypto.randomBytes(32).toString('base64url');
  const expires = now() + config.sessionDays * 86400 * 1000;
  db.prepare('INSERT INTO sessions (token_hash, created_at, expires_at, user_agent) VALUES (?, ?, ?, ?)')
    .run(sha(token), now(), expires, String(req.headers['user-agent'] || '').slice(0, 200));
  res.setHeader('Set-Cookie', `${COOKIE}=${token}; Path=/; HttpOnly; ${secureFlag(req)}SameSite=Strict; Max-Age=${config.sessionDays * 86400}`);
}

export function logout(req, res) {
  const token = parseCookies(req)[COOKIE];
  if (token) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha(token));
  res.setHeader('Set-Cookie', `${COOKIE}=; Path=/; HttpOnly; ${secureFlag(req)}SameSite=Strict; Max-Age=0`);
}

// Secure cookies over HTTPS; the plain-HTTP listener only serves the app to this laptop itself.
const secureFlag = (req) => (req.socket.encrypted ? 'Secure; ' : '');

const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');

export function isCreator(req) {
  const token = parseCookies(req)[COOKIE];
  if (!token) return false;
  const row = db.prepare('SELECT expires_at FROM sessions WHERE token_hash = ?').get(sha(token));
  return !!row && row.expires_at > now();
}

export function pruneSessions() {
  db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(now());
}

export const isLoopback = (req) => ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress);

// Middleware-style guards. `ctx` carries req/res/params.
export function requireCreator(ctx) {
  if (!isCreator(ctx.req)) throw new HttpError(401, 'Sign in as the creator to continue.');
}
export function requireViewer(ctx) {
  if (config.allowGuestViewing) return;
  if (!isCreator(ctx.req)) throw new HttpError(401, 'Sign in to watch. (Guest viewing is disabled in this private prototype.)');
}
