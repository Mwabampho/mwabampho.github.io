// Central configuration. Every value can be overridden with an environment variable
// (see ENV.example). Numbers are clamped to safe bounds so a typo cannot remove a limit.
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

// Minimal .env loader (no dependency). Existing environment variables win.
const envFile = path.join(ROOT, '.env');
if (fs.existsSync(envFile)) {
  for (const line of fs.readFileSync(envFile, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/\s+#.*$/, '').trim().replace(/^["']|["']$/g, '');
  }
}

function num(name, def, min, max) {
  const raw = process.env[name];
  const v = raw === undefined || raw === '' ? def : Number(raw);
  if (!Number.isFinite(v)) return def;
  return Math.min(max, Math.max(min, v));
}
function bool(name, def) {
  const raw = process.env[name];
  if (raw === undefined || raw === '') return def;
  return /^(1|true|yes|on)$/i.test(raw);
}
function str(name, def) {
  const raw = process.env[name];
  return raw === undefined || raw === '' ? def : raw;
}

const dataDir = path.resolve(ROOT, str('VIEWVERSE_DATA_DIR', 'data'));

export const config = {
  host: str('HOST', '0.0.0.0'),
  port: num('PORT', 8443, 1, 65535),
  setupHttpPort: num('SETUP_HTTP_PORT', 8080, 0, 65535), // 0 disables the phone setup helper
  dataDir,
  dbFile: path.join(dataDir, 'viewverse.db'),
  privateDir: path.join(dataDir, 'private'), // never served statically
  publicDir: path.join(dataDir, 'published'), // served only through the media route
  certDir: path.resolve(ROOT, str('CERT_DIR', 'certs')),
  staticDir: path.join(ROOT, 'public'),
  aiHelper: path.resolve(ROOT, str('AI_HELPER', 'bin/viewverse-ai')),
  aiProvider: str('AI_PROVIDER', 'apple-local'), // apple-local | none
  speechLocale: str('SPEECH_LOCALE', 'en-US'),
  ffmpeg: str('FFMPEG_PATH', 'ffmpeg'),
  ffprobe: str('FFPROBE_PATH', 'ffprobe'),

  allowGuestViewing: bool('ALLOW_GUEST_VIEWING', false),
  sessionDays: num('SESSION_DAYS', 14, 1, 90),

  // Uploads
  maxUploadMB: num('MAX_UPLOAD_MB', 500, 1, 4096),
  maxDurationSec: num('MAX_DURATION_SEC', 600, 5, 3600),
  uploadChunkMB: num('UPLOAD_CHUNK_MB', 4, 1, 32),
  abandonedUploadHours: num('ABANDONED_UPLOAD_HOURS', 24, 1, 720),

  // Storage
  storageQuotaGB: num('STORAGE_QUOTA_GB', 5, 0.5, 500),
  minFreeDiskGB: num('MIN_FREE_DISK_GB', 3, 0.5, 100),

  // Jobs
  maxConcurrentJobs: num('MAX_CONCURRENT_JOBS', 1, 1, 4),
  maxJobAttempts: num('MAX_JOB_ATTEMPTS', 3, 1, 10),
  stepTimeoutSec: num('STEP_TIMEOUT_SEC', 900, 30, 7200),
  videoEncoder: str('VIDEO_ENCODER', 'h264_videotoolbox'), // or libx264

  // Upload editing defaults (each can be turned off per video)
  silenceMinSec: num('SILENCE_MIN_SEC', 1.5, 0.5, 10),
  silenceKeepSec: num('SILENCE_KEEP_SEC', 0.4, 0.1, 2),
  silenceThresholdDb: num('SILENCE_THRESHOLD_DB', -38, -70, -20),
  targetLufs: num('TARGET_LUFS', -16, -30, -10),

  // Live
  liveSegmentSec: num('LIVE_SEGMENT_SEC', 2, 1, 6),
  liveTargetDelaySec: num('LIVE_TARGET_DELAY_SEC', 10, 4, 60),
  liveMaxBacklogSec: num('LIVE_MAX_BACKLOG_SEC', 20, 5, 120),
  liveMaxBroadcastMin: num('LIVE_MAX_BROADCAST_MIN', 60, 1, 240),
  liveReconnectGraceSec: num('LIVE_RECONNECT_GRACE_SEC', 45, 5, 600),
  liveKeepRecording: bool('LIVE_KEEP_RECORDING', false),
};

export const LIMITS = {
  allowedVideoExt: ['mp4', 'mov', 'm4v', 'webm', 'mkv', '3gp'],
  allowedMime: /^video\/(mp4|quicktime|x-m4v|webm|x-matroska|3gpp)(;.*)?$/i,
};
