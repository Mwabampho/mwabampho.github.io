import fs from 'node:fs';
import { DatabaseSync } from 'node:sqlite';
import { config } from './config.js';

fs.mkdirSync(config.dataDir, { recursive: true, mode: 0o700 });

export const db = new DatabaseSync(config.dbFile);
db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 3000;');

db.exec(`
CREATE TABLE IF NOT EXISTS creator (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  username TEXT NOT NULL,
  display_name TEXT NOT NULL,
  bio TEXT NOT NULL DEFAULT '',
  password_hash TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  user_agent TEXT
);
CREATE TABLE IF NOT EXISTS videos (
  id TEXT PRIMARY KEY,
  status TEXT NOT NULL,              -- draft|uploading|queued|processing|ready|published|failed|cancelled
  source TEXT NOT NULL,              -- browser-recording|upload
  original_name TEXT NOT NULL,
  mime TEXT NOT NULL,
  ext TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  received_bytes INTEGER NOT NULL DEFAULT 0,
  sha256 TEXT,
  probe_json TEXT,
  options_json TEXT NOT NULL,        -- per-video editing options
  report_json TEXT,                  -- what the pipeline actually did
  cues_json TEXT,                    -- captions (original timeline) + keep map
  suggestion_json TEXT,
  thumbs_json TEXT,
  selected_thumb INTEGER NOT NULL DEFAULT 0,
  title TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '',
  published_version TEXT,            -- edited|original
  public_id TEXT,
  error TEXT,
  attempts INTEGER NOT NULL DEFAULT 0,
  progress REAL NOT NULL DEFAULT 0,
  step TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  published_at INTEGER
);
CREATE INDEX IF NOT EXISTS videos_status ON videos(status);
CREATE TABLE IF NOT EXISTS broadcasts (
  id TEXT PRIMARY KEY,
  status TEXT NOT NULL,              -- starting|processing|broadcasting|holding|reconnecting|ended|failed
  title TEXT NOT NULL,
  publish_live INTEGER NOT NULL DEFAULT 0,
  segment_sec REAL NOT NULL,
  target_delay_sec REAL NOT NULL,
  captions INTEGER NOT NULL DEFAULT 1,
  orientation TEXT NOT NULL DEFAULT 'landscape',
  stats_json TEXT,
  error TEXT,
  created_at INTEGER NOT NULL,
  started_at INTEGER,
  ended_at INTEGER
);
`);

export const now = () => Date.now();

export function tx(fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; }
}
