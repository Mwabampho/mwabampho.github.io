// Safe process runner for ffmpeg/ffprobe/AI helper.
// - Arguments are always passed as an array (never through a shell), so filenames
//   or user text can't be interpreted as commands.
// - Every call has a timeout and can be cancelled through an AbortSignal.
// - Output captured in memory is capped.
import { spawn } from 'node:child_process';

const MAX_CAPTURE = 8 * 1024 * 1024;

export class ProcessError extends Error {
  constructor(message, { code, stderr, cancelled, timedOut } = {}) {
    super(message);
    this.code = code; this.stderr = stderr; this.cancelled = cancelled; this.timedOut = timedOut;
  }
}

export function run(cmd, args, { timeoutSec = 900, signal, input, onStderr, cwd } = {}) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) return reject(new ProcessError('Cancelled', { cancelled: true }));
    const child = spawn(cmd, args, { stdio: ['pipe', 'pipe', 'pipe'], cwd });
    let stdout = '', stderr = '', done = false, timedOut = false, cancelled = false;
    const kill = () => { try { child.kill('SIGKILL'); } catch {} };
    const timer = setTimeout(() => { timedOut = true; kill(); }, timeoutSec * 1000);
    const onAbort = () => { cancelled = true; kill(); };
    signal?.addEventListener('abort', onAbort, { once: true });
    child.stdout.on('data', (d) => { if (stdout.length < MAX_CAPTURE) stdout += d; });
    child.stderr.on('data', (d) => {
      const s = d.toString();
      if (stderr.length < MAX_CAPTURE) stderr += s;
      onStderr?.(s);
    });
    child.on('error', (err) => {
      if (done) return; done = true; clearTimeout(timer); signal?.removeEventListener('abort', onAbort);
      reject(new ProcessError(err.code === 'ENOENT' ? `${cmd} is not installed or not on PATH` : err.message, {}));
    });
    child.on('close', (code) => {
      if (done) return; done = true; clearTimeout(timer); signal?.removeEventListener('abort', onAbort);
      if (cancelled) return reject(new ProcessError('Cancelled', { cancelled: true }));
      if (timedOut) return reject(new ProcessError(`${cmd} timed out after ${timeoutSec}s`, { timedOut: true, stderr }));
      if (code !== 0) return reject(new ProcessError(`${cmd} exited with code ${code}`, { code, stderr, stdout }));
      resolve({ stdout, stderr });
    });
    if (input !== undefined) child.stdin.end(input); else child.stdin.end();
  });
}

// Last meaningful ffmpeg error lines, for user-facing messages.
export function ffmpegErrorSummary(stderr = '') {
  const lines = stderr.split('\n').map((l) => l.trim()).filter(Boolean)
    .filter((l) => !/^(frame=|size=|video:|\[out|Stream mapping|Press \[q\]|  )/.test(l));
  return lines.slice(-3).join(' | ').slice(0, 400);
}
