// Deterministic media processing with ffmpeg. No AI here.
import fs from 'node:fs';
import path from 'node:path';
import { config } from '../config.js';
import { run, ProcessError, ffmpegErrorSummary } from './run.js';

const FF = ['-hide_banner', '-nostdin', '-y'];

export async function probe(file, { signal } = {}) {
  let out;
  try {
    ({ stdout: out } = await run(config.ffprobe, ['-v', 'error', '-print_format', 'json', '-show_format', '-show_streams', file], { signal, timeoutSec: 60 }));
  } catch (e) {
    if (e.cancelled) throw e;
    throw new Error('This file could not be read as a video. It may be incomplete or in an unsupported format.');
  }
  const j = JSON.parse(out);
  const v = (j.streams || []).find((s) => s.codec_type === 'video' && s.disposition?.attached_pic !== 1);
  const a = (j.streams || []).find((s) => s.codec_type === 'audio');
  let rotation = 0;
  const dm = v?.side_data_list?.find((d) => d.rotation !== undefined);
  if (dm) rotation = Number(dm.rotation) || 0;
  else if (v?.tags?.rotate) rotation = -Number(v.tags.rotate) || 0;
  rotation = ((Math.round(rotation / 90) * 90) % 360 + 360) % 360;
  const [sn, sd] = String(v?.sample_aspect_ratio || '1:1').split(':').map(Number);
  const sar = sn > 0 && sd > 0 ? sn / sd : 1;
  const rate = (r) => { const [n, d] = String(r || '0/1').split('/').map(Number); return d ? n / d : 0; };
  let duration = Number(j.format?.duration) || Number(v?.duration) || 0;
  const width = v?.width || 0, height = v?.height || 0;
  const displayW = rotation % 180 ? height : Math.round(width * sar);
  const displayH = rotation % 180 ? Math.round(width * sar) : height;
  return {
    duration, hasVideo: !!v, hasAudio: !!a, width, height, sar, rotation, displayW, displayH,
    orientation: displayW >= displayH ? 'landscape' : 'portrait',
    fps: rate(v?.avg_frame_rate) || rate(v?.r_frame_rate) || 30,
    vcodec: v?.codec_name, acodec: a?.codec_name, format: j.format?.format_name,
    // Some browser recordings (WebM from MediaRecorder) don't declare a duration.
    durationKnown: duration > 0,
  };
}

// Some MediaRecorder WebM files have no duration in the header; decode to find it.
export async function measureDuration(file, { signal } = {}) {
  const { stderr } = await run(config.ffmpeg, [...FF, '-i', file, '-map', '0:v:0?', '-map', '0:a:0?', '-c', 'copy', '-f', 'null', '-'], { signal, timeoutSec: 300 });
  const all = [...stderr.matchAll(/time=(\d+):(\d+):(\d+\.?\d*)/g)];
  if (!all.length) return 0;
  const m = all[all.length - 1];
  return Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]);
}

export async function extractSpeechAudio(input, out, { signal } = {}) {
  await ff(['-i', input, '-vn', '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le', out], { signal, label: 'Audio extraction' });
}

export async function detectSilences(input, { signal } = {}) {
  const { stderr } = await ff(['-i', input, '-vn', '-af', `silencedetect=noise=${config.silenceThresholdDb}dB:d=${config.silenceMinSec}`, '-f', 'null', '-'], { signal, label: 'Silence detection' });
  const out = [];
  let start = null;
  for (const line of stderr.split('\n')) {
    let m;
    if ((m = line.match(/silence_start: (-?[\d.]+)/))) start = Math.max(0, Number(m[1]));
    else if ((m = line.match(/silence_end: ([\d.]+)/)) && start !== null) { out.push([start, Number(m[1])]); start = null; }
  }
  return { silences: out, trailingStart: start };
}

// Turns silences into "keep" ranges, leaving a little room around speech.
export function keepRanges(silences, trailingStart, duration) {
  const pad = config.silenceKeepSec;
  const cuts = [];
  const all = trailingStart !== null ? [...silences, [trailingStart, duration]] : silences;
  for (const [a, b] of all) {
    // Leave `pad` seconds of room next to speech; at the very start/end cut to the edge.
    const cutStart = a <= 0.05 ? 0 : a + pad;
    const cutEnd = b >= duration - 0.05 ? duration : b - pad;
    if (cutEnd - cutStart > 0.3) cuts.push([cutStart, cutEnd]);
  }
  if (!cuts.length) return null;
  const keep = [];
  let t = 0;
  for (const [a, b] of cuts) { if (a > t + 0.05) keep.push([t, a]); t = b; }
  if (duration - t > 0.05) keep.push([t, duration]);
  const removed = cuts.reduce((s, [a, b]) => s + (b - a), 0);
  return keep.length ? { keep: keep.map(([a, b]) => [r3(a), r3(b)]), removed: r3(removed), count: cuts.length } : null;
}
const r3 = (x) => Math.round(x * 1000) / 1000;

function audioChain({ denoise, loud }) {
  const f = [];
  if (denoise) f.push('highpass=f=60', 'afftdn=nr=12:nf=-45:tn=1');
  if (loud) {
    f.push(`loudnorm=I=${config.targetLufs}:TP=-1.5:LRA=11:measured_I=${loud.input_i}:measured_TP=${loud.input_tp}:measured_LRA=${loud.input_lra}:measured_thresh=${loud.input_thresh}:offset=${loud.target_offset}:linear=true`);
  }
  f.push('aresample=48000');
  return f.join(',');
}

function videoChain(probeInfo) {
  // ffmpeg applies the phone's rotation flag while decoding (autorotate), so we only
  // square the pixels, cap the size (no upscaling) and keep even dimensions.
  const long = 1920;
  const fps = Math.min(60, Math.max(15, Math.round(probeInfo.fps || 30)));
  return [
    `scale=w='if(gte(iw*sar,ih),min(${long},iw*sar),-2)':h='if(gte(iw*sar,ih),-2,min(${long},ih))'`,
    'scale=trunc(iw/2)*2:trunc(ih/2)*2',
    'setsar=1', `fps=${fps}`, 'format=yuv420p',
  ].join(',');
}

function trimGraph(keep, withVideo, withAudio) {
  const parts = [];
  keep.forEach(([a, b], i) => {
    if (withVideo) parts.push(`[0:v:0]trim=start=${a}:end=${b},setpts=PTS-STARTPTS[v${i}]`);
    if (withAudio) parts.push(`[0:a:0]atrim=start=${a}:end=${b},asetpts=PTS-STARTPTS[a${i}]`);
  });
  const ins = keep.map((_, i) => (withVideo ? `[v${i}]` : '') + (withAudio ? `[a${i}]` : '')).join('');
  parts.push(`${ins}concat=n=${keep.length}:v=${withVideo ? 1 : 0}:a=${withAudio ? 1 : 0}${withVideo ? '[vc]' : ''}${withAudio ? '[ac]' : ''}`);
  return parts;
}

// First loudnorm pass over the audio exactly as it will be rendered (after trim/denoise).
export async function measureLoudness(input, { keep, denoise, signal }) {
  const args = ['-i', input, '-vn'];
  const pre = denoise ? 'highpass=f=60,afftdn=nr=12:nf=-45:tn=1,' : '';
  const measure = `loudnorm=I=${config.targetLufs}:TP=-1.5:LRA=11:print_format=json`;
  if (keep) {
    const g = trimGraph(keep, false, true);
    g.push(`[ac]${pre}${measure}[out]`);
    args.push('-filter_complex', g.join(';'), '-map', '[out]');
  } else {
    args.push('-af', pre + measure);
  }
  args.push('-f', 'null', '-');
  const { stderr } = await ff(args, { signal, label: 'Loudness measurement' });
  const m = stderr.match(/\{[\s\S]*?"input_i"[\s\S]*?\}/);
  if (!m) throw new Error('Loudness measurement produced no result');
  const j = JSON.parse(m[0]);
  return { input_i: Number(j.input_i), input_tp: Number(j.input_tp), input_lra: Number(j.input_lra), input_thresh: Number(j.input_thresh), target_offset: Number(j.target_offset) };
}

function encoderArgs(p) {
  const pixels = Math.min(p.displayW * p.displayH || 1920 * 1080, 1920 * 1080);
  const kbps = Math.round(Math.max(1500, Math.min(8000, pixels / 1000 * 3.2)));
  if (config.videoEncoder === 'libx264') return ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '21', '-profile:v', 'high'];
  return ['-c:v', 'h264_videotoolbox', '-b:v', `${kbps}k`, '-maxrate', `${Math.round(kbps * 1.5)}k`, '-bufsize', `${kbps * 2}k`, '-profile:v', 'high', '-allow_sw', '1'];
}

// Renders a playable MP4. With no options it is a faithful, unedited conversion (used for the
// "original" preview); with options it applies trim/denoise/normalisation.
export async function render({ input, output, probeInfo, keep = null, denoise = false, loud = null, signal, onProgress, expectedDuration }) {
  const tmp = output + '.part.mp4';
  const args = ['-i', input];
  const vchain = videoChain(probeInfo);
  const achain = audioChain({ denoise, loud });
  if (keep) {
    const g = trimGraph(keep, true, probeInfo.hasAudio);
    g.push(`[vc]${vchain}[vout]`);
    if (probeInfo.hasAudio) g.push(`[ac]${achain}[aout]`);
    args.push('-filter_complex', g.join(';'), '-map', '[vout]');
    if (probeInfo.hasAudio) args.push('-map', '[aout]');
  } else {
    args.push('-map', '0:v:0', '-vf', vchain);
    if (probeInfo.hasAudio) args.push('-map', '0:a:0', '-af', achain);
  }
  args.push(...encoderArgs(probeInfo));
  if (probeInfo.hasAudio) args.push('-c:a', 'aac', '-b:a', '160k', '-ac', '2');
  // Strip container metadata (e.g. GPS location from phones) from every output.
  args.push('-map_metadata', '-1', '-map_chapters', '-1', '-movflags', '+faststart', '-f', 'mp4', tmp);
  const total = expectedDuration || probeInfo.duration || 0;
  await ff(args, {
    signal, label: 'Video rendering', timeoutSec: config.stepTimeoutSec,
    onStderr: (s) => {
      const m = s.match(/time=(\d+):(\d+):(\d+\.?\d*)/);
      if (m && total > 0 && onProgress) onProgress(Math.min(1, (Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3])) / total));
    },
  });
  fs.renameSync(tmp, output);
}

export async function thumbnails(input, duration, outDir, { signal, count = 4 } = {}) {
  const files = [];
  for (let i = 0; i < count; i++) {
    const t = Math.max(0, duration * (0.1 + (0.8 * i) / Math.max(1, count - 1)) - 0.5);
    const out = path.join(outDir, `thumb-${i}.jpg`);
    // Pick the most representative frame from a short window around each point.
    await ff(['-ss', t.toFixed(2), '-t', '1.5', '-i', input, '-vf', 'thumbnail=20,scale=640:-2', '-frames:v', '1', '-q:v', '3', out], { signal, label: 'Thumbnail extraction', timeoutSec: 60 });
    if (fs.existsSync(out)) files.push({ index: i, time: Math.round(t * 10) / 10, file: `thumb-${i}.jpg` });
  }
  return files;
}

async function ff(args, { signal, label, timeoutSec = config.stepTimeoutSec, onStderr } = {}) {
  try {
    return await run(config.ffmpeg, [...FF, ...args], { signal, timeoutSec, onStderr });
  } catch (e) {
    if (e instanceof ProcessError && !e.cancelled) {
      const err = new Error(`${label} failed: ${e.timedOut ? 'took too long' : ffmpegErrorSummary(e.stderr) || e.message}`);
      err.detail = e.stderr?.slice(-4000);
      throw err;
    }
    throw e;
  }
}
