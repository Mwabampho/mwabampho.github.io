// Viewer-facing API: feed, search, watch, creator profile, and published media.
// Only published copies are reachable here. No processing details are exposed.
import path from 'node:path';
import { db } from '../db.js';
import { HttpError, sendJson, sendFile, readJson } from '../http.js';
import { requireViewer, getCreator, isCreator, isLoopback, login, logout, createCreator } from '../auth.js';
import { publishedDir } from '../storage.js';
import { config } from '../config.js';
import { publicBroadcasts } from '../live/broadcast.js';

function card(v) {
  const probe = v.probe_json ? JSON.parse(v.probe_json) : {};
  return {
    id: v.public_id, title: v.title, description: v.description, publishedAt: v.published_at,
    duration: v.published_version === 'original' ? probe.duration : (probe.editedDuration ?? probe.duration),
    orientation: probe.orientation, thumb: `/media/${v.public_id}/thumb.jpg`,
  };
}

const published = () => db.prepare(`SELECT * FROM videos WHERE status = 'published' ORDER BY published_at DESC`).all();

export function registerPublic(r) {
  r.get('/api/me', ({ req, res }) => {
    const c = getCreator();
    sendJson(res, 200, {
      signedIn: isCreator(req), setupNeeded: !c, canSetupHere: !c && isLoopback(req),
      guestViewing: config.allowGuestViewing,
      creator: c ? { username: c.username, displayName: c.username } : null,
    });
  });

  // First-run account creation is only allowed from the laptop itself, so nobody else
  // on the Wi-Fi can claim the creator account.
  r.post('/api/setup', async ({ req, res }) => {
    if (!isLoopback(req)) throw new HttpError(403, 'Create the creator account on the laptop running Viewverse (http://localhost:8080).');
    const b = await readJson(req);
    createCreator({ username: b.username, displayName: b.displayName, password: b.password });
    login(req, res, { username: b.username, password: b.password });
    sendJson(res, 201, { ok: true });
  });

  r.post('/api/login', async ({ req, res }) => {
    const b = await readJson(req);
    login(req, res, b);
    sendJson(res, 200, { ok: true });
  });

  r.post('/api/logout', ({ req, res }) => { logout(req, res); sendJson(res, 200, { ok: true }); });

  r.get('/api/feed', requireViewer, ({ res }) => {
    sendJson(res, 200, { videos: published().map(card), live: publicBroadcasts() });
  });

  r.get('/api/search', requireViewer, ({ res, url }) => {
    const q = (url.searchParams.get('q') || '').trim().toLowerCase().slice(0, 100);
    if (!q) return sendJson(res, 200, { query: q, videos: [] });
    const terms = q.split(/\s+/).filter(Boolean).slice(0, 8);
    const results = published().map((v) => {
      const cues = v.cues_json ? JSON.parse(v.cues_json).edited : [];
      const title = v.title.toLowerCase(), desc = v.description.toLowerCase(), spoken = cues.map((c) => c.text).join(' ').toLowerCase();
      let score = 0, matchedSpeech = false;
      for (const t of terms) {
        if (title.includes(t)) score += 5;
        if (desc.includes(t)) score += 2;
        if (spoken.includes(t)) { score += 1; matchedSpeech = true; }
      }
      return { v, score, matchedSpeech, all: terms.every((t) => title.includes(t) || desc.includes(t) || spoken.includes(t)) };
    }).filter((x) => x.all).sort((a, b) => b.score - a.score);
    sendJson(res, 200, { query: q, videos: results.map((x) => ({ ...card(x.v), matchedSpeech: x.matchedSpeech })) });
  });

  r.get('/api/videos/:id', requireViewer, ({ res, params }) => {
    const v = db.prepare(`SELECT * FROM videos WHERE public_id = ? AND status = 'published'`).get(params.id);
    if (!v) throw new HttpError(404, 'This video is not available.');
    const c = getCreator();
    const cues = v.cues_json ? JSON.parse(v.cues_json).edited : [];
    sendJson(res, 200, {
      ...card(v), src: `/media/${v.public_id}/video.mp4`,
      captions: cues.some((x) => x.text.trim()) ? `/media/${v.public_id}/captions.vtt` : null,
      creator: { username: c.username, displayName: c.username },
      more: published().filter((x) => x.id !== v.id).slice(0, 8).map(card),
    });
  });

  r.get('/api/creator', requireViewer, ({ res }) => {
    const c = getCreator();
    if (!c) throw new HttpError(404, 'No creator yet');
    const vids = published();
    sendJson(res, 200, {
      username: c.username, displayName: c.username, bio: c.bio, joinedAt: c.created_at,
      videoCount: vids.length, videos: vids.map(card), live: publicBroadcasts(),
    });
  });

  // Published media only. The directory name is the public id, never the private one.
  for (const name of ['video.mp4', 'thumb.jpg', 'captions.vtt']) {
    r.get(`/media/:id/${name.replace('.', '\\.')}`, requireViewer, ({ req, res, params }) => {
      const v = db.prepare(`SELECT id FROM videos WHERE public_id = ? AND status = 'published'`).get(params.id);
      if (!v) throw new HttpError(404, 'Not found');
      sendFile(req, res, path.join(publishedDir(params.id), name), { cache: name === 'video.mp4' ? 'private, max-age=300' : 'no-cache' });
    });
  }
}
