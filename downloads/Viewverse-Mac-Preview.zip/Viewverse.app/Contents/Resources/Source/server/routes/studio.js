// Creator-only API: resumable uploads, review, publish, delete.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { db, now } from '../db.js';
import { config, LIMITS } from '../config.js';
import { HttpError, sendJson, readJson, sendFile } from '../http.js';
import { requireCreator, getCreator } from '../auth.js';
import { newId, originalDir, workDir, publishedDir, ensureDir, rmrf, sanitizeDisplayName, assertCapacity, storageStatus } from '../storage.js';
import { normalizeOptions } from '../pipeline/upload-pipeline.js';
import { enqueue, cancel, retry, updateVideo, isRunning } from '../pipeline/jobs.js';
import { toVtt, sanitizeCues } from '../captions.js';
import { aiStatus } from '../ai/index.js';

const getVideo = (id) => {
  const v = db.prepare('SELECT * FROM videos WHERE id = ?').get(id);
  if (!v) throw new HttpError(404, 'Video not found');
  return v;
};

export function studioSummary(v) {
  return {
    id: v.id, status: v.status, source: v.source, originalName: v.original_name, sizeBytes: v.size_bytes,
    receivedBytes: v.received_bytes, title: v.title, progress: v.progress, step: v.step, error: v.error,
    attempts: v.attempts, maxAttempts: config.maxJobAttempts, publicId: v.status === 'published' ? v.public_id : null,
    publishedVersion: v.published_version, createdAt: v.created_at, updatedAt: v.updated_at,
    duration: v.probe_json ? JSON.parse(v.probe_json).duration : null,
    hasThumb: !!v.thumbs_json && JSON.parse(v.thumbs_json).length > 0, selectedThumb: v.selected_thumb,
  };
}

function detail(v) {
  const cues = v.cues_json ? JSON.parse(v.cues_json) : null;
  return {
    ...studioSummary(v),
    description: v.description,
    options: JSON.parse(v.options_json),
    report: v.report_json ? JSON.parse(v.report_json) : [],
    probe: v.probe_json ? JSON.parse(v.probe_json) : null,
    captions: cues ? cues.edited : [],
    captionsTrimmed: !!cues?.keep,
    thumbs: v.thumbs_json ? JSON.parse(v.thumbs_json) : [],
    suggestion: v.suggestion_json ? JSON.parse(v.suggestion_json) : null,
  };
}

// Recognise real video containers by their first bytes, regardless of the file name.
function sniffContainer(file) {
  const fd = fs.openSync(file, 'r');
  const b = Buffer.alloc(16);
  fs.readSync(fd, b, 0, 16, 0);
  fs.closeSync(fd);
  if (b.readUInt32BE(0) === 0x1a45dfa3) return 'matroska';
  if (b.toString('latin1', 4, 8) === 'ftyp') return 'isobmff';
  return null;
}

const chunkLocks = new Set();

export function registerStudio(r) {
  const creator = (ctx) => requireCreator(ctx);

  r.get('/api/studio/status', creator, async ({ res }) => {
    const counts = Object.fromEntries(db.prepare('SELECT status, COUNT(*) n FROM videos GROUP BY status').all().map((x) => [x.status, x.n]));
    sendJson(res, 200, {
      storage: storageStatus(), ai: await aiStatus(), counts,
      limits: { maxUploadMB: config.maxUploadMB, maxDurationSec: config.maxDurationSec, chunkBytes: config.uploadChunkMB * 1024 * 1024, allowedExt: LIMITS.allowedVideoExt, maxConcurrentJobs: config.maxConcurrentJobs, maxJobAttempts: config.maxJobAttempts },
      live: { segmentSec: config.liveSegmentSec, targetDelaySec: config.liveTargetDelaySec, maxBacklogSec: config.liveMaxBacklogSec },
      guestViewing: config.allowGuestViewing,
    });
  });

  r.get('/api/studio/videos', creator, ({ res }) => {
    sendJson(res, 200, { videos: db.prepare('SELECT * FROM videos ORDER BY created_at DESC').all().map(studioSummary) });
  });

  r.get('/api/studio/videos/:id', creator, ({ res, params }) => sendJson(res, 200, detail(getVideo(params.id))));

  // Step 1 of an upload: declare the file. Nothing is written yet (status "draft").
  r.post('/api/studio/uploads', creator, async ({ req, res }) => {
    const body = await readJson(req);
    const size = Number(body.size);
    const name = sanitizeDisplayName(body.name);
    const ext = (name.match(/\.([A-Za-z0-9]{2,4})$/)?.[1] || '').toLowerCase();
    const mime = String(body.mime || '');
    if (!Number.isInteger(size) || size <= 0) throw new HttpError(400, 'File size is missing.');
    if (size > config.maxUploadMB * 1024 * 1024) throw new HttpError(413, `This file is ${(size / 1024 / 1024).toFixed(0)} MB; the limit is ${config.maxUploadMB} MB.`);
    if (!LIMITS.allowedVideoExt.includes(ext)) throw new HttpError(415, `Unsupported file type. Use ${LIMITS.allowedVideoExt.join(', ')}.`);
    if (mime && !LIMITS.allowedMime.test(mime)) throw new HttpError(415, `Unsupported file type (${mime.slice(0, 40)}).`);
    assertCapacity(size * 3); // original + comparison copy + edited copy
    const id = newId();
    const t = now();
    db.prepare(`INSERT INTO videos (id, status, source, original_name, mime, ext, size_bytes, options_json, created_at, updated_at)
      VALUES (?, 'draft', ?, ?, ?, ?, ?, ?, ?, ?)`).run(id, body.source === 'browser-recording' ? 'browser-recording' : 'upload', name, mime || 'video/' + ext, ext, size, JSON.stringify(normalizeOptions(body.options)), t, t);
    ensureDir(originalDir(id));
    sendJson(res, 201, { id, received: 0, chunkBytes: config.uploadChunkMB * 1024 * 1024 });
  });

  // Where to resume from after a dropped connection.
  r.get('/api/studio/uploads/:id', creator, ({ res, params }) => {
    const v = getVideo(params.id);
    sendJson(res, 200, { id: v.id, status: v.status, received: v.received_bytes, size: v.size_bytes });
  });

  // Step 2: send bytes in order. `offset` must equal what the server already has, so a
  // chunk re-sent after a timeout is acknowledged instead of written twice.
  r.put('/api/studio/uploads/:id', creator, async ({ req, res, params, url }) => {
    const v = getVideo(params.id);
    if (!['draft', 'uploading'].includes(v.status)) throw new HttpError(409, `Upload already ${v.status}.`, { received: v.received_bytes, status: v.status });
    const offset = Number(url.searchParams.get('offset'));
    if (offset !== v.received_bytes) {
      req.resume();
      return sendJson(res, 409, { error: 'Offset mismatch; resume from the server offset.', received: v.received_bytes });
    }
    if (chunkLocks.has(v.id)) { req.resume(); throw new HttpError(409, 'Another chunk for this upload is in progress.'); }
    chunkLocks.add(v.id);
    const part = path.join(originalDir(v.id), `original.${v.ext}.part`);
    const maxChunk = config.uploadChunkMB * 1024 * 1024 + 1024;
    let written = 0;
    try {
      // Write to the file, but only commit the new offset once the whole chunk arrived.
      const fd = fs.openSync(part, 'a');
      try {
        if (fs.fstatSync(fd).size !== offset) fs.ftruncateSync(fd, offset);
        for await (const c of req) {
          written += c.length;
          if (written > maxChunk || offset + written > v.size_bytes) throw new HttpError(413, 'Chunk larger than declared.');
          fs.writeSync(fd, c);
        }
      } finally { fs.closeSync(fd); }
    } catch (e) {
      try { fs.truncateSync(part, offset); } catch {}
      chunkLocks.delete(v.id);
      if (e instanceof HttpError) throw e;
      return; // client disconnected mid-chunk; it will resume from `offset`
    }
    chunkLocks.delete(v.id);
    const received = offset + written;
    updateVideo(v.id, { received_bytes: received, status: 'uploading' });
    if (received < v.size_bytes) return sendJson(res, 200, { received, status: 'uploading' });

    // Upload complete: verify the bytes are really a video container, then queue it.
    const final = path.join(originalDir(v.id), `original.${v.ext}`);
    if (!sniffContainer(part)) {
      rmrf(originalDir(v.id));
      updateVideo(v.id, { status: 'failed', error: 'The uploaded file is not a recognised video (MP4/MOV/WebM/MKV/3GP).', attempts: config.maxJobAttempts });
      throw new HttpError(415, 'The uploaded file is not a recognised video.');
    }
    fs.renameSync(part, final);
    fs.chmodSync(final, 0o400); // the original is never modified
    const hash = crypto.createHash('sha256');
    for await (const c of fs.createReadStream(final)) hash.update(c);
    updateVideo(v.id, { sha256: hash.digest('hex') });
    enqueue(v.id);
    sendJson(res, 200, { received, status: 'queued' });
  });

  r.patch('/api/studio/videos/:id', creator, async ({ req, res, params }) => {
    const v = getVideo(params.id);
    if (v.source === 'rec') throw new HttpError(409, 'Edit and review this story in Rec.');
    const body = await readJson(req, 2 * 1024 * 1024);
    const f = {};
    if (body.title !== undefined) f.title = String(body.title).trim().slice(0, 100);
    if (body.description !== undefined) f.description = String(body.description).slice(0, 2000);
    if (body.selectedThumb !== undefined) {
      const n = Number(body.selectedThumb);
      const thumbs = v.thumbs_json ? JSON.parse(v.thumbs_json) : [];
      if (!thumbs.some((t) => t.index === n)) throw new HttpError(400, 'No such thumbnail');
      f.selected_thumb = n;
    }
    if (body.captions !== undefined) {
      if (!v.cues_json) throw new HttpError(409, 'No captions to edit yet');
      const cues = JSON.parse(v.cues_json);
      const probe = JSON.parse(v.probe_json || '{}');
      try { cues.edited = sanitizeCues(body.captions, probe.editedDuration || probe.duration); } catch (e) { throw new HttpError(400, e.message); }
      f.cues_json = JSON.stringify(cues);
    }
    if (body.options !== undefined) f.options_json = JSON.stringify(normalizeOptions(body.options));
    updateVideo(v.id, f);
    const updated = getVideo(v.id);
    if (updated.status === 'published') writePublishedExtras(updated);
    sendJson(res, 200, detail(updated));
  });

  r.post('/api/studio/videos/:id/cancel', creator, ({ res, params }) => { getVideo(params.id); cancel(params.id); sendJson(res, 200, detail(getVideo(params.id))); });

  // Retry a failed/cancelled job, or re-run a finished one with different options.
  r.post('/api/studio/videos/:id/retry', creator, async ({ req, res, params }) => {
    const v = getVideo(params.id);
    if (v.source === 'rec') throw new HttpError(409, 'Edit and review this story in Rec.');
    const body = await readJson(req);
    if (body.options) updateVideo(v.id, { options_json: JSON.stringify(normalizeOptions(body.options)) });
    if (v.status === 'ready') updateVideo(v.id, { attempts: 0 });
    const r2 = retry(v.id);
    if (!r2.ok) throw new HttpError(409, r2.error);
    sendJson(res, 200, detail(getVideo(v.id)));
  });

  r.post('/api/studio/videos/:id/publish', creator, async ({ req, res, params }) => {
    const v = getVideo(params.id);
    if (v.source === 'rec') throw new HttpError(409, 'Publish this story through Rec review.');
    const { version } = await readJson(req);
    if (!['edited', 'original'].includes(version)) throw new HttpError(400, 'Choose the edited or original version.');
    if (!['ready', 'published'].includes(v.status)) throw new HttpError(409, `Only reviewed videos can be published (this one is ${v.status}).`);
    if (!v.title.trim()) throw new HttpError(400, 'Add a title before publishing.');
    const src = path.join(workDir(v.id), version === 'edited' ? 'edited.mp4' : 'original-preview.mp4');
    if (!fs.existsSync(src)) throw new HttpError(409, 'The processed file is missing; press Retry to process again.');
    assertCapacity(0);
    const publicId = v.public_id || newId(9);
    const dir = ensureDir(publishedDir(publicId));
    const dest = path.join(dir, 'video.mp4');
    fs.rmSync(dest, { force: true });
    try { fs.linkSync(src, dest); } catch { fs.copyFileSync(src, dest); }
    updateVideo(v.id, { status: 'published', public_id: publicId, published_version: version, published_at: v.published_at || now() });
    writePublishedExtras(getVideo(v.id));
    sendJson(res, 200, detail(getVideo(v.id)));
  });

  r.post('/api/studio/videos/:id/unpublish', creator, ({ res, params }) => {
    const v = getVideo(params.id);
    if (v.status !== 'published') throw new HttpError(409, 'Not published');
    rmrf(publishedDir(v.public_id));
    updateVideo(v.id, { status: 'ready', published_version: null });
    sendJson(res, 200, detail(getVideo(v.id)));
  });

  r.del('/api/studio/videos/:id', creator, ({ res, params }) => {
    const v = getVideo(params.id);
    if (isRunning(v.id)) cancel(v.id);
    deleteVideoFiles(v);
    db.prepare('DELETE FROM videos WHERE id = ?').run(v.id);
    sendJson(res, 200, { deleted: v.id });
  });

  // Bulk cleanup of test recordings: everything that isn't published.
  r.post('/api/studio/cleanup', creator, async ({ req, res }) => {
    const { scope } = await readJson(req);
    const rows = scope === 'all'
      ? db.prepare('SELECT * FROM videos').all()
      : db.prepare(`SELECT * FROM videos WHERE status != 'published'`).all();
    for (const v of rows) { if (isRunning(v.id)) cancel(v.id); deleteVideoFiles(v); db.prepare('DELETE FROM videos WHERE id = ?').run(v.id); }
    sendJson(res, 200, { deleted: rows.length, storage: storageStatus() });
  });

  // Private media (creator only). `kind` is from a fixed list; never a user path.
  r.get('/api/studio/videos/:id/media/:kind', creator, ({ req, res, params, url }) => {
    const v = getVideo(params.id);
    const kinds = { original: path.join(originalDir(v.id), `original.${v.ext}`), comparison: path.join(workDir(v.id), 'original-preview.mp4'), edited: path.join(workDir(v.id), 'edited.mp4') };
    if (params.kind === 'thumb') {
      const n = Number(url.searchParams.get('n') ?? v.selected_thumb);
      if (!Number.isInteger(n) || n < 0 || n > 9) throw new HttpError(400, 'Bad thumbnail');
      return sendFile(req, res, path.join(workDir(v.id), `thumb-${n}.jpg`), { cache: 'private, max-age=60' });
    }
    if (params.kind === 'captions') {
      const cues = v.cues_json ? JSON.parse(v.cues_json) : { edited: [] };
      const body = toVtt(url.searchParams.get('version') === 'original' ? originalCues(cues) : cues.edited);
      res.writeHead(200, { 'Content-Type': 'text/vtt; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end(body);
    }
    const file = kinds[params.kind];
    if (!file) throw new HttpError(404, 'Unknown media');
    sendFile(req, res, file, { cache: 'private, no-store', download: url.searchParams.get('download') ? `${v.original_name}` : undefined });
  });

  r.patch('/api/studio/profile', creator, async ({ req, res }) => {
    const b = await readJson(req);
    if (b.displayName !== undefined) {
      const d = String(b.displayName).trim();
      if (!d || d.length > 50) throw new HttpError(400, 'Display name must be 1–50 characters.');
      db.prepare('UPDATE creator SET display_name = ? WHERE id = 1').run(d);
    }
    if (b.bio !== undefined) db.prepare('UPDATE creator SET bio = ? WHERE id = 1').run(String(b.bio).slice(0, 500));
    sendJson(res, 200, getCreator());
  });
}

// Caption text edits are made on the edited timeline; carry them onto the original timeline by cue id.
function originalCues(cues) {
  const byId = new Map(cues.edited.map((c) => [c.id, c.text]));
  return cues.keep ? cues.original.map((c) => ({ ...c, text: byId.get(c.id) ?? c.text })) : cues.edited;
}

function writePublishedExtras(v) {
  const dir = ensureDir(publishedDir(v.public_id));
  const cues = v.cues_json ? JSON.parse(v.cues_json) : null;
  const list = cues ? (v.published_version === 'original' ? originalCues(cues) : cues.edited) : [];
  fs.writeFileSync(path.join(dir, 'captions.vtt'), toVtt(list));
  const thumb = path.join(workDir(v.id), `thumb-${v.selected_thumb}.jpg`);
  if (fs.existsSync(thumb)) fs.copyFileSync(thumb, path.join(dir, 'thumb.jpg'));
}

export function deleteVideoFiles(v) {
  rmrf(originalDir(v.id));
  rmrf(workDir(v.id));
  if (v.public_id) rmrf(publishedDir(v.public_id));
}
