import { sendJson, readJson, readBody, sendFile, HttpError } from '../http.js';
import { requireCreator, isCreator } from '../auth.js';
import * as live from '../live/broadcast.js';

export function registerLive(r) {
  const creator = (ctx) => requireCreator(ctx);

  // Clock sync so the camera can stamp chunks in server time.
  r.get('/api/live/time', ({ res }) => sendJson(res, 200, { serverNow: Date.now() }));

  r.get('/api/studio/live', creator, ({ res }) => sendJson(res, 200, { broadcasts: live.listBroadcasts() }));

  // Live auto-publication is off unless the creator ticks "publishLive" when starting.
  r.post('/api/studio/live', creator, async ({ req, res }) => sendJson(res, 201, live.createBroadcast(await readJson(req))));

  r.post('/api/studio/live/:id/end', creator, ({ res, params }) => { live.endBroadcast(params.id, null); sendJson(res, 200, live.getState(params.id)); });

  r.del('/api/studio/live/:id', creator, ({ res, params }) => { live.deleteBroadcast(params.id); sendJson(res, 200, { deleted: params.id }); });

  r.post('/api/studio/live/:id/ingest', creator, async ({ req, res, params, url }) => {
    const q = (k) => (url.searchParams.has(k) ? Number(url.searchParams.get(k)) : NaN);
    const body = await readBody(req, 8 * 1024 * 1024);
    const out = live.ingestChunk(params.id, { run: q('run'), seq: q('seq'), captureMs: q('t'), runStartMs: q('runStart') }, body);
    sendJson(res, out.status, { ...out.body, state: live.getState(params.id) });
  });

  // Viewer side. Private previews are creator-only; published broadcasts follow the viewer rules.
  r.get('/api/live/:id', ({ req, res, params }) => { live.canView(params.id, isCreator(req)); sendJson(res, 200, live.getState(params.id)); });

  r.get('/api/live/:id/playlist\\.m3u8', ({ req, res, params }) => {
    live.canView(params.id, isCreator(req));
    const body = live.playlist(params.id);
    res.writeHead(200, { 'Content-Type': 'application/vnd.apple.mpegurl', 'Cache-Control': 'no-store' });
    res.end(body);
  });

  r.get('/api/live/:id/seg/:run/:file', ({ req, res, params }) => {
    live.canView(params.id, isCreator(req));
    sendFile(req, res, live.segmentFile(params.id, params.run, params.file), { cache: 'private, max-age=3600', type: 'video/mp2t' });
  });

  r.get('/api/live/:id/captions', ({ req, res, params, url }) => {
    live.canView(params.id, isCreator(req));
    const since = Number(url.searchParams.get('since')) || 0;
    sendJson(res, 200, { cues: live.captionsSince(params.id, since) });
  });
}

export { HttpError };
