// Private, revisioned pre-production. An attestation is never a factual verification.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { db, now } from '../db.js';
import { config } from '../config.js';
import { requireCreator } from '../auth.js';
import { HttpError, sendJson, readJson, sendFile } from '../http.js';
import { assertCapacity, publishedDir, ensureDir } from '../storage.js';

db.exec(`CREATE TABLE IF NOT EXISTS rec_projects (id TEXT PRIMARY KEY, revision INTEGER NOT NULL, body TEXT NOT NULL, updated INTEGER NOT NULL);`);
const busy = new Set();
const root = path.join(config.privateDir, 'rec');
const dir = id => path.join(root, id);
const load = id => {
  const row = db.prepare('SELECT * FROM rec_projects WHERE id=?').get(id);
  if (!row) throw new HttpError(404, 'Project not found');
  return { ...JSON.parse(row.body), id: row.id, revision: row.revision };
};
function save(p) {
  db.prepare('INSERT OR REPLACE INTO rec_projects VALUES (?,?,?,?)').run(p.id,p.revision,JSON.stringify(p),now());
  return p;
}
const clean = (v,n=200) => String(v ?? '').trim().slice(0,n);
export function normalize(b) {
  const kind = ['personal','dramatised','fiction'].includes(b.kind) ? b.kind : 'dramatised';
  const scenes = (Array.isArray(b.scenes) ? b.scenes : []).slice(0,30).map(s=>({
    text:clean(s.text,1200), setting:clean(s.setting), action:clean(s.action,500),
    basis:['memory','reconstruction','fiction'].includes(s.basis)?s.basis:'reconstruction',
    seconds:Math.min(30,Math.max(3,Number(s.seconds)||8))
  }));
  return {title:clean(b.title)||'Untitled', episode:clean(b.episode), kind,
    story:clean(b.story,50000), lesson:clean(b.lesson,2000), nickname:clean(b.nickname,40),
    character:clean(b.character,3000), outfit:clean(b.outfit,2000), scenes};
}
export function blockers(p) {
  const errors=[];
  if(!p.nickname) errors.push('Choose a public nickname.');
  if(!p.story) errors.push('Record or type your story.');
  if(!p.scenes.length || p.scenes.some(s=>!s.text)) errors.push('Every scene needs story text.');
  if(p.kind==='personal' && p.scenes.some(s=>s.basis!=='memory')) errors.push('Use “Based on life · dramatised” when scenes reconstruct memories or add fiction.');
  if(p.kind==='fiction' && !p.lesson) errors.push('Explain the constructive lesson your fiction teaches.');
  if(!p.character || !p.outfit) errors.push('Complete the character and outfit briefs.');
  return errors;
}
function run(args,cwd) {return new Promise((resolve,reject)=>{
  const child=spawn(config.ffmpeg,args,{cwd,stdio:['ignore','ignore','pipe']});let err='';
  const timer=setTimeout(()=>child.kill('SIGKILL'),180000);
  child.stderr.on('data',b=>{err=(err+b).slice(-3000)});
  child.on('error',e=>{clearTimeout(timer);reject(e)});
  child.on('close',code=>{clearTimeout(timer);code===0?resolve():reject(new Error('Preview render failed. Check that FFmpeg includes drawtext. '+err.slice(-300)))});
});}
function wrap(text,width=48) {
  return text.split(/\s+/).reduce((lines,word)=>{
    if((lines.at(-1)+' '+word).length>width) lines.push(word); else lines[lines.length-1]+=(lines.at(-1)?' ':'')+word;
    return lines;
  },['']).join('\n');
}
async function render(p) {
 const cwd=dir(p.id);ensureDir(cwd);assertCapacity(40*1024*1024);
 const parts=[];
 for(let i=0;i<p.scenes.length;i++) {
  const s=p.scenes[i];
  fs.writeFileSync(path.join(cwd,'caption.txt'),wrap(s.text));
  fs.writeFileSync(path.join(cwd,'heading.txt'),wrap(`${p.title} / ${p.nickname} / ${i+1}`,60));
  const filters="drawbox=x=0:y=0:w=iw:h=ih:color=black@0.65:t=fill,drawtext=textfile=heading.txt:expansion=none:fontcolor=0xf5c518:fontsize=24:x=50:y=45,drawtext=textfile=caption.txt:expansion=none:fontcolor=white:fontsize=27:line_spacing=12:x=50:y=140,drawtext=text='STORYBOARD PREVIEW':fontcolor=white:fontsize=18:x=50:y=h-45";
  const input=p.image ? ['-loop','1','-i','character.png','-vf',`scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,${filters}`] : ['-f','lavfi','-i','color=c=0x111318:s=1280x720:r=24','-vf',filters];
  const name=`part-${i}.mp4`;
  await run(['-y',...input,'-t',String(s.seconds),'-r','24','-c:v','libx264','-preset','ultrafast','-pix_fmt','yuv420p','-an',name],cwd);
  parts.push(`file '${name}'`);
 }
 fs.writeFileSync(path.join(cwd,'concat.txt'),parts.join('\n'));
 await run(['-y','-f','concat','-safe','1','-i','concat.txt','-c','copy','-movflags','+faststart','preview.mp4'],cwd);
 await run(['-y','-i','preview.mp4','-frames:v','1','thumb.jpg'],cwd);
 for(let i=0;i<parts.length;i++)fs.rmSync(path.join(cwd,`part-${i}.mp4`),{force:true});
 p.renderedRevision=p.revision;p.renderState='ready';p.error=null;save(p);
}
export function registerRec(r) {
 const auth=requireCreator;
 r.get('/api/rec/projects',auth,({res})=>sendJson(res,200,{projects:db.prepare('SELECT id FROM rec_projects ORDER BY updated DESC').all().map(x=>load(x.id))}));
 r.post('/api/rec/projects',auth,async({req,res})=>{
  const b=await readJson(req);const p=save({...normalize(b),id:crypto.randomUUID(),revision:1,renderState:'none',review:null});
  sendJson(res,201,p);
 });
 r.get('/api/rec/projects/:id',auth,({params,res})=>sendJson(res,200,load(params.id)));
 r.patch('/api/rec/projects/:id',auth,async({params,req,res})=>{
  const p=load(params.id),b=await readJson(req,150000);
  if(busy.has(p.id))throw new HttpError(409,'Wait for the preview to finish.');
  if(b.revision!==p.revision)throw new HttpError(409,'This project changed in another window. Reopen it before saving.');
  sendJson(res,200,save({...p,...normalize(b),revision:p.revision+1,review:null,renderState:'none',renderedRevision:null}));
 });
 r.post('/api/rec/projects/:id/image',auth,async({params,req,res})=>{
  const p=load(params.id);if(busy.has(p.id))throw new HttpError(409,'Rendering in progress.');
  const b=await readJson(req,7*1024*1024);
  if(b.revision!==p.revision)throw new HttpError(409,'Reopen the project before importing.');
  const bytes=Buffer.from(String(b.png||''),'base64');
  if(bytes.length>5*1024*1024 || bytes.subarray(0,8).toString('hex')!=='89504e470d0a1a0a')throw new HttpError(400,'Choose a PNG image under 5 MB.');
  assertCapacity(bytes.length);ensureDir(dir(p.id));fs.writeFileSync(path.join(dir(p.id),'character.png'),bytes);
  sendJson(res,200,save({...p,image:true,revision:p.revision+1,review:null,renderState:'none',renderedRevision:null}));
 });
 r.post('/api/rec/projects/:id/render',auth,({params,res})=>{
  const p=load(params.id),errors=blockers(p);
  if(errors.length)throw new HttpError(400,errors.join(' '));
  if(busy.size)throw new HttpError(409,'A preview is already rendering.');
  if(p.scenes.some(s=>s.text.length>400))throw new HttpError(400,'Split long scenes into shots of 400 characters or fewer for the storyboard preview.');
  if(p.scenes.reduce((n,s)=>n+s.seconds,0)>600)throw new HttpError(400,'Keep each preview under 10 minutes.');
  busy.add(p.id);p.renderState='rendering';p.review=null;save(p);
  render(p).catch(e=>save({...p,renderState:'failed',error:e.message})).finally(()=>busy.delete(p.id));
  sendJson(res,202,p);
 });
 r.post('/api/rec/projects/:id/review',auth,async({params,req,res})=>{
  const p=load(params.id),b=await readJson(req);
  if(p.renderedRevision!==p.revision || p.renderState!=='ready')throw new HttpError(409,'Render the current revision first.');
  if(b.revision!==p.revision || !['story','wardrobe','privacy','rights'].every(k=>b[k]===true))throw new HttpError(400,'Watch the preview and complete all four review checks.');
  p.review={revision:p.revision,at:now(),type:'creator-attested; not independently verified'};
  sendJson(res,200,save(p));
 });
 r.get('/api/rec/projects/:id/media/:kind',auth,({params,req,res})=>{
  const p=load(params.id);const names={preview:'preview.mp4',image:'character.png'};
  if(!names[params.kind])throw new HttpError(404,'Not found');
  sendFile(req,res,path.join(dir(p.id),names[params.kind]),{cache:'private, no-store'});
 });
 r.post('/api/rec/projects/:id/publish',auth,({params,res})=>{
  const p=load(params.id);
  if(blockers(p).length || p.review?.revision!==p.revision || p.renderedRevision!==p.revision || p.renderState!=='ready')throw new HttpError(409,'Complete the review of this revision first.');
  if(p.publishedRevision===p.revision && db.prepare("SELECT id FROM videos WHERE public_id=? AND status='published'").get(p.publicId))return sendJson(res,200,p);
  const id=crypto.randomUUID(),publicId=crypto.randomUUID(),folder=ensureDir(publishedDir(publicId));
  fs.copyFileSync(path.join(dir(p.id),'preview.mp4'),path.join(folder,'video.mp4'));
  fs.copyFileSync(path.join(dir(p.id),'thumb.jpg'),path.join(folder,'thumb.jpg'));
  const labels={personal:'Personal account · creator-attested',dramatised:'Based on life · includes dramatisation',fiction:'Fiction · constructive lesson'};
  const description=`${labels[p.kind]}. Not independently fact-verified. Storyboard preview. By @${p.nickname}. ${p.kind==='fiction'?p.lesson:''}`;
  const t=now(),duration=p.scenes.reduce((n,s)=>n+s.seconds,0);
  db.prepare(`INSERT INTO videos (id,status,source,original_name,mime,ext,size_bytes,options_json,created_at,updated_at,title,description,public_id,published_version,published_at,probe_json) VALUES (?,'published','rec','storyboard.mp4','video/mp4','mp4',?,'{}',?,?,?,?,?,'edited',?,?)`).run(id,fs.statSync(path.join(folder,'video.mp4')).size,t,t,p.title,description,publicId,t,JSON.stringify({duration,orientation:'landscape'}));
  p.publicId=publicId;p.publishedRevision=p.revision;save(p);sendJson(res,201,p);
 });
 // Interrupted renders are retryable after a service restart.
 for(const row of db.prepare('SELECT id FROM rec_projects').all()) {const p=load(row.id);if(p.renderState==='rendering')save({...p,renderState:'failed',error:'Rendering was interrupted. Please retry.'});}
}
