// Captions: group word timings into readable cues, remap them onto the edited
// timeline after silence trimming, and render WebVTT.

const MAX_CHARS = 84; // two comfortable lines
const MAX_DUR = 5.5;
const MAX_GAP = 0.9;

export function wordsToCues(words) {
  const cues = [];
  let cur = null;
  for (const w of words) {
    const text = w.w.replace(/\s+/g, ' ');
    const breakHere = cur && (
      w.s - cur.end > MAX_GAP ||
      (cur.text + text).trim().length > MAX_CHARS ||
      w.e - cur.start > MAX_DUR ||
      /[.?!]$/.test(cur.text.trim()) && (cur.text.trim().length > 20)
    );
    if (!cur || breakHere) {
      if (cur) cues.push(cur);
      cur = { start: w.s, end: w.e, text: text.trimStart() };
    } else {
      cur.text += text.startsWith(' ') || cur.text.endsWith(' ') ? text : ' ' + text;
      cur.end = w.e;
    }
  }
  if (cur) cues.push(cur);
  return cues.map((c, i) => ({ id: i + 1, start: round(c.start), end: round(Math.max(c.end, c.start + 0.3)), text: c.text.trim() }));
}

const round = (x) => Math.round(x * 1000) / 1000;

// keep = [[start, end], ...] ranges of the original that survive trimming.
export function mapTime(t, keep) {
  if (!keep) return t;
  let out = 0;
  for (const [a, b] of keep) {
    if (t < a) return out;
    if (t <= b) return out + (t - a);
    out += b - a;
  }
  return out;
}

export function remapCues(cues, keep) {
  if (!keep) return cues;
  return cues
    .map((c) => ({ ...c, start: round(mapTime(c.start, keep)), end: round(mapTime(c.end, keep)) }))
    .filter((c) => c.end - c.start > 0.05);
}

const ts = (t) => {
  const ms = Math.max(0, Math.round(t * 1000));
  const h = Math.floor(ms / 3600000), m = Math.floor(ms / 60000) % 60, s = Math.floor(ms / 1000) % 60, r = ms % 1000;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}.${String(r).padStart(3, '0')}`;
};

export function toVtt(cues) {
  const body = cues
    .filter((c) => c.text && c.text.trim())
    .map((c) => `${c.id}\n${ts(c.start)} --> ${ts(c.end)}\n${c.text.replace(/-->/g, '→').replace(/\n{2,}/g, '\n')}`)
    .join('\n\n');
  return `WEBVTT\n\n${body}\n`;
}

// Validates caption edits from the review screen.
export function sanitizeCues(input, duration) {
  if (!Array.isArray(input) || input.length > 5000) throw new Error('Captions must be a list');
  return input.map((c, i) => {
    const start = Number(c.start), end = Number(c.end);
    if (!Number.isFinite(start) || !Number.isFinite(end) || start < 0 || end <= start || (duration && start > duration + 1)) {
      throw new Error(`Caption ${i + 1} has invalid timing`);
    }
    // Keep the original cue id so text edits can be carried over to the unedited timeline.
    const id = Number.isInteger(c.id) && c.id > 0 && c.id < 100000 ? c.id : 100000 + i;
    return { id, start: round(start), end: round(end), text: String(c.text ?? '').slice(0, 300) };
  });
}
