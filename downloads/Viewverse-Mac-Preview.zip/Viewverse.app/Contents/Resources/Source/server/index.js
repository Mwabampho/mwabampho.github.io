// Viewverse local prototype server.
// HTTPS on the local network only (no tunnels, no port forwarding, no cloud).
import https from 'node:https';
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from './config.js';
import { db, now } from './db.js';
import { createRouter, sendJson, sendFile, HttpError } from './http.js';
import { pruneSessions, requireCreator } from './auth.js';
import { registerPublic } from './routes/public.js';
import { registerStudio, deleteVideoFiles } from './routes/studio.js';
import { registerRec } from './routes/rec.js';
import { registerLive } from './routes/live.js';
import { startRunner } from './pipeline/jobs.js';
import { recoverBroadcasts } from './live/broadcast.js';

const certFile = path.join(config.certDir, 'server.crt');
const keyFile = path.join(config.certDir, 'server.key');
const caFile = path.join(config.certDir, 'viewverse-local-ca.crt');
if (!fs.existsSync(certFile) || !fs.existsSync(keyFile)) {
  console.error('\nNo HTTPS certificate found. Run:  npm run setup\n');
  process.exit(1);
}

const router = createRouter();
router.get('/api/studio/connect', (ctx) => {
  requireCreator(ctx);
  sendJson(ctx.res, 200, {
    appUrls: lanAddresses().map((ip) => `https://${ip}:${config.port}`),
    setupUrls: config.setupHttpPort ? lanAddresses().map((ip) => `http://${ip}:${config.setupHttpPort}/phone-setup`) : [],
    caFingerprint: caFingerprint(),
  });
});
registerPublic(router);
registerStudio(router);
registerLive(router);
registerRec(router);

const SECURITY_HEADERS = {
  'Content-Security-Policy': "default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; worker-src 'self' blob:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'Permissions-Policy': 'camera=(self), microphone=(self), geolocation=()',
  'Cross-Origin-Opener-Policy': 'same-origin',
};

async function handle(req, res) {
  for (const [k, v] of Object.entries(SECURITY_HEADERS)) res.setHeader(k, v);
  const url = new URL(req.url, 'https://localhost');
  const pathname = decodeURIComponent(url.pathname);
  try {
    if (pathname.startsWith('/api/') || pathname.startsWith('/media/')) {
      // CSRF guard: state-changing API calls must carry a custom header, which other
      // sites can't add without a CORS preflight (which we never approve).
      if (!['GET', 'HEAD'].includes(req.method) && req.headers['x-viewverse'] !== '1') throw new HttpError(403, 'Missing request header');
      const m = router.match(req.method, pathname);
      if (!m) throw new HttpError(404, 'Not found');
      const ctx = { req, res, params: m.params, url };
      for (const h of m.handlers) { await h(ctx); if (res.writableEnded || res.headersSent) break; }
      return;
    }
    return serveStatic(req, res, pathname);
  } catch (e) {
    if (res.headersSent) { res.destroy(); return; }
    const status = e instanceof HttpError ? e.status : e.status || 500;
    if (status >= 500 && !(e instanceof HttpError)) console.error(e);
    sendJson(res, status, { error: status >= 500 && !(e instanceof HttpError) ? 'Something went wrong on the laptop. Check the terminal running Viewverse.' : e.message, ...(e.extra || {}) });
  }
}

function serveStatic(req, res, pathname) {
  if (pathname === '/viewverse-local-ca.crt') return sendFile(req, res, caFile, { type: 'application/x-x509-ca-cert', download: 'viewverse-local-ca.crt' });
  const rel = path.normalize(pathname).replace(/^(\.\.[/\\])+/, '');
  let file = path.join(config.staticDir, rel);
  if (!file.startsWith(config.staticDir)) throw new HttpError(400, 'Bad path');
  if (!path.extname(file) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(config.staticDir, 'index.html');
  const immutable = /\/vendor\//.test(file);
  sendFile(req, res, file, { cache: immutable ? 'public, max-age=86400' : 'no-cache' });
}

// Housekeeping: abandoned uploads, expired sessions.
function housekeeping() {
  pruneSessions();
  const cutoff = now() - config.abandonedUploadHours * 3600 * 1000;
  const stale = db.prepare(`SELECT * FROM videos WHERE status IN ('draft', 'uploading') AND updated_at < ?`).all(cutoff);
  for (const v of stale) { deleteVideoFiles(v); db.prepare('DELETE FROM videos WHERE id = ?').run(v.id); }
  if (stale.length) console.log(`[cleanup] removed ${stale.length} abandoned upload(s)`);
}

recoverBroadcasts();
startRunner();
housekeeping();
setInterval(housekeeping, 30 * 60 * 1000).unref();

const server = https.createServer({ cert: fs.readFileSync(certFile), key: fs.readFileSync(keyFile) }, handle);
server.requestTimeout = 0; // long uploads are chunked; each chunk is bounded
server.headersTimeout = 30_000;
server.listen(config.port, config.host, () => {
  const lan = lanAddresses();
  const fp = caFingerprint();
  console.log(`\n  VIEWVERSE is running (local prototype, not public)\n`);
  if (config.setupHttpPort) console.log(`  On this laptop:   http://localhost:${config.setupHttpPort}   (no certificate needed)`);
  else console.log(`  On this laptop:   https://localhost:${config.port}`);
  for (const ip of lan) console.log(`  On your phone:    https://${ip}:${config.port}   (same Wi-Fi)`);
  if (config.setupHttpPort) for (const ip of lan) console.log(`  Phone setup page: http://${ip}:${config.setupHttpPort}/phone-setup  (certificate download + steps)`);
  if (fp) console.log(`\n  Local CA fingerprint (SHA-256):\n  ${fp}`);
  console.log(`\n  Guest viewing: ${config.allowGuestViewing ? 'ON (anyone on this Wi-Fi can watch published videos)' : 'OFF (sign-in required)'}`);
  console.log('  Press Ctrl+C to stop.\n');
});

// Plain-HTTP listener.
//  - From this laptop (loopback): the full app at http://localhost:PORT. Browsers treat
//    localhost as a secure context, so the camera works without installing the CA on the Mac.
//  - From any other device: only the certificate + setup page; everything else redirects
//    to HTTPS. App data is never sent over plain HTTP on the network.
if (config.setupHttpPort) {
  http.createServer((req, res) => {
    if (isLoopbackSocket(req)) return handle(req, res);
    const host = (req.headers.host || '').split(':')[0].replace(/[^A-Za-z0-9.-]/g, '');
    if (req.url === '/viewverse-local-ca.crt' && fs.existsSync(caFile)) {
      res.writeHead(200, { 'Content-Type': 'application/x-x509-ca-cert', 'Content-Disposition': 'attachment; filename="viewverse-local-ca.crt"' });
      return fs.createReadStream(caFile).pipe(res);
    }
    if (req.url === '/' || req.url === '/phone-setup') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', ...SECURITY_HEADERS, 'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'" });
      return res.end(setupPage(host));
    }
    res.writeHead(302, { Location: `https://${host}:${config.port}${req.url.startsWith('/') ? req.url : '/'}` });
    res.end();
  }).listen(config.setupHttpPort, config.host);
}

function setupPage(host) {
  const fp = caFingerprint() || 'missing – run npm run setup';
  return `<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><title>Viewverse phone setup</title>
<body style="font:16px/1.5 -apple-system,system-ui,sans-serif;background:#16181b;color:#f5f5f7;max-width:640px;margin:0 auto;padding:20px">
<h1 style="letter-spacing:.12em;font-weight:900">VIEWVERSE</h1><h2>Connect this phone</h2>
<p>Your phone needs to trust this laptop's private certificate once, so the browser allows the camera over HTTPS.</p>
<p><a style="display:inline-block;background:#f5c518;color:#111;padding:12px 18px;border-radius:999px;font-weight:700;text-decoration:none" href="/viewverse-local-ca.crt">Download certificate</a></p>
<h3>iPhone / iPad</h3><ol><li>Tap Download, then Allow.</li><li>Settings → <b>Profile Downloaded</b> → Install.</li><li>Settings → General → About → <b>Certificate Trust Settings</b> → turn on “Viewverse Local CA”.</li></ol>
<h3>Android</h3><ol><li>Tap Download.</li><li>Settings → Security & privacy → More security settings → Encryption & credentials → <b>Install a certificate → CA certificate</b> → pick the file.</li></ol>
<p>Check the fingerprint shown on the phone matches the one printed in the laptop's terminal:<br><code style="word-break:break-all;font-size:12px">${fp}</code></p>
<p>This certificate is limited to private network addresses and <code>.local</code> names. Remove it after testing.</p>
<p><a style="color:#f5c518" href="https://${host}:${config.port}/">Open Viewverse →</a></p></body>`;
}

function caFingerprint() {
  if (!fs.existsSync(caFile)) return null;
  return crypto.createHash('sha256').update(new crypto.X509Certificate(fs.readFileSync(caFile)).raw).digest('hex').toUpperCase().match(/.{2}/g).join(':');
}

function isLoopbackSocket(req) {
  return ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress);
}

function lanAddresses() {
  let interfaces = {};
  try { interfaces = os.networkInterfaces(); } catch { /* Local browser access remains available. */ }
  return Object.values(interfaces).flat().filter((i) => i && i.family === 'IPv4' && !i.internal).map((i) => i.address);
}

for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { console.log('\nStopping Viewverse…'); process.exit(0); });
