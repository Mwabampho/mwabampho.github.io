// Storage layout and privacy boundary.
//
//   data/private/originals/<videoId>/original.<ext>   the untouched upload (creator only)
//   data/private/work/<videoId>/                      edited output, thumbnails, audio, logs (creator only)
//   data/private/live/<broadcastId>/                  live ingest + processed segments (served via auth checks)
//   data/published/<publicId>/                        approved copies for viewers
//
// Nothing under data/ is served as static files. Every media response goes through a
// route that checks who is asking. Published copies use a different random id than the
// private video id, so knowing a published URL reveals nothing about private paths.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from './config.js';
import { HttpError } from './http.js';

export const dirs = {
  originals: path.join(config.privateDir, 'originals'),
  work: path.join(config.privateDir, 'work'),
  live: path.join(config.privateDir, 'live'),
  published: config.publicDir,
};
for (const d of Object.values(dirs)) fs.mkdirSync(d, { recursive: true, mode: 0o700 });

const ID_RE = /^[A-Za-z0-9_-]{8,40}$/;
export const newId = (bytes = 12) => crypto.randomBytes(bytes).toString('base64url');

function safeJoin(base, id, ...rest) {
  if (!ID_RE.test(id)) throw new HttpError(400, 'Bad id');
  const p = path.join(base, id, ...rest);
  if (!p.startsWith(base + path.sep)) throw new HttpError(400, 'Bad path');
  return p;
}
export const originalDir = (id) => safeJoin(dirs.originals, id);
export const workDir = (id) => safeJoin(dirs.work, id);
export const liveDir = (id) => safeJoin(dirs.live, id);
export const publishedDir = (id) => safeJoin(dirs.published, id);

export function ensureDir(d) { fs.mkdirSync(d, { recursive: true, mode: 0o700 }); return d; }
export function rmrf(d) { fs.rmSync(d, { recursive: true, force: true }); }

// Filenames from users are only ever kept as display metadata, never used as paths.
export function sanitizeDisplayName(name) {
  const base = String(name || 'video').split(/[\\/]/).pop();
  return base.normalize('NFKC').replace(/[^\p{L}\p{N} ._()-]/gu, '_').replace(/^\.+/, '').slice(0, 120) || 'video';
}

export function dirSize(d) {
  let total = 0;
  const walk = (p) => {
    let entries;
    try { entries = fs.readdirSync(p, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      const f = path.join(p, e.name);
      if (e.isDirectory()) walk(f); else { try { total += fs.statSync(f).size; } catch {} }
    }
  };
  walk(d);
  return total;
}

export function storageStatus() {
  const used = dirSize(config.dataDir);
  let freeBytes = null;
  try { const s = fs.statfsSync(config.dataDir); freeBytes = s.bavail * s.bsize; } catch {}
  return { usedBytes: used, quotaBytes: config.storageQuotaGB * 1024 ** 3, freeDiskBytes: freeBytes, minFreeDiskBytes: config.minFreeDiskGB * 1024 ** 3 };
}

// Throws a 507 if accepting `extraBytes` more would exceed the quota or leave too little disk.
export function assertCapacity(extraBytes) {
  const s = storageStatus();
  if (s.usedBytes + extraBytes > s.quotaBytes) {
    throw new HttpError(507, `Viewverse storage limit reached (${(s.usedBytes / 1024 ** 3).toFixed(2)} of ${config.storageQuotaGB} GB used). Delete test recordings in Studio or raise STORAGE_QUOTA_GB.`);
  }
  if (s.freeDiskBytes !== null && s.freeDiskBytes - extraBytes < s.minFreeDiskBytes) {
    throw new HttpError(507, `Not enough free disk space on this laptop (${(s.freeDiskBytes / 1024 ** 3).toFixed(1)} GB free, keeping at least ${config.minFreeDiskGB} GB spare).`);
  }
}
