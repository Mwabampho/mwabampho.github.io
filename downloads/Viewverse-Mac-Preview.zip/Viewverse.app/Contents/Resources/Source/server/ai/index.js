// AI service boundary. The rest of the app only calls status(), transcribe() and suggest().
// Swap providers with AI_PROVIDER. The default ("apple-local") runs Apple's on-device
// speech and language models through bin/viewverse-ai — no audio or text leaves the Mac.
// "none" disables AI features; the pipeline still produces an edited video and says
// honestly that captions/suggestions are unavailable.
import fs from 'node:fs';
import { config } from '../config.js';
import { run } from '../media/run.js';

function parseHelperOutput(stdout) {
  const line = stdout.trim().split('\n').pop();
  try { return JSON.parse(line); } catch { return { ok: false, error: 'AI helper returned unreadable output' }; }
}

async function helper(args, { signal, input, timeoutSec = 600 } = {}) {
  try {
    const { stdout } = await run(config.aiHelper, args, { signal, input, timeoutSec });
    return parseHelperOutput(stdout);
  } catch (e) {
    if (e.cancelled) throw e;
    // The helper exits non-zero with a JSON error message on stdout.
    const parsed = e.stdout ? parseHelperOutput(e.stdout) : null;
    return parsed && parsed.error ? parsed : { ok: false, error: e.message };
  }
}

const appleLocal = {
  name: 'apple-local',
  async status() {
    if (!fs.existsSync(config.aiHelper)) {
      const reason = 'AI helper not built. Run "npm run setup".';
      return { transcription: { available: false, reason }, suggestions: { available: false, reason } };
    }
    const s = await helper(['status'], { timeoutSec: 30 });
    if (!s.ok) return { transcription: { available: false, reason: s.error }, suggestions: { available: false, reason: s.error } };
    const hasLocale = (s.speechLocales || []).some((l) => l.toLowerCase() === config.speechLocale.toLowerCase());
    return {
      transcription: {
        available: s.speech === 'available' && hasLocale,
        engine: 'Apple Speech (on-device)',
        reason: s.speech !== 'available' ? `Speech: ${s.speech}` : hasLocale ? undefined : `Speech model for ${config.speechLocale} is not installed on this Mac`,
      },
      suggestions: {
        available: s.llm === 'available',
        engine: 'Apple Foundation Models (on-device)',
        reason: s.llm === 'available' ? undefined : `Language model ${s.llm}. Apple Intelligence must be enabled in System Settings.`,
      },
    };
  },
  async transcribe(wavPath, { signal } = {}) {
    const r = await helper(['transcribe', wavPath, config.speechLocale], { signal, timeoutSec: config.stepTimeoutSec });
    if (!r.ok) throw new Error(r.error || 'Transcription failed');
    return { engine: r.engine, words: r.words.map((w) => ({ w: w.w, s: w.s, e: w.e })) };
  },
  async suggest(transcript, { signal } = {}) {
    const r = await helper(['suggest'], { signal, input: JSON.stringify({ transcript }), timeoutSec: 120 });
    if (!r.ok) throw new Error(r.error || 'Suggestion failed');
    return { engine: r.engine, title: String(r.title).slice(0, 100), description: String(r.description).slice(0, 1000) };
  },
};

const none = {
  name: 'none',
  async status() {
    const reason = 'AI features are turned off (AI_PROVIDER=none)';
    return { transcription: { available: false, reason }, suggestions: { available: false, reason } };
  },
  async transcribe() { throw new Error('Transcription is turned off (AI_PROVIDER=none)'); },
  async suggest() { throw new Error('Suggestions are turned off (AI_PROVIDER=none)'); },
};

const providers = { 'apple-local': appleLocal, none };
export const ai = providers[config.aiProvider] || none;

let cached = null, cachedAt = 0;
export async function aiStatus() {
  if (cached && Date.now() - cachedAt < 60_000) return cached;
  cached = { provider: ai.name, dataLeavesMachine: false, ...(await ai.status()) };
  cachedAt = Date.now();
  return cached;
}
