// Uploaded-video editing pipeline. Each step records what it actually did in a report
// that the creator sees on the review screen. AI is only used for transcription and
// title/description suggestions; everything else is ordinary ffmpeg processing.
import fs from 'node:fs';
import path from 'node:path';
import { config } from '../config.js';
import { ai, aiStatus } from '../ai/index.js';
import * as ops from '../media/ops.js';
import { wordsToCues, remapCues } from '../captions.js';
import { workDir, originalDir, ensureDir } from '../storage.js';

export const DEFAULT_OPTIONS = { captions: true, normalize: true, denoise: false, trimSilence: true, suggest: true };

export function normalizeOptions(o = {}) {
  const out = { ...DEFAULT_OPTIONS };
  for (const k of Object.keys(DEFAULT_OPTIONS)) if (typeof o[k] === 'boolean') out[k] = o[k];
  return out;
}

const WEIGHTS = { inspect: 0.03, preview: 0.25, transcribe: 0.12, silence: 0.05, loudness: 0.08, render: 0.37, thumbnails: 0.05, suggest: 0.05 };

export async function processVideo(video, { signal, update }) {
  const opts = normalizeOptions(JSON.parse(video.options_json));
  const work = ensureDir(workDir(video.id));
  const input = path.join(originalDir(video.id), `original.${video.ext}`);
  if (!fs.existsSync(input)) throw new Error('The original file is missing, so it cannot be processed.');

  const report = [];
  const add = (key, label, kind, status, detail) => { report.push({ key, label, kind, status, detail }); update({ report_json: JSON.stringify(report) }); };
  let done = 0;
  const stepStart = (name, label) => update({ step: label, progress: done });
  const stepEnd = (name) => { done += WEIGHTS[name]; update({ progress: Math.min(0.99, done) }); };
  const sub = (name) => (f) => update({ progress: Math.min(0.99, done + WEIGHTS[name] * f) });
  maybeInjectFailure(video);

  // 1. Inspect and validate
  stepStart('inspect', 'Inspecting video');
  const p = await ops.probe(input, { signal });
  if (!p.hasVideo) throw new Error('This file has no video track.');
  if (!p.durationKnown) p.duration = await ops.measureDuration(input, { signal });
  if (!(p.duration > 0.5)) throw new Error('This video is too short or could not be decoded.');
  if (p.duration > config.maxDurationSec + 1) throw new Error(`This video is ${Math.round(p.duration)}s long; the limit is ${config.maxDurationSec}s (MAX_DURATION_SEC).`);
  update({ probe_json: JSON.stringify(p) });
  const orientationDetail = [
    p.rotation ? `Rotated ${p.rotation}° using the camera's orientation flag` : 'No rotation needed',
    Math.abs(p.sar - 1) > 0.01 ? `stretched pixels corrected (${p.sar.toFixed(2)}:1 → square)` : null,
    `${p.displayW}×${p.displayH} ${p.orientation}`,
  ].filter(Boolean).join('; ');
  add('orientation', 'Orientation & aspect ratio', 'media', p.rotation || Math.abs(p.sar - 1) > 0.01 ? 'applied' : 'checked', orientationDetail);
  stepEnd('inspect');

  // 2. Faithful playable copy of the original (for comparison, or publishing unedited)
  stepStart('preview', 'Preparing original for comparison');
  await ops.render({ input, output: path.join(work, 'original-preview.mp4'), probeInfo: p, signal, onProgress: sub('preview'), expectedDuration: p.duration });
  stepEnd('preview');

  // 3. Transcription (AI, on-device)
  stepStart('transcribe', 'Transcribing speech');
  let cuesOriginal = [];
  let transcript = '';
  const status = await aiStatus();
  if (!opts.captions) add('captions', 'Captions', 'ai', 'disabled', 'Turned off for this video');
  else if (!p.hasAudio) add('captions', 'Captions', 'ai', 'skipped', 'The video has no audio track');
  else if (!status.transcription.available) add('captions', 'Captions', 'ai', 'unavailable', status.transcription.reason);
  else {
    try {
      const wav = path.join(work, 'speech.wav');
      await ops.extractSpeechAudio(input, wav, { signal });
      const t = await ai.transcribe(wav, { signal });
      fs.rmSync(wav, { force: true });
      cuesOriginal = wordsToCues(t.words);
      transcript = cuesOriginal.map((c) => c.text).join(' ');
      add('captions', 'Captions', 'ai', cuesOriginal.length ? 'applied' : 'skipped',
        cuesOriginal.length ? `${cuesOriginal.length} captions from ${t.words.length} recognised words (${t.engine}). Check them before publishing.` : 'No speech was recognised');
    } catch (e) {
      if (signal.aborted) throw e;
      add('captions', 'Captions', 'ai', 'failed', `Transcription failed: ${e.message}. The video can still be published without captions.`);
    }
  }
  stepEnd('transcribe');

  // 4. Silence trimming (optional)
  stepStart('silence', 'Looking for long silences');
  let trim = null;
  if (!opts.trimSilence) add('trim', 'Trim long silences', 'media', 'disabled', 'Turned off for this video');
  else if (!p.hasAudio) add('trim', 'Trim long silences', 'media', 'skipped', 'No audio track to analyse');
  else {
    const { silences, trailingStart } = await ops.detectSilences(input, { signal });
    trim = ops.keepRanges(silences, trailingStart, p.duration);
    if (trim && p.duration - trim.removed < 1) trim = null; // never cut a video down to nothing
    add('trim', 'Trim long silences', 'media', trim ? 'applied' : 'skipped',
      trim ? `Removed ${trim.count} silence${trim.count > 1 ? 's' : ''} longer than ${config.silenceMinSec}s (${trim.removed.toFixed(1)}s total), keeping ${config.silenceKeepSec}s around speech`
        : `No silences longer than ${config.silenceMinSec}s found`);
  }
  stepEnd('silence');

  // 5. Noise reduction (optional) + loudness measurement
  stepStart('loudness', 'Measuring loudness');
  if (!p.hasAudio) add('denoise', 'Noise reduction', 'media', 'skipped', 'No audio track');
  else add('denoise', 'Noise reduction', 'media', opts.denoise ? 'applied' : 'disabled',
    opts.denoise ? 'Gentle FFT noise reduction (12 dB) with a 60 Hz rumble filter' : 'Off (turn on for noisy rooms)');
  let loud = null;
  if (!opts.normalize) add('normalize', 'Audio level', 'media', 'disabled', 'Turned off for this video');
  else if (!p.hasAudio) add('normalize', 'Audio level', 'media', 'skipped', 'No audio track');
  else {
    const m = await ops.measureLoudness(input, { keep: trim?.keep, denoise: opts.denoise, signal });
    if (!Number.isFinite(m.input_i) || m.input_i < -60) add('normalize', 'Audio level', 'media', 'skipped', 'Audio is almost silent; left unchanged');
    else if (Math.abs(m.input_i - config.targetLufs) <= 1 && m.input_tp <= -1) add('normalize', 'Audio level', 'media', 'skipped', `Already at a comfortable level (${m.input_i.toFixed(1)} LUFS)`);
    else {
      loud = m;
      add('normalize', 'Audio level', 'media', 'applied', `Loudness ${m.input_i.toFixed(1)} → ${config.targetLufs} LUFS (EBU R128, linear gain, peaks limited to −1.5 dBTP)`);
    }
  }
  stepEnd('loudness');

  // 6. Render edited version
  stepStart('render', 'Rendering edited video');
  const editedDuration = trim ? trim.keep.reduce((s, [a, b]) => s + b - a, 0) : p.duration;
  await ops.render({ input, output: path.join(work, 'edited.mp4'), probeInfo: p, keep: trim?.keep, denoise: opts.denoise && p.hasAudio, loud, signal, onProgress: sub('render'), expectedDuration: editedDuration });
  stepEnd('render');

  // 7. Thumbnails from the real frames of the edited video
  stepStart('thumbnails', 'Choosing thumbnail frames');
  const thumbs = await ops.thumbnails(path.join(work, 'edited.mp4'), editedDuration, work, { signal });
  add('thumbnails', 'Thumbnail choices', 'media', thumbs.length ? 'applied' : 'failed', `${thumbs.length} frames taken from the video`);
  stepEnd('thumbnails');

  // 8. Title/description suggestion (AI, on-device)
  stepStart('suggest', 'Suggesting title and description');
  let suggestion = null;
  if (!opts.suggest) add('suggest', 'Title & description', 'ai', 'disabled', 'Turned off for this video');
  else if (transcript.split(/\s+/).filter(Boolean).length < 4) add('suggest', 'Title & description', 'ai', 'skipped', 'Not enough recognised speech to base a suggestion on');
  else if (!status.suggestions.available) add('suggest', 'Title & description', 'ai', 'unavailable', status.suggestions.reason);
  else {
    try {
      suggestion = await ai.suggest(transcript, { signal });
      add('suggest', 'Title & description', 'ai', 'applied', `Suggested from the transcript by ${suggestion.engine}. Edit freely.`);
    } catch (e) {
      if (signal.aborted) throw e;
      add('suggest', 'Title & description', 'ai', 'failed', e.message);
    }
  }
  stepEnd('suggest');

  const cues = { original: cuesOriginal, keep: trim?.keep || null, edited: remapCues(cuesOriginal, trim?.keep) };
  const fields = {
    cues_json: JSON.stringify(cues), thumbs_json: JSON.stringify(thumbs), suggestion_json: suggestion ? JSON.stringify(suggestion) : null,
    report_json: JSON.stringify(report), step: null, progress: 1,
    probe_json: JSON.stringify({ ...p, editedDuration }),
  };
  if (suggestion && !video.title) { fields.title = suggestion.title; fields.description = suggestion.description; }
  return fields;
}

// Test hook: with NODE_ENV=test, a file named "*fail-once*" fails its first attempt so the
// retry path can be exercised by automated tests. Ignored outside tests.
function maybeInjectFailure(video) {
  if (process.env.NODE_ENV === 'test' && video.original_name.includes('fail-once') && video.attempts === 1) {
    throw new Error('Simulated failure for testing (TEST_FAIL_ONCE)');
  }
}
