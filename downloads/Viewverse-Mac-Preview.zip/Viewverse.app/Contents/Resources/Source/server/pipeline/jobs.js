// Bounded job runner for uploaded videos. The videos table is the queue:
//   queued → processing → ready | failed | cancelled
// At most MAX_CONCURRENT_JOBS run at once; each has an AbortController for cancel.
import { db, now } from '../db.js';
import { config } from '../config.js';
import { processVideo } from './upload-pipeline.js';

const running = new Map(); // videoId -> AbortController

export function updateVideo(id, fields) {
  const keys = Object.keys(fields);
  if (!keys.length) return;
  db.prepare(`UPDATE videos SET ${keys.map((k) => `${k} = ?`).join(', ')}, updated_at = ? WHERE id = ?`)
    .run(...keys.map((k) => fields[k]), now(), id);
}

export function recoverInterruptedJobs() {
  db.prepare(`UPDATE videos SET status = 'failed', step = NULL, error = 'Processing was interrupted because Viewverse stopped. Press Retry to run it again.', updated_at = ? WHERE status = 'processing'`).run(now());
}

export function enqueue(id) {
  updateVideo(id, { status: 'queued', error: null, progress: 0, step: null });
  tick();
}

export function cancel(id) {
  const ctl = running.get(id);
  if (ctl) ctl.abort();
  const v = db.prepare('SELECT status FROM videos WHERE id = ?').get(id);
  if (v && ['queued', 'processing'].includes(v.status)) updateVideo(id, { status: 'cancelled', step: null, error: 'Cancelled by you. The original is kept; press Retry to process it again.' });
}

export function retry(id) {
  const v = db.prepare('SELECT status, attempts FROM videos WHERE id = ?').get(id);
  if (!v) return { ok: false, error: 'Not found' };
  if (!['failed', 'cancelled', 'ready'].includes(v.status)) return { ok: false, error: `Can't reprocess a video that is ${v.status}` };
  if (v.status === 'failed' && v.attempts >= config.maxJobAttempts) return { ok: false, error: `Stopped after ${config.maxJobAttempts} attempts. Delete this upload and try a different file, or raise MAX_JOB_ATTEMPTS.` };
  enqueue(id);
  return { ok: true };
}

export const isRunning = (id) => running.has(id);

function tick() {
  while (running.size < config.maxConcurrentJobs) {
    const next = db.prepare(`SELECT * FROM videos WHERE status = 'queued' ORDER BY updated_at ASC LIMIT 1`).get();
    if (!next) return;
    start(next);
  }
}

async function start(video) {
  const ctl = new AbortController();
  running.set(video.id, ctl);
  const attempts = video.attempts + 1;
  updateVideo(video.id, { status: 'processing', attempts, error: null, progress: 0, report_json: null });
  const update = (fields) => { if (!ctl.signal.aborted) updateVideo(video.id, fields); };
  try {
    const fields = await processVideo({ ...video, attempts }, { signal: ctl.signal, update });
    if (!ctl.signal.aborted) updateVideo(video.id, { ...fields, status: 'ready' });
  } catch (e) {
    if (!ctl.signal.aborted) {
      console.error(`[job ${video.id}] failed:`, e.message);
      const left = config.maxJobAttempts - attempts;
      updateVideo(video.id, { status: 'failed', step: null, error: `${e.message}${left > 0 ? '' : ' (no retries left)'}` });
    }
  } finally {
    running.delete(video.id);
    setImmediate(tick);
  }
}

export function startRunner() {
  recoverInterruptedJobs();
  tick();
}
