// Viewverse on-device AI helper.
// Uses only Apple frameworks that run locally on this Mac:
//   - Speech (SpeechAnalyzer + SpeechTranscriber) for transcription
//   - FoundationModels (the on-device system language model) for title/description suggestions
// No network access is made by this program. Output is always a single JSON object on stdout.
//
// Usage:
//   viewverse-ai status
//   viewverse-ai transcribe <audio-file> [locale]
//   viewverse-ai suggest            (reads {"transcript": "..."} from stdin)

import Foundation
import Speech
import AVFoundation
import FoundationModels

func emit(_ obj: [String: Any]) {
    let data = try! JSONSerialization.data(withJSONObject: obj, options: [])
    FileHandle.standardOutput.write(data)
    FileHandle.standardOutput.write("\n".data(using: .utf8)!)
}

func fail(_ message: String, code: Int32 = 1) -> Never {
    emit(["ok": false, "error": message])
    exit(code)
}

@Generable
struct VideoMetadata {
    @Guide(description: "A short, accurate title under 70 characters, based only on what the speaker says")
    var title: String
    @Guide(description: "One or two plain sentences describing what the video contains. Only facts stated in the transcript.")
    var description: String
}

func status() async {
    var speech = "unavailable"
    if SpeechTranscriber.isAvailable {
        let installed = await SpeechTranscriber.installedLocales
        speech = installed.isEmpty ? "no-language-installed" : "available"
    }
    var llm = "available"
    switch SystemLanguageModel.default.availability {
    case .available: llm = "available"
    case .unavailable(let reason): llm = "unavailable: \(reason)"
    }
    let installed = await SpeechTranscriber.installedLocales.map { $0.identifier(.bcp47) }
    emit(["ok": true, "speech": speech, "speechLocales": installed, "llm": llm])
}

func transcribe(path: String, localeId: String) async {
    guard SpeechTranscriber.isAvailable else { fail("On-device speech transcription is not available on this Mac.") }
    let url = URL(fileURLWithPath: path)
    let wanted = Locale(identifier: localeId)
    guard let locale = await SpeechTranscriber.supportedLocale(equivalentTo: wanted) else {
        fail("Language \(localeId) is not supported for on-device transcription.")
    }
    let installed = await SpeechTranscriber.installedLocales
    guard installed.contains(where: { $0.identifier(.bcp47) == locale.identifier(.bcp47) }) else {
        fail("The on-device speech model for \(localeId) is not installed. Install it in System Settings > General > Keyboard > Dictation.")
    }
    let transcriber = SpeechTranscriber(locale: locale, transcriptionOptions: [], reportingOptions: [], attributeOptions: [.audioTimeRange])
    let analyzer = SpeechAnalyzer(modules: [transcriber])
    let file: AVAudioFile
    do { file = try AVAudioFile(forReading: url) } catch { fail("Could not read audio: \(error.localizedDescription)") }

    let collector = Task { () -> [[String: Any]] in
        var words: [[String: Any]] = []
        for try await result in transcriber.results {
            for run in result.text.runs {
                let text = String(result.text[run.range].characters)
                if text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { continue }
                if let range = run.audioTimeRange {
                    words.append(["w": text, "s": range.start.seconds, "e": range.end.seconds])
                } else {
                    words.append(["w": text, "s": result.range.start.seconds, "e": result.range.end.seconds])
                }
            }
        }
        return words
    }
    do {
        if let last = try await analyzer.analyzeSequence(from: file) {
            try await analyzer.finalizeAndFinish(through: last)
        } else {
            await analyzer.cancelAndFinishNow()
        }
        let words = try await collector.value
        emit(["ok": true, "engine": "apple-speech-on-device", "locale": locale.identifier(.bcp47), "words": words])
    } catch {
        fail("Transcription failed: \(error.localizedDescription)")
    }
}

func suggest() async {
    let input = FileHandle.standardInput.readDataToEndOfFile()
    guard let obj = try? JSONSerialization.jsonObject(with: input) as? [String: Any],
          var transcript = obj["transcript"] as? String else { fail("Expected {\"transcript\": \"...\"} on stdin") }
    transcript = transcript.trimmingCharacters(in: .whitespacesAndNewlines)
    guard transcript.split(separator: " ").count >= 4 else { fail("Not enough speech to base a suggestion on.") }
    // The on-device model has a small context window; keep the prompt well within it.
    if transcript.count > 9000 { transcript = String(transcript.prefix(9000)) }
    guard case .available = SystemLanguageModel.default.availability else { fail("The on-device language model is not available.") }
    let session = LanguageModelSession(instructions: """
        You write a title and description for a creator's video from its transcript. \
        Use only information stated in the transcript. Never invent names, places, events, numbers or claims. \
        Keep the creator's own wording where possible. Do not add hashtags or emojis.
        """)
    do {
        let response = try await session.respond(to: "Transcript:\n\(transcript)", generating: VideoMetadata.self)
        emit(["ok": true, "engine": "apple-foundation-models-on-device", "title": response.content.title, "description": response.content.description])
    } catch {
        fail("Suggestion failed: \(error.localizedDescription)")
    }
}

@main
struct ViewverseAI {
    static func main() async {
        let args = CommandLine.arguments
        guard args.count >= 2 else { fail("usage: viewverse-ai status | transcribe <file> [locale] | suggest", code: 2) }
        switch args[1] {
        case "status": await status()
        case "transcribe":
            guard args.count >= 3 else { fail("transcribe needs a file path", code: 2) }
            await transcribe(path: args[2], localeId: args.count >= 4 ? args[3] : "en-US")
        case "suggest": await suggest()
        default: fail("unknown command \(args[1])", code: 2)
        }
    }
}
