// One-time setup: checks tools, builds the on-device AI helper, creates local HTTPS
// certificates, and copies the video player library into public/vendor.
// Safe to run again; it keeps an existing CA so your phone doesn't need to re-trust it.
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execFileSync } from 'node:child_process';
import { ROOT, config } from '../server/config.js';

const ok = (m) => console.log(`  ✓ ${m}`);
const warn = (m) => console.log(`  ! ${m}`);
const has = (cmd, args = ['-version']) => { try { execFileSync(cmd, args, { stdio: 'ignore' }); return true; } catch { return false; } };

console.log('\nViewverse setup\n');
console.log(`  macOS ${os.release()} · ${os.cpus()[0]?.model} · ${Math.round(os.totalmem() / 1024 ** 3)} GB RAM`);

// 1. Media tools
if (!has(config.ffmpeg) || !has(config.ffprobe)) { console.error('  ✗ ffmpeg/ffprobe not found. Install with: brew install ffmpeg'); process.exit(1); }
ok('ffmpeg found');

// 2. On-device AI helper (Apple Speech + Foundation Models)
const helperSrc = path.join(ROOT, 'ai', 'viewverse-ai.swift');
fs.mkdirSync(path.join(ROOT, 'bin'), { recursive: true });
if (process.platform !== 'darwin') warn('Not macOS: on-device AI helper skipped (captions/suggestions will show as unavailable).');
else if (!has('swiftc', ['--version'])) warn('swiftc not found: install Xcode Command Line Tools (xcode-select --install) for captions & suggestions.');
else {
  try {
    execFileSync('swiftc', ['-parse-as-library', '-O', helperSrc, '-o', config.aiHelper], { stdio: 'inherit' });
    const s = JSON.parse(execFileSync(config.aiHelper, ['status']).toString());
    ok(`AI helper built — speech: ${s.speech}, language model: ${s.llm}`);
  } catch (e) { warn(`AI helper failed to build (${e.message}). Captions and suggestions will show as unavailable.`); }
}

// 3. Local HTTPS certificates
const certs = config.certDir;
fs.mkdirSync(certs, { recursive: true, mode: 0o700 });
const caKey = path.join(certs, 'viewverse-local-ca.key');
const caCrt = path.join(certs, 'viewverse-local-ca.crt');
const ossl = (args) => execFileSync('openssl', args, { stdio: ['ignore', 'pipe', 'pipe'] });
if (!fs.existsSync(caKey) || !fs.existsSync(caCrt)) {
  // Name constraints: this CA can only vouch for private-network addresses and .local
  // names, so even if its key leaked it couldn't impersonate real websites.
  ossl(['req', '-x509', '-newkey', 'ec', '-pkeyopt', 'ec_paramgen_curve:prime256v1', '-nodes', '-keyout', caKey, '-out', caCrt, '-days', '825',
    '-subj', '/CN=Viewverse Local CA/O=Viewverse local prototype',
    '-addext', 'basicConstraints=critical,CA:TRUE,pathlen:0',
    '-addext', 'keyUsage=critical,keyCertSign,cRLSign',
    '-addext', 'nameConstraints=critical,permitted;IP:10.0.0.0/255.0.0.0,permitted;IP:172.16.0.0/255.240.0.0,permitted;IP:192.168.0.0/255.255.0.0,permitted;IP:127.0.0.0/255.0.0.0,permitted;DNS:localhost,permitted;DNS:local']);
  fs.chmodSync(caKey, 0o600);
  ok('Created local certificate authority (certs/viewverse-local-ca.crt)');
} else ok('Keeping existing local certificate authority');

let interfaces = {};
try { interfaces = os.networkInterfaces(); } catch { warn('Network interfaces unavailable; local browser access still works.'); }
const ips = Object.values(interfaces).flat().filter((i) => i && i.family === 'IPv4').map((i) => i.address);
const hostLocal = `${os.hostname().replace(/\.local$/, '').replace(/[^A-Za-z0-9-]/g, '-')}.local`;
const san = ['DNS:localhost', `DNS:${hostLocal}`, ...ips.map((ip) => `IP:${ip}`)].join(',');
const srvKey = path.join(certs, 'server.key'), srvCsr = path.join(certs, 'server.csr'), srvCrt = path.join(certs, 'server.crt');
const ext = path.join(certs, 'server.ext');
fs.writeFileSync(ext, `basicConstraints=critical,CA:FALSE\nkeyUsage=critical,digitalSignature\nextendedKeyUsage=serverAuth\nsubjectAltName=${san}\n`);
ossl(['req', '-newkey', 'ec', '-pkeyopt', 'ec_paramgen_curve:prime256v1', '-nodes', '-keyout', srvKey, '-out', srvCsr, '-subj', '/CN=Viewverse local server']);
ossl(['x509', '-req', '-in', srvCsr, '-CA', caCrt, '-CAkey', caKey, '-CAcreateserial', '-out', srvCrt, '-days', '397', '-sha256', '-extfile', ext]);
fs.rmSync(srvCsr); fs.rmSync(ext);
fs.chmodSync(srvKey, 0o600);
ok(`Server certificate for: ${san.replace(/DNS:|IP:/g, '')}`);
console.log('    (If your laptop gets a new Wi-Fi address later, run "npm run certs" again.)');

// 4. Video player library for HLS live playback (served locally, no CDN)
const hlsSrc = path.join(ROOT, 'node_modules', 'hls.js', 'dist', 'hls.min.js');
const vendor = path.join(ROOT, 'public', 'vendor');
fs.mkdirSync(vendor, { recursive: true });
if (fs.existsSync(hlsSrc)) { fs.copyFileSync(hlsSrc, path.join(vendor, 'hls.min.js')); ok('Copied hls.js player'); }
else if (fs.existsSync(path.join(vendor, 'hls.min.js'))) ok('Bundled hls.js player');
else warn('hls.js player unavailable; live playback in Chrome/Firefox requires it.');

// 5. Data folder
fs.mkdirSync(config.dataDir, { recursive: true, mode: 0o700 });
const free = fs.statfsSync(config.dataDir);
const freeGb = (free.bavail * free.bsize) / 1024 ** 3;
(freeGb < config.minFreeDiskGB + 2 ? warn : ok)(`${freeGb.toFixed(1)} GB free disk; Viewverse will use at most ${config.storageQuotaGB} GB (STORAGE_QUOTA_GB)`);

console.log('\nNext: npm start, then open https://localhost:' + config.port + ' on this laptop to create your creator account.\n');
