// Reset the creator password from the laptop's terminal (signs out every device).
import readline from 'node:readline';
import { setPassword, getCreator } from '../server/auth.js';

if (!getCreator()) { console.log('No creator account yet. Start Viewverse and open https://localhost:8443 on this laptop.'); process.exit(0); }
const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
rl._writeToOutput = (s) => { if (s.includes('New password')) process.stdout.write(s); };
rl.question('New password (min 10 characters): ', (pw) => {
  rl.close();
  try { setPassword(pw.trim()); console.log('\nPassword changed. All devices have been signed out.'); }
  catch (e) { console.log(`\n${e.message}`); process.exit(1); }
});
