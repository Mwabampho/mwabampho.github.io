#!/usr/bin/env python3
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import os
PORT=int(os.environ.get('PORT','8787'))
os.chdir(os.path.dirname(os.path.abspath(__file__)))
print(f'GlobalConnect: http://0.0.0.0:{PORT}')
ThreadingHTTPServer(('0.0.0.0',PORT),SimpleHTTPRequestHandler).serve_forever()
