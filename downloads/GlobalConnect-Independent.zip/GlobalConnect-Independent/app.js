const countries = [
  {code:'UK',name:'United Kingdom',flag:'🇬🇧',dial:'+44'},
  {code:'ZM',name:'Zambia',flag:'🇿🇲',dial:'+260'},
  {code:'US',name:'United States',flag:'🇺🇸',dial:'+1'},
  {code:'CA',name:'Canada',flag:'🇨🇦',dial:'+1'},
  {code:'DE',name:'Germany',flag:'🇩🇪',dial:'+49'},
  {code:'FR',name:'France',flag:'🇫🇷',dial:'+33'},
  {code:'JP',name:'Japan',flag:'🇯🇵',dial:'+81'},
  {code:'AU',name:'Australia',flag:'🇦🇺',dial:'+61'}
];
let selected = JSON.parse(localStorage.getItem('gc_country')||'null') || countries[0];
let pc = null, localStream = null;
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
function alias(){ const bytes=new Uint8Array(5); crypto.getRandomValues(bytes); return `GC-${selected.code}-${[...bytes].map(x=>x.toString(16).padStart(2,'0')).join('').toUpperCase()}`; }
function setAlias(){ const a=alias(); $('#currentAlias').textContent=a; $('#newAlias').textContent=a; $('#callAliasLine').textContent=`Private alias ${a}`; return a; }
function renderCountry(){ $('#countryName').textContent=selected.name; $('#countryFlag').textContent=selected.flag; $('#detailsCountry').textContent=selected.name; $('#phoneInput').placeholder=`e.g. ${selected.dial} ...`; localStorage.setItem('gc_country',JSON.stringify(selected)); setAlias(); }
function openDlg(id){ $(id).showModal(); }
function closeDialogs(){ $$('dialog[open]').forEach(d=>d.close()); }
$$('[data-close]').forEach(b=>b.onclick=closeDialogs);
$('#countryButton').onclick=()=>openDlg('#countryDialog');
$('#callBtn').onclick=()=>{setAlias(); openDlg('#callDialog')};
$('#receiveBtn').onclick=()=>openDlg('#answerDialog');
$('#detailsBtn').onclick=()=>openDlg('#detailsDialog');
$('#settingsBtn').onclick=()=>openDlg('#settingsDialog');
$('#countryList').innerHTML=countries.map((c,i)=>`<button class="country-item" data-i="${i}"><span class="f">${c.flag}</span><span><strong>${c.name}</strong><small>${c.dial}</small></span></button>`).join('');
$$('.country-item').forEach(b=>b.onclick=()=>{selected=countries[+b.dataset.i]; renderCountry(); closeDialogs();});
$$('.mode').forEach(b=>b.onclick=()=>{ $$('.mode').forEach(x=>x.classList.remove('active')); b.classList.add('active'); const app=b.dataset.mode==='app'; $('#appCallPanel').classList.toggle('hidden',!app); $('#pstnPanel').classList.toggle('hidden',app); });
$('#regenAlias').onclick=setAlias;
function iceConfig(){ try { return {iceServers: JSON.parse(localStorage.getItem('gc_ice')||'[]')}; } catch { return {iceServers:[]}; } }
async function getMedia(){ if(localStream) return localStream; localStream=await navigator.mediaDevices.getUserMedia({audio:true,video:false}); return localStream; }
function waitIceComplete(peer){ if(peer.iceGatheringState==='complete') return Promise.resolve(); return new Promise(res=>{ const f=()=>{if(peer.iceGatheringState==='complete'){peer.removeEventListener('icegatheringstatechange',f);res();}}; peer.addEventListener('icegatheringstatechange',f); setTimeout(res,5000); }); }
function setupPeer(stateEl){ const peer=new RTCPeerConnection(iceConfig()); peer.ontrack=e=>{ $('#remoteAudio').srcObject=e.streams[0]; stateEl.textContent='Connected — live audio'; }; peer.onconnectionstatechange=()=>{ stateEl.textContent=`Connection: ${peer.connectionState}`; }; return peer; }
async function createOffer(){ try{ await hangup(false); setAlias(); pc=setupPeer($('#callState')); const stream=await getMedia(); stream.getTracks().forEach(t=>pc.addTrack(t,stream)); const offer=await pc.createOffer(); await pc.setLocalDescription(offer); await waitIceComplete(pc); $('#signalBox').value=JSON.stringify(pc.localDescription); $('#callState').textContent='Invite created. Send it privately to the other person, then paste their answer below.'; $('#hangupBtn').classList.remove('hidden'); }catch(e){ $('#callState').textContent=`Cannot start microphone/call: ${e.message}`; } }
async function applyAnswer(){ try{ const data=JSON.parse($('#signalBox').value.trim()); if(!pc) throw new Error('Create an invite first.'); await pc.setRemoteDescription(data); $('#callState').textContent='Answer applied. Connecting…'; }catch(e){ $('#callState').textContent=`Answer error: ${e.message}`; } }
async function answerOffer(){ try{ await answerHangup(false); const offer=JSON.parse($('#incomingOffer').value.trim()); pc=setupPeer($('#answerState')); const stream=await getMedia(); stream.getTracks().forEach(t=>pc.addTrack(t,stream)); await pc.setRemoteDescription(offer); const ans=await pc.createAnswer(); await pc.setLocalDescription(ans); await waitIceComplete(pc); $('#answerBox').value=JSON.stringify(pc.localDescription); $('#answerState').textContent='Answer created. Send it back to the caller.'; $('#answerHangupBtn').classList.remove('hidden'); }catch(e){ $('#answerState').textContent=`Invite error: ${e.message}`; } }
async function hangup(clear=true){ if(pc){pc.close();pc=null} if(localStream){localStream.getTracks().forEach(t=>t.stop());localStream=null} if(clear){$('#callState').textContent='Call ended';$('#hangupBtn').classList.add('hidden');} }
async function answerHangup(clear=true){ await hangup(false); if(clear){$('#answerState').textContent='Call ended';$('#answerHangupBtn').classList.add('hidden');} }
$('#createOfferBtn').onclick=createOffer; $('#applyAnswerBtn').onclick=applyAnswer; $('#answerOfferBtn').onclick=answerOffer; $('#hangupBtn').onclick=()=>hangup(); $('#answerHangupBtn').onclick=()=>answerHangup();
async function copyFrom(sel,stateSel){ try{await navigator.clipboard.writeText($(sel).value); if(stateSel) $(stateSel).textContent='Copied';}catch{ if(stateSel) $(stateSel).textContent='Copy failed — select the text manually'; }}
$('#copySignalBtn').onclick=()=>copyFrom('#signalBox','#callState'); $('#copyAnswerBtn').onclick=()=>copyFrom('#answerBox','#answerState');
$('#iceServers').value=localStorage.getItem('gc_ice')||'[]'; $('#saveSettings').onclick=()=>{ try{JSON.parse($('#iceServers').value||'[]');localStorage.setItem('gc_ice',$('#iceServers').value||'[]');closeDialogs();}catch{alert('ICE servers must be valid JSON.');} };
renderCountry();
if('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(()=>{});
