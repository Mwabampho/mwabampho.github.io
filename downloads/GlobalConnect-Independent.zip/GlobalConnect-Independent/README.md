# GlobalConnect Independent

A local-first, installable phone web app (PWA) matching the GlobalConnect prototype.

## What works
- Country selection (UK default, Zambia and other countries included).
- A fresh cryptographically random **private call alias** for every call.
- Browser-to-browser audio using WebRTC and microphone access.
- No third-party JavaScript SDKs.
- Optional configuration for STUN/TURN servers that **you operate**.
- Installable to a phone home screen as a PWA when served from a secure origin.

## What it deliberately does NOT do
- It does not generate or transmit random public telephone caller-ID numbers.
- It does not claim to provision a real SIM/eSIM profile.
- It does not call ordinary mobile/landline numbers without a real PSTN interconnect.

Random public caller-ID generation can impersonate real subscribers. Instead, GlobalConnect randomizes a private app call alias that has no public telephone routing meaning.

## Run on your Mac
Double-click `Run-GlobalConnect.command`, or run:

```sh
cd GlobalConnect-Independent
python3 server.py
```

Then open the printed address.

## Put it on your phone
For normal UI testing on the same Wi-Fi, open the Mac address shown by the launcher.

For microphone/WebRTC and install-to-home-screen outside localhost, browsers normally require HTTPS. Host this folder on an HTTPS server you control. Then open it on your phone and choose **Add to Home Screen**.

## Real app-to-app voice
1. Caller taps **Make a call** → **Create voice invite**.
2. Caller sends the generated invite data privately to the recipient.
3. Recipient opens **Receive / answer**, pastes the invite, and creates an answer.
4. Recipient sends the answer data back.
5. Caller pastes the answer over the invite text and taps **Apply answer**.
6. If the network path allows direct WebRTC connectivity, the audio call connects.

For reliable calls between unrelated networks/countries, run your own STUN/TURN infrastructure and add its ICE server JSON in Settings. No external ICE service is configured by default.

## Calling a Zambian mobile number
A regular Zambian mobile/landline number is on the PSTN/mobile network. Reaching it requires a legitimate telecom interconnect/carrier route and a valid originating identity. The application intentionally does not simulate that connection.
