#!/bin/zsh
cd "$(dirname "$0")"
IP=$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || echo "YOUR-MAC-IP")
echo ""
echo "GlobalConnect Independent"
echo "On this Mac: http://127.0.0.1:8787"
echo "On your phone (same Wi-Fi): http://$IP:8787"
echo ""
python3 server.py
