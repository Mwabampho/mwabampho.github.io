CLEAN — ARISE 0.2 — macOS

1. Double-click “Build and Install Clean.command”.
2. macOS builds the native SwiftUI application and installs it to ~/Applications/Clean.app.
3. Clean launches immediately.

Arise 0.2 rules:
- Core Clean works with zero third-party API keys.
- No API-key gate on startup.
- When you deliberately connect an external provider, Clean asks for that API key then.
- The key is session-only by default and is not persisted.
- Settings contains visible Check for Updates and Download Arise 0.2 controls.
- Update centre: https://shouldbe.media/clean/updates
