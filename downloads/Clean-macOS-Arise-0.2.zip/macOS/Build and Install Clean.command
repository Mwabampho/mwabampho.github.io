#!/bin/zsh
set -euo pipefail
cd "$(dirname "$0")"
APP="$HOME/Applications/Clean.app"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleName</key><string>Clean</string>
<key>CFBundleDisplayName</key><string>Clean</string>
<key>CFBundleIdentifier</key><string>media.shouldbe.clean</string>
<key>CFBundleVersion</key><string>2</string>
<key>CFBundleShortVersionString</key><string>0.2</string>
<key>LSMinimumSystemVersion</key><string>13.0</string>
<key>NSHighResolutionCapable</key><true/>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleExecutable</key><string>Clean</string>
</dict></plist>
PLIST
xcrun swiftc -parse-as-library CleanMac.swift -o "$APP/Contents/MacOS/Clean" -framework SwiftUI -framework AppKit
codesign --force --deep --sign - "$APP" >/dev/null 2>&1 || true
xattr -dr com.apple.quarantine "$APP" 2>/dev/null || true
open "$APP"
echo ""
echo "✅ Clean — Arise 0.2 installed in $APP"
echo "Core Clean requires no third-party API key. External keys are entered only when you choose to connect and are session-only by default."
