import SwiftUI
import AppKit

private let cleanVersion = "Arise 0.2"
private let updatesURL = URL(string: "https://shouldbe.media/clean/updates")!

@main
struct CleanMacApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
                .frame(minWidth: 980, minHeight: 680)
        }
        .windowStyle(.hiddenTitleBar)
    }
}

enum CleanSection: String, CaseIterable, Identifiable {
    case brain = "Brain"
    case projects = "Projects"
    case vault = "The Vault"
    case more = "More"
    case settings = "Settings"
    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .brain: return "brain.head.profile"
        case .projects: return "square.grid.2x2"
        case .vault: return "lock.square.stack"
        case .more: return "ellipsis.circle"
        case .settings: return "gearshape"
        }
    }
}

struct RootView: View {
    @State private var section: CleanSection = .brain
    var body: some View {
        NavigationSplitView {
            ZStack {
                Color(red: 0.025, green: 0.055, blue: 0.10).ignoresSafeArea()
                VStack(alignment: .leading, spacing: 18) {
                    HStack(spacing: 10) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 11).fill(.blue.gradient).frame(width: 38, height: 42)
                            Image(systemName: "checkmark.shield.fill").foregroundStyle(.white)
                        }
                        VStack(alignment: .leading, spacing: 1) {
                            Text("Clean").font(.title2.bold())
                            Text(cleanVersion).font(.caption).foregroundStyle(.secondary)
                        }
                    }.padding(.horizontal, 8).padding(.top, 12)
                    ForEach(CleanSection.allCases) { item in
                        Button {
                            section = item
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: item.symbol).frame(width: 22)
                                Text(item.rawValue)
                                Spacer()
                            }
                            .padding(.vertical, 10).padding(.horizontal, 12)
                            .background(section == item ? Color.blue.opacity(0.24) : .clear)
                            .clipShape(RoundedRectangle(cornerRadius: 11))
                        }
                        .buttonStyle(.plain)
                    }
                    Spacer()
                    Label("Single owner · Private", systemImage: "lock.fill")
                        .font(.caption).foregroundStyle(.secondary).padding(10)
                }.padding(12)
            }
            .navigationSplitViewColumnWidth(min: 210, ideal: 230, max: 260)
        } detail: {
            ZStack {
                LinearGradient(colors: [Color(red:0.025, green:0.07, blue:0.13), Color(red:0.02, green:0.04, blue:0.08)], startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()
                Group {
                    switch section {
                    case .brain: BrainView()
                    case .projects: ProjectsView()
                    case .vault: VaultView()
                    case .more: MoreView(section: $section)
                    case .settings: SettingsView()
                    }
                }.padding(28)
            }
        }
        .preferredColorScheme(.dark)
    }
}

struct Header: View {
    let title: String
    let subtitle: String
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.system(size: 30, weight: .bold))
            Text(subtitle).foregroundStyle(.secondary)
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct BrainView: View {
    @State private var text = ""
    @State private var history: [String] = []
    var body: some View {
        VStack(spacing: 18) {
            Header(title: "Brain", subtitle: "Your private control layer. Core Clean works without third-party API keys.")
            GlassCard {
                VStack(alignment: .leading, spacing: 12) {
                    Label("Local-first mode", systemImage: "checkmark.seal.fill").foregroundStyle(.green)
                    Text("External providers are optional. When you choose to connect one, Clean asks for the API key at that moment and does not persist it by default.")
                        .foregroundStyle(.secondary)
                }
            }
            GlassCard {
                VStack(spacing: 12) {
                    ScrollView {
                        VStack(alignment: .leading, spacing: 10) {
                            ForEach(Array(history.enumerated()), id: \.offset) { _, item in
                                Text(item).padding(10).background(Color.white.opacity(0.05)).clipShape(RoundedRectangle(cornerRadius: 10))
                            }
                        }.frame(maxWidth: .infinity, alignment: .leading)
                    }
                    HStack {
                        TextField("Write to your Brain…", text: $text).textFieldStyle(.plain).padding(12).background(Color.black.opacity(0.22)).clipShape(RoundedRectangle(cornerRadius: 10))
                        Button("Save locally") {
                            let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
                            guard !trimmed.isEmpty else { return }
                            history.append(trimmed)
                            text = ""
                        }.buttonStyle(.borderedProminent)
                    }
                }.frame(minHeight: 330)
            }
            Spacer()
        }
    }
}

struct ProjectsView: View {
    var body: some View {
        VStack(spacing: 18) {
            Header(title: "Projects", subtitle: "Organize the products and systems you own.")
            HStack(spacing: 14) {
                ProjectCard(name: "Clean", detail: "Top-level control application", status: "Active")
                ProjectCard(name: "ShouldBe", detail: "Primary ecosystem", status: "Managed")
            }
            Spacer()
        }
    }
}

struct ProjectCard: View {
    let name: String; let detail: String; let status: String
    var body: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 12) {
                Image(systemName: "app.gift.fill").font(.title2).foregroundStyle(.blue)
                Text(name).font(.title3.bold())
                Text(detail).foregroundStyle(.secondary)
                Text(status).font(.caption.bold()).foregroundStyle(.cyan)
            }.frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}

struct VaultIdea: Identifiable, Codable { let id: UUID; var text: String; var status: String }

struct VaultView: View {
    @State private var idea = ""
    @State private var ideas: [VaultIdea] = []
    var body: some View {
        VStack(spacing: 18) {
            Header(title: "The Vault", subtitle: "Private idea capture. Keep ideas local until you decide what to do with them.")
            GlassCard {
                HStack {
                    TextField("Capture an idea…", text: $idea).textFieldStyle(.plain).padding(12).background(Color.black.opacity(0.22)).clipShape(RoundedRectangle(cornerRadius: 10))
                    Button("Save") {
                        let value = idea.trimmingCharacters(in: .whitespacesAndNewlines)
                        guard !value.isEmpty else { return }
                        ideas.insert(VaultIdea(id: UUID(), text: value, status: "Active"), at: 0)
                        idea = ""
                    }.buttonStyle(.borderedProminent)
                }
            }
            GlassCard {
                if ideas.isEmpty {
                    ContentUnavailableView("The Vault is empty", systemImage: "lock.square.stack", description: Text("Your ideas will appear here."))
                } else {
                    List(ideas) { item in
                        HStack {
                            VStack(alignment: .leading) { Text(item.text); Text(item.status).font(.caption).foregroundStyle(.secondary) }
                            Spacer()
                            Button("Turn into project") { }
                        }
                    }.scrollContentBackground(.hidden)
                }
            }
            Spacer()
        }
    }
}

struct MoreView: View {
    @Binding var section: CleanSection
    var body: some View {
        VStack(spacing: 18) {
            Header(title: "More", subtitle: "Clean tools and controls.")
            GlassCard {
                VStack(spacing: 8) {
                    RowButton(icon: "gearshape.fill", title: "Settings", subtitle: "Privacy, connections and updates") { section = .settings }
                    Divider()
                    RowButton(icon: "arrow.triangle.2.circlepath", title: "Check for Updates", subtitle: "Open the Clean update centre") { NSWorkspace.shared.open(updatesURL) }
                }
            }
            Spacer()
        }
    }
}

struct SettingsView: View {
    @State private var provider = ""
    @State private var apiKey = ""
    @State private var sessionConnected = false
    @State private var updateMessage = "Arise 0.2 · current release"
    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                Header(title: "Settings", subtitle: "Independent by default. External credentials only when you choose to connect.")
                GlassCard {
                    VStack(alignment: .leading, spacing: 12) {
                        Label("Core independence", systemImage: "checkmark.shield.fill").font(.headline)
                        Toggle("Require no third-party API key for core Clean", isOn: .constant(true)).disabled(true)
                        Text("Clean starts and remains usable without OpenAI, Anthropic, Google or any other third-party credential.")
                            .font(.callout).foregroundStyle(.secondary)
                    }
                }
                GlassCard {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Temporary external connection").font(.headline)
                        TextField("Provider or service", text: $provider).textFieldStyle(.roundedBorder)
                        SecureField("API key for this session", text: $apiKey).textFieldStyle(.roundedBorder)
                        HStack {
                            Button(sessionConnected ? "Connected for this session" : "Connect") {
                                sessionConnected = !provider.isEmpty && !apiKey.isEmpty
                            }.buttonStyle(.borderedProminent)
                            Button("Clear key") { apiKey = ""; sessionConnected = false }
                        }
                        Text("The key is kept in memory for this app session only and is not written to Clean storage by default.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
                GlassCard {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Updates & downloads").font(.headline)
                        Text(updateMessage).foregroundStyle(.secondary)
                        HStack {
                            Button("Check for Updates") {
                                updateMessage = "Opening first-party Clean update centre…"
                                NSWorkspace.shared.open(updatesURL)
                            }.buttonStyle(.bordered)
                            Button("Download Arise 0.2") { NSWorkspace.shared.open(updatesURL) }
                                .buttonStyle(.borderedProminent)
                        }
                    }
                }
            }
        }
    }
}

struct RowButton: View {
    let icon: String; let title: String; let subtitle: String; let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                Image(systemName: icon).foregroundStyle(.blue).frame(width: 26)
                VStack(alignment: .leading, spacing: 2) { Text(title).foregroundStyle(.primary).font(.headline); Text(subtitle).font(.caption).foregroundStyle(.secondary) }
                Spacer(); Image(systemName: "chevron.right").foregroundStyle(.tertiary)
            }.padding(.vertical, 8)
        }.buttonStyle(.plain)
    }
}

struct GlassCard<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        content.padding(18).background(.ultraThinMaterial.opacity(0.75)).overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.white.opacity(0.08))).clipShape(RoundedRectangle(cornerRadius: 18))
    }
}
