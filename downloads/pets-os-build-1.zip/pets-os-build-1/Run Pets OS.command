#!/bin/zsh
set -eu
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
cd "$(dirname "$0")"
if [ -f "build.py" ]; then
    python3 build.py
fi

if ! command -v qemu-system-i386 >/dev/null 2>&1; then
    echo "❌ Error: QEMU is required to run Pets OS on macOS."
    echo "To install QEMU, run this in Terminal: brew install qemu"
    echo ""
    read -k 1 -s "?Press any key to exit..."
    exit 1
fi

echo "🐾 Booting Pets OS Build 1 on macOS..."
exec qemu-system-i386 -name 'Pets OS — Graphical Desktop' -machine pc,pcspk-audiodev=snd0 -accel tcg -m 128 -audiodev coreaudio,id=snd0 -drive file=build/pets.img,format=raw,if=ide -boot c -vga std -no-reboot
