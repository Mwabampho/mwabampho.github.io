#!/bin/zsh
set -eu

# Ensure standard tools in PATH
export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"

cd "$(dirname "$0")"

# Colors
BOLD='\033[1m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
RESET='\033[0m'

clear
echo -e "${BOLD}${CYAN}"
echo "============================================================"
echo "          🐾 Pets OS — Create Bootable USB Drive 🐾         "
echo "============================================================"
echo -e "${RESET}"

# 1. Check bootable disk image
if [ -f "build.py" ]; then
    echo -e "${CYAN}Building latest Pets OS distribution images...${RESET}"
    python3 build.py
    echo ""
fi

IMG="build/pets.img"
if [ ! -f "$IMG" ]; then
    echo -e "${RED}Error: $IMG not found!${RESET}"
    exit 1
fi

# 2. Scan for external removable drives
echo -e "${BOLD}Scanning for connected external USB drives...${RESET}"
echo "------------------------------------------------------------"

EXTERNAL_DISKS=$(diskutil list external | grep -E "^/dev/disk[0-9]+" | awk '{print $1}' || true)

if [ -z "$EXTERNAL_DISKS" ]; then
    echo -e "${YELLOW}No external USB drives detected.${RESET}"
    echo ""
    echo "Please connect your USB flash drive (thumb drive) and run"
    echo "this command again."
    echo ""
    read -k 1 -s "?Press any key to exit..."
    echo ""
    exit 0
fi

echo -e "${GREEN}Detected External Drive(s):${RESET}"
diskutil list external
echo "------------------------------------------------------------"

# 3. Prompt user for target disk identifier
echo -e "${BOLD}Select target drive:${RESET}"
echo "Enter just the disk name (for example, ${CYAN}disk2${RESET} or ${CYAN}disk3${RESET}):"
read -r TARGET_NAME

TARGET_NAME=$(echo "$TARGET_NAME" | tr -d ' ' | sed 's|/dev/||')

if [ -z "$TARGET_NAME" ]; then
    echo -e "${RED}No drive specified. Operation canceled.${RESET}"
    exit 1
fi

TARGET_DEV="/dev/$TARGET_NAME"
TARGET_RDEV="/dev/r$TARGET_NAME"

# 4. Strict Safety Guard: Never allow flashing an internal drive!
IS_INTERNAL=$(diskutil info "$TARGET_DEV" 2>/dev/null | grep -i "Internal:" | awk '{print $2}' || true)
if [ "$IS_INTERNAL" = "Yes" ]; then
    echo -e "${RED}${BOLD}CRITICAL SAFETY ERROR: $TARGET_DEV is an INTERNAL macOS drive!${RESET}"
    echo "Flashing an internal drive is strictly prevented."
    exit 1
fi

# Verify drive exists
if [ ! -e "$TARGET_DEV" ]; then
    echo -e "${RED}Error: Device $TARGET_DEV does not exist!${RESET}"
    exit 1
fi

echo ""
echo -e "${BOLD}${YELLOW}Target Drive Summary:${RESET}"
diskutil info "$TARGET_DEV" | grep -E "Device / Media Name|Disk Size|Content \(Data\)|Protocol"
echo ""

echo -e "${BOLD}${RED}WARNING: All existing data on $TARGET_DEV will be erased!${RESET}"
echo "Are you sure you want to write Pets OS to this drive?"
echo "Type ${BOLD}YES${RESET} (in capital letters) to confirm, or press Enter to cancel:"
read -r CONFIRMATION

if [ "$CONFIRMATION" != "YES" ]; then
    echo -e "${YELLOW}Confirmation not given. Canceled with no changes made.${RESET}"
    exit 0
fi

# 5. Unmount disk and flash Pets OS image
echo ""
echo -e "${CYAN}Unmounting $TARGET_DEV...${RESET}"
diskutil unmountDisk "$TARGET_DEV"

echo -e "${CYAN}Writing Pets OS to $TARGET_RDEV (may prompt for Mac password)...${RESET}"
sudo dd if="$IMG" of="$TARGET_RDEV" bs=1m status=progress conv=sync

echo -e "${CYAN}Flushing cache and syncing disk buffers...${RESET}"
sync

echo -e "${CYAN}Safely ejecting $TARGET_DEV...${RESET}"
diskutil eject "$TARGET_DEV" || true

echo ""
echo -e "${BOLD}${GREEN}============================================================${RESET}"
echo -e "${BOLD}${GREEN}  🐾 SUCCESS! Pets OS Bootable USB Drive is Ready! 🐾      ${RESET}"
echo -e "${BOLD}${GREEN}============================================================${RESET}"
echo ""
echo "You can now safely remove your USB flash drive."
echo ""
echo "To boot Pets OS on a physical PC / laptop:"
echo "1. Insert the USB drive into your PC."
echo "2. Power on the PC and press the Boot Menu key (F12, F11, F8, or Del)."
echo "3. Select the USB Drive (Legacy / CSM mode)."
echo "4. Enjoy Pets OS running directly on real bare-metal hardware!"
echo ""
read -k 1 -s "?Press any key to close this window..."
echo ""
