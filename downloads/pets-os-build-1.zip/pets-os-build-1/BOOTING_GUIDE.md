# Pets OS — Complete Bootable Drive & Hardware Guide

Pets OS can be booted in two ways:
1. **Physical Bare-Metal Hardware**: Flash to a USB flash drive (thumb drive) and boot real x86 PCs/laptops.
2. **Virtual Machine Hypervisors**: Load `build/pets.img` (virtual hard disk) or `build/pets.iso` (virtual optical disc) into UTM, VirtualBox, VMware, or QEMU.

---

## 1. Creating a Bootable USB Flash Drive on macOS

### Method A: One-Click Interactive macOS Tool (Recommended)
1. Insert any standard USB flash drive (thumb drive) into your Mac.
2. Double-click **[`Create Bootable Drive.command`](Create%20Bootable%20Drive.command)** in Finder (or run `./"Create Bootable Drive.command"` in Terminal).
3. The tool will scan and list all connected external drives.
4. Type your USB drive identifier (e.g. `disk2`).
   *(Safety check: The tool automatically prevents selecting internal Mac system drives).*
5. Confirm the drive size and name, then type **`YES`** to write Pets OS.
6. Once finished, the tool safely unmounts and ejects the USB drive. It is now ready to boot!

### Method B: Graphical Flasher (BalenaEtcher / Raspberry Pi Imager)
1. Download [BalenaEtcher](https://etcher.balena.io/) or Raspberry Pi Imager on your Mac.
2. Select **Flash from file** and choose `build/pets.img` (or `build/pets.iso`).
3. Select your target USB flash drive.
4. Click **Flash!**

---

## 2. Creating a Bootable USB Flash Drive on Windows

1. Insert your USB thumb drive into a Windows PC.
2. Download and open [Rufus](https://rufus.ie/).
3. Under **Device**, select your USB flash drive.
4. Under **Boot selection**, click **SELECT** and choose `build/pets.img` (or `pets.iso`).
5. Set **Partition scheme** to **MBR** and **Target system** to **BIOS (or UEFI-CSM)**.
6. Click **START** to create the bootable drive.

---

## 3. Booting Physical PC / Laptop Hardware

To boot Pets OS bare-metal on a desktop PC or laptop:

1. Insert the bootable USB drive into the PC.
2. Power on the computer and immediately start tapping the **Boot Menu Key**:
   - **Lenovo / ThinkPad**: `F12` or `Enter`
   - **Dell**: `F12`
   - **HP**: `F9` or `Esc`
   - **Asus**: `F8` or `Esc`
   - **Acer / MSI**: `F11` or `F12`
   - **Generic / Custom PC**: `F11`, `F12`, or `F8`
3. If the USB drive does not appear or fails to start, enter the **BIOS / UEFI Setup** (`F2` or `Del` on boot):
   - **Enable CSM / Legacy Boot**: Under the *Boot* or *Startup* tab, enable **CSM (Compatibility Support Module)** or **Legacy Boot Mode**.
   - **Disable Secure Boot**: Under the *Security* tab, turn **Secure Boot** to **Disabled**.
   - Save and exit (`F10`).
4. Select your USB drive from the Boot Menu.
5. Pets OS will boot natively in 1024x768 32-bit True Color with full mouse, keyboard, sound, and filesystem capabilities!

---

## 4. Booting in Virtual Machines on macOS

### A. UTM (Native macOS Hypervisor — Apple Silicon & Intel)
1. Open [UTM](https://mac.getutm.app/).
2. Click **Create a New Virtual Machine** -> **Emulate**.
3. Choose **Other**.
4. Configure:
   - **Architecture**: `x86_64` or `i386`
   - **Memory**: `128 MB` or `256 MB`
5. Under Drives, choose **New Drive**:
   - Interface: **IDE**
   - Click **Import Drive** and select `build/pets.img` (or mount `build/pets.iso` as a CD/DVD image).
6. Click **Start** to run Pets OS!

### B. VirtualBox
1. Open VirtualBox and click **New**.
2. Set Type: **Other**, Version: **Other/Unknown (32-bit)**, RAM: **128 MB**.
3. Under Storage:
   - Attach `build/pets.iso` to the Optical Drive, or
   - Attach `build/pets.img` to the Primary IDE Controller.
4. Click **Start**.

### C. VMware Fusion
1. Create a custom 32-bit virtual machine.
2. Attach `build/pets.iso` as the CD/DVD drive.
3. Power on the virtual machine.

### D. Native QEMU (Fastest macOS Local Test)
Simply double-click **[`Run Pets OS.command`](Run%20Pets%20OS.command)** in Finder!
